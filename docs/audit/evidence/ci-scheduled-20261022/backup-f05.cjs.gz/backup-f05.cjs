// Read-only backup only. No mutation, settings override, or cleanup entry point.
process.loadEnvFile('.env.local');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {once}=require('node:events'),{finished}=require('node:stream/promises');
const {Client}=require(process.cwd()+'/node_modules/pg');
const out=path.resolve('artifacts/db-cleanup/20261022-f05');
const u=new URL(process.env.DATABASE_URL);
const c=new Client({host:u.hostname,port:Number(u.port||5432),user:decodeURIComponent(u.username),password:decodeURIComponent(u.password),database:u.pathname.slice(1),ssl:{ca:fs.readFileSync(process.env.QUANTOS_BFF_SSLROOTCERT,'utf8'),rejectUnauthorized:true},connectionTimeoutMillis:10000});
c.on('error',e=>{console.error('CONNECTION_ERROR',e.code||e.name);process.exitCode=1});
const manifest={status:'RUNNING_READ_ONLY_BACKUP',startedAt:new Date().toISOString(),scope:'strict-f05-generated-service-fixtures',files:[]};
const save=()=>fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{mode:0o600});
const ident=x=>{if(!/^[a-z_]+$/.test(x))throw Error('unexpected table identifier');return '"'+x+'"'};
(async()=>{try{
 fs.mkdirSync(out,{recursive:true,mode:0o700});save();await c.connect();
 await c.query('begin isolation level repeatable read read only');await c.query("set local statement_timeout='60s'");
 const tenants=(await c.query("select t.id,t.slug,t.name from quantos.tenants t where t.slug='f05-live-'||t.id::text and t.name=t.slug and not exists(select 1 from quantos.actors a where a.tenant_id=t.id and (a.actor_kind<>'service' or a.service_name is distinct from 'f05-test-'||a.id::text)) order by t.id")).rows;
 if(tenants.length===0)throw Error('no strictly matched fixtures');
 manifest.tenants=tenants;save();const ids=tenants.map(t=>t.id);
 const tables=(await c.query("select c.relname as table_name from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attname='tenant_id' and not a.attisdropped where n.nspname='quantos' and c.relkind='r' order by c.relname")).rows.map(r=>r.table_name);
 for(const table of ['tenants',...tables]){
  const column=table==='tenants'?'id':'tenant_id';
  await c.query(`declare fixture_rows no scroll cursor for select row_to_json(t)::text as document from quantos.${ident(table)} t where ${column}=any($1::uuid[])`,[ids]);
  const filename=table+'.jsonl.gz',target=path.join(out,filename),gzip=zlib.createGzip({level:6}),file=fs.createWriteStream(target,{mode:0o600,flags:'wx'});
  gzip.pipe(file);let rows=0;
  try{for(;;){const batch=await c.query('fetch forward 2000 from fixture_rows');if(!batch.rows.length)break;for(const r of batch.rows){if(!gzip.write(r.document+'\n'))await once(gzip,'drain');rows++;}}gzip.end();await finished(file);}catch(e){gzip.destroy();file.destroy();throw e;}
  await c.query('close fixture_rows');
  const hash=crypto.createHash('sha256');for await(const chunk of fs.createReadStream(target))hash.update(chunk);
  manifest.files.push({table,path:filename,rows,bytes:fs.statSync(target).size,sha256:hash.digest('hex')});save();console.log(JSON.stringify({table,rows,bytes:fs.statSync(target).size}));
 }
 await c.query('rollback');manifest.status='PASS_READ_ONLY_BACKUP';manifest.finishedAt=new Date().toISOString();save();console.log('Backup completed; no rows deleted.');
}catch(e){manifest.status='FAIL_READ_ONLY_BACKUP';manifest.error={code:e.code||e.name,message:e.message};save();console.error(e.code||e.name,e.message);process.exitCode=1;}finally{await c.end();}})();
