process.loadEnvFile('.env.local');
const {spawnSync}=require('node:child_process');
const u=new URL(process.env.DATABASE_URL);u.searchParams.set('sslmode','verify-full');u.searchParams.set('sslrootcert',process.env.QUANTOS_BFF_SSLROOTCERT);
const kind=process.argv[2];
const args=kind==='f05'?['-p','quantos-event','-p','quantos-storage','--lib','--test','postgres_persistence','--test','storage_http']:['-p','quantos-runtime','-p','runtime-gateway','--lib','--bins','--test','postgres_runtime'];
const result=spawnSync('cargo',['llvm-cov',...args,'--branch','--json','--output-path',`/tmp/quantos-ci-scheduled-20261022/local/${kind}-coverage.json`,'--locked','--','--test-threads=1','--nocapture'],{stdio:'inherit',env:{...process.env,DATABASE_URL:u.toString(),SSL_CERT_FILE:process.env.QUANTOS_BFF_SSLROOTCERT,RUSTUP_TOOLCHAIN:'nightly-2026-10-21',CARGO_BUILD_JOBS:'1',QUANTOS_RUN_F05_POSTGRES_TESTS:'1',QUANTOS_F07_DB_REQUIRED:'1',QUANTOS_RUNTIME_RECOVERY_RUNS:'10',QUANTOS_F07_COVERAGE_MEASUREMENT:'1',QUANTOS_F05_MEASUREMENTS_PATH:'/tmp/quantos-ci-scheduled-20261022/local/f05-measurements.json'}});
process.exit(result.status??1);
