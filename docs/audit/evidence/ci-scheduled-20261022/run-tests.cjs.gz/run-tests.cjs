process.loadEnvFile('.env.local');
const {spawnSync}=require('node:child_process');
const u=new URL(process.env.DATABASE_URL);
u.searchParams.set('sslmode','verify-full');u.searchParams.set('sslrootcert',process.env.QUANTOS_BFF_SSLROOTCERT);
const result=spawnSync('cargo',process.argv.slice(2),{stdio:'inherit',env:{...process.env,DATABASE_URL:u.toString(),SSL_CERT_FILE:process.env.QUANTOS_BFF_SSLROOTCERT,CARGO_BUILD_JOBS:'1',QUANTOS_RUN_F05_POSTGRES_TESTS:'1',QUANTOS_F07_DB_REQUIRED:'1'}});
process.exit(result.status??1);
