# Read-only review of redacted findings against immutable Git blobs.
import json,re,subprocess,hashlib,collections
from pathlib import Path
root=Path('artifacts/ci-89ddea26-20261027')
findings=json.loads((root/'history-findings.json').read_text())
assert len(findings)==156
assert collections.Counter(f['Commit'] for f in findings)=={'89ddea268e3494f7b495eb3ec3040d1aa3f2003f':42,'10d13870229a3b9f6325b23fbde3203b466b27d3':6,'072fa539792e776824dd9800ea83323fe05af89a':108}
cache={}
def blob(commit,path):
 key=(commit,path)
 if key not in cache:cache[key]=subprocess.check_output(['git','show',commit+':'+path])
 return cache[key]
def sha(b):return hashlib.sha256(b).hexdigest()
producers=[]
for commit in sorted(set(f['Commit'] for f in findings)):
 for path in ['tests/e2e/fixtures/fep5-reference.ts','tests/e2e/fixtures/frontend-g8-reference.ts']:
  b=blob(commit,path);text=re.sub(r'\s+','',b.decode()).replace("'",'"')
  assert 'createHash("sha256").update(b).digest("hex")' in text
  assert 'keyHash:req.headers["idempotency-key"]?hash(String(req.headers["idempotency-key"])):undefined' in text
  producers.append({'commit':commit,'path':path,'sha256':sha(b),'producer':'request idempotency-key -> SHA256 hex; original request keys are not retained'})
review=[]
for f in findings:
 assert f['RuleID']=='generic-api-key' and f['StartLine']==f['EndLine']
 assert f['File'].startswith(('docs/audit/evidence/core-l03-local-20261027/','docs/audit/evidence/frontend-g8-current-20261027/'))
 assert f['File'].endswith(('/fep5.json','/frontend-g8.json','/g8-journey.json'))
 b=blob(f['Commit'],f['File']);line=b.decode().splitlines()[f['StartLine']-1]
 match=re.fullmatch(r'\s*"keyHash": "([a-f0-9]{64})",?\s*',line);assert match
 rows=[]
 def walk(o):
  if isinstance(o,dict):
   if o.get('keyHash')==match[1]:rows.append(o)
   for v in o.values():walk(v)
  elif isinstance(o,list):
   for v in o:walk(v)
 obj=json.loads(b);walk(obj);assert rows
 for row in rows:
  assert {'method','path','status','source','bodyHash','query','control'}<=row.keys()
  assert row['method']=='POST' and row['path'].startswith('/v1/') and isinstance(row['status'],int)
  assert row['source'] in ['REFERENCE_BYTES','REFERENCE_COMMITTED_RESPONSE_DROPPED','SYNTHETIC_FEP5_DECISION_CORRELATION']
  assert re.fullmatch('[a-f0-9]{64}',row['bodyHash'])
 fingerprint=f"{f['Commit']}:{f['File']}:{f['RuleID']}:{f['StartLine']}"
 assert f['Fingerprint']==fingerprint
 review.append({'fingerprint':fingerprint,'commit':f['Commit'],'path':f['File'],'rule':f['RuleID'],'line':f['StartLine'],'blobSha256':sha(b),'lineSha256':sha(line.encode()),'classification':'OWNED_REQUEST_IDEMPOTENCY_SHA256_NOT_AUTHENTICATION','rowSources':sorted(set(row['source'] for row in rows)),'matchingRows':len(rows),'recordedSourceCommit':obj.get('sourceCommit') if isinstance(obj,dict) else None})
assert len(set(r['fingerprint'] for r in review))==len(review)
(root/'history-finding-review.json').write_text(json.dumps({'findings':len(review),'unclassified':0,'historicalEvidenceBlobs':len({(f['Commit'],f['File']) for f in findings}),'producerSnapshots':producers,'limitation':'Original request idempotency keys were not retained; this review verifies producer semantics and exact historical rows, not digest preimage recomputation. Historical bytes remain unchanged.','review':review},indent=2)+'\n')
(root/'reviewed-fingerprints.txt').write_text('\n'.join(r['fingerprint'] for r in review)+'\n')
print('156 exact findings verified; 30 historical evidence blobs; 6 historical producer snapshots; 0 unclassified')
