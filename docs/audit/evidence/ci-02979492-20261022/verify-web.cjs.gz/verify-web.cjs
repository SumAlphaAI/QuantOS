const fs=require('node:fs'),{spawnSync}=require('node:child_process'),{parse}=require('yaml');
const out='artifacts/ci-02979492-20261022';
const workflow=parse(fs.readFileSync('.github/workflows/frontend-baseline.yml','utf8'));
const profile=Object.fromEntries(Object.entries(workflow.jobs['frontend-baseline'].env).filter(([key])=>key.startsWith('NEXT_PUBLIC_')));
const env={...process.env,...profile,QUANTOS_SKIP_ENV:'1',NEXT_TELEMETRY_DISABLED:'1'};
for(const key of Object.keys(env))if(/DATABASE_URL|SUPABASE|QUANTOS_RUN_.*TESTS|QUANTOS_F07_DB_REQUIRED/.test(key))delete env[key];
const commands=[['web-website-build',['--filter','@sumalpha/website','build']],['web-terminal-build',['--filter','@sumalpha/terminal','build']],['pre03-positive',['check:pre03:web']],['pre03-negative',['test:pre03']]];
const receipt={schema:'quantos-scoped-web-validation/v1',profile:'same public variables as Frontend Baseline',databaseExecution:false,attempts:[],status:'RUNNING'};
for(const[name,args]of commands){
 const started=Date.now();const r=spawnSync('pnpm',args,{env,encoding:'utf8',timeout:300000,maxBuffer:10000000});
 fs.writeFileSync(`${out}/${name}.log`,(r.stdout||'')+(r.stderr||''));
 receipt.attempts.push({name,command:['pnpm',...args],exitCode:r.status,signal:r.signal,elapsedMs:Date.now()-started});
 receipt.status=r.status===0?'RUNNING':'FAIL';fs.writeFileSync(out+'/web-validation.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(name+': '+r.status);if(r.status!==0)process.exit(1);
}
receipt.status='PASS';fs.writeFileSync(out+'/web-validation.json',JSON.stringify(receipt,null,2)+'\n');
