> 当前工程结果（2026-10-14）：冻结5fa0fb04完整42节点/141组共同本地执行PASS；R1-SERVICE/A2/BFF003/BFF005/A3五项限定DEVELOPMENT READY已恢复，TP02_LOCAL以同源13节点/44组证明重新READY。全图6 READY / 153 NOT_ASSESSED / 0 BLOCKED；Supabase、外部/性能与正式验收独立待办，formalAccepted=false。见[本轮报告](./audit/PROVIDER-A3-readmission-2026-10-14.md)。

> 上轮工程快照：2026-10-13 TP02_LOCAL DEVELOPMENT READY；冻结135c7bd5完整13节点/44组本地检查PASS，全图1 READY / 158 NOT_ASSESSED / 0 BLOCKED，仅TP02放行。上轮A3相关五项READY因公共输入变化撤回，历史证据保留；外部/性能归测试及RELEASE，formalAccepted=false。见[本轮报告](./audit/TP02-local-admission-2026-10-13.md)。

> 上轮工程快照：2026-10-13 PROVIDER:A3 聚合开发验收完成；冻结 1ee328c7 的 42 节点 / 140 组全部 PASS，A2/R1-SERVICE/BFF003/BFF005/A3 五份限定 DEVELOPMENT READY；全图 5 READY / 154 NOT_ASSESSED / 0 BLOCKED。外部环境及性能移交 RELEASE，formalAccepted=false。见[本轮报告](./audit/PROVIDER-A3-development-2026-10-13.md)。

> 历史基础设施修复：2026-10-13 修复 main 自动签名/目标执行与正式验收 HEAD 循环；签名/目标检查改为手动冻结候选，正式入口显式选 SHA。公共工作流/校验器功能输入变化后，旧四消费者 READY 撤回为 NOT_ASSESSED，原回执保留。仅文档/证据后续提交不改变已选候选，不自动接受新 HEAD。见[修复报告](./audit/Frozen-candidate-workflow-2026-10-13.md)。

> 历史工程快照（BFF-FE-005，本次基础设施修复前）：2026-10-13 BFF-FE-005 本地 DEVELOPMENT READY；冻结 ac4a8dc4 完整 42 节点 / 139 组 PASS，A2/R1-SERVICE/BFF003/BFF005 四消费者回执均同源复评 READY。PROVIDER:A3 未授予 READY；外部/性能 RELEASE NOT_RUN，formalAccepted=false。见[本轮报告](./audit/BFF-FE-005-development-2026-10-13.md)。

> 历史 A3 前置回执复评（2026-10-12）：A2 与 R1-SERVICE 均 NOT_ASSESSED；TP01-D 旧 READY 因当前功能输入漂移撤回。当前全图 0 READY / 158 NOT_ASSESSED / 1 BLOCKED（BFF-FE-003）；外部环境/性能为 RELEASE NOT_RUN，未自行批准。见[复评与前端发布移交](./audit/A3-prerequisites-and-frontend-release-handoffs-2026-10-12.md)。

> TP01-D_LOCAL 历史复验（2026-10-12）：冻结4fe846ef完整执行16节点/54组必要本地检查全部PASS；仅TP01-D限定DEVELOPMENT READY，全图1 READY/158 NOT_ASSESSED/0 BLOCKED。旧TP01-C本地READY因公共输入变化撤回，历史回执和失败保留。14组目标/远程检查及外部环境/性能移交RELEASE-GATE:BETA，formalAccepted=false。见[完成报告](./audit/TP01-D-local-admission-2026-10-12.md)及[本地规程](./operations/tp01-d-local-admission.md)。

> 历史 TP01-C_LOCAL 复验（2026-10-12）：冻结bacc3b60完成13节点/45组必要本地检查及递归内容验证，全部PASS；仅TP01-C限定DEVELOPMENT READY，全图1 READY/158 NOT_ASSESSED/0 BLOCKED。原5个限定本地READY因公共输入变化撤回，历史证据保留。12组目标/远程治理检查及外部环境/性能由测试和RELEASE-GATE:BETA验收，formalAccepted=false。见[完成报告](./audit/TP01-C-local-admission-2026-10-12.md)及[本地规程](./operations/tp01-c-local-admission.md)。

> 历史本地复验（2026-10-12）：冻结76789443完成17节点/56组本地必要前置及R03七组PASS；F0/TP03/TP04/R03本地READY，R04实施admission READY、完成NOT_ASSESSED。全图4 READY/155 NOT_ASSESSED/0 BLOCKED；13组Supabase目标与后续22任务/16检查点外部环境和性能移交测试/最终发布，formalAccepted=false。见[当前报告](./audit/local-development-gates-and-handoffs-2026-10-12.md)。

> 历史严格复评（F06/F07/F09目标诊断，2026-10-12）：冻结e4c45a7c完成14节点/56组实际复验，46 PASS、10 FAIL（本地45/45、目标1/11）。F09收尾/超时缺陷已修复，F06/F07/F09只读前置明确拒绝；平台Auth服务与真实调度写入仍未恢复验收。严格F0/TP03/TP04为BLOCKED；全图0 READY、156 NOT_ASSESSED、3 BLOCKED，formalAccepted=false。见[本轮报告](./audit/F0-target-failures-remediation-2026-10-12.md)。

> 历史工程快照（R03本地开发Gate，2026-10-11）：冻结b2511e1d完成15节点/49组本地前置与R03七组实际复验，R03 DEVELOPMENT READY（R03_LOCAL）；全图1 READY、158 NOT_ASSESSED、0 BLOCKED。13组Supabase前置及R03真实生命周期移交RELEASE-GATE:BETA，NOT RUN。原只读/失败/退役pending=0历史保留；用户工程确认、同SHA CI及发布独立。见[本轮报告](./audit/R03-local-gate-policy-2026-10-11.md)。

> 历史工程快照（R03，2026-10-11）：冻结0819addc的研究编排与持久Artifact限定工程验证PASS，取消230/621ms、独立进程恢复通过；旧功能输入变化后撤销失效开发Gate，R03 BLOCKED。R02历史来源授权到期，合成目标证据不能替代真实来源准入；正式/CI/发布独立。见[本轮报告](./audit/R03-development-2026-10-11.md)。

> 上轮工程快照（TP09，2026-10-11）：冻结fbb5775e完成TP09/TP03/F08/F05/F0必要14节点、56组实际功能复评与严格内容校验；14 DEVELOPMENT READY、145 NOT_ASSESSED、0 BLOCKED。正式用户确认、同SHA hosted CI、发布独立。见[本轮报告](./audit/TP09-development-2026-10-11.md)。

> 先行准入快照（TP03，2026-10-11）：冻结13c4096f完成TP03/F08/F05/F0必要13节点、原53组52PASS/1连接重置FAIL，同源完整补测PASS，53有效组与严格内容校验；13 DEVELOPMENT READY、146 NOT_ASSESSED、0 BLOCKED。正式用户确认、同SHA hosted CI、发布独立。见[本轮报告](./audit/TP03-readmission-2026-10-11.md)。

> 上轮工程快照（TP11，2026-10-11）：先行TP05已刷新；冻结05d3b78f完成TP11/TP05/F0必要14节点、原56组55PASS/1超时FAIL及同源完整补测PASS，并通过严格组合递归内容校验；14 DEVELOPMENT READY、145 NOT_ASSESSED、0 BLOCKED。限定reference_only，无真实数据或上游运行时准入；正式/hosted CI/部署/发布独立。见[TP11报告](./audit/TP11-development-2026-10-11.md)。

> 先行准入快照（TP05，2026-10-11）：冻结ddae9d52完成TP05/F08/F0必要13节点、53组实测与严格内容准入；13 READY、146 NOT_ASSESSED、0 BLOCKED，正式/hosted CI/生产发布独立。见[TP05刷新报告](./audit/TP05-readmission-2026-10-11.md)。

> 上轮工程快照（TP10，2026-10-11）：冻结8fbedfe8完成TP10/F08/F0必要13节点、53组实际功能复评，严格DEVELOPMENT READY；当前13 READY、146 NOT_ASSESSED、0 BLOCKED。限定IA评估，无上游源码/运行时；正式、UI实现与发布独立。见[TP10报告](./audit/TP10-development-2026-10-11.md)。

> 上轮工程快照（2026-10-10）：冻结4875b140完成TP05/F05/F08/F0必要13节点、53组实际功能复评与严格内容校验；13 DEVELOPMENT READY、146 NOT_ASSESSED、0 BLOCKED。TP02/TP03/TP04等旧Gate本轮未重授，正式/hosted CI/发布独立。见[本轮报告](./audit/TP05-development-2026-10-10.md)。

> 上轮工程快照（TP03，2026-10-10）：冻结3ab1df6完成TP03/F08/F05/F0必要13节点、53组实际功能复评及严格内容校验；13 DEVELOPMENT READY、146 NOT_ASSESSED、0 BLOCKED。TP02/TP01-C/D/R01/R02旧Gate本轮未重授，正式/hosted CI/发布独立。见[本轮报告](./audit/TP03-development-2026-10-10.md)。

> 上轮工程快照（2026-10-09）：冻结c3f86f5完成TP02与F08/F0必要13节点、53组实际功能检查及严格内容校验，13 DEVELOPMENT READY、146 NOT_ASSESSED、0 BLOCKED。旧TP01-C/D、R01/R02未在本轮重新准入；正式确认、hosted CI和发布独立，见[本轮报告](./audit/TP02-development-2026-10-09.md)。

> 迁移时历史快照：2026-10-07 第二轮执行文档整理：8 份 P0/A1 验收规程及 R01/R02/UI 交付记录保留迁入 `docs/execution/`，同步活动引用与 R01/R02 读取路径；阶段准入与当前 G0 PENDING 状态保持不变。见[整理报告](./audit/Execution-document-organization-round2-2026-10-07.md)。

> 迁移时历史快照：2026-10-07 执行文档目录整理：25 份 BFF/PRE/Desktop 准备产物保留并迁入 `docs/execution/`；读取脚本及输入策略已同步。原 26 READY 和 `52fee5f6e499` 确认为迁移前历史记录，当前受影响功能准入均为 NOT_ASSESSED，需独立内容复评。见[整理报告](./audit/Execution-document-organization-2026-10-07.md)。

> 迁移前历史快照：2026-10-07 PROVIDER:A2 再复核完成：原四项问题全部关闭，当前活动问题0、24/24控制点PASS、26/26 API证据完整；26 READY、0 BLOCKED，G0范围52fee5f6e499已确认。64acc87的9项工程工作流及Dependency Graph共10/10成功；后续文档提交的hosted CI独立核验。见[当前复核报告](./audit/PROVIDER-A2-comprehensive-review-2026-10-07.md)。

# SumAlpha QuantOS 前端开发执行计划

> 历史快照（47cb743 CI 修复前）：2026-10-07 PROVIDER:A2 整改复验完成：原 4 项问题全部关闭，24/24 控制点 PASS；F0/A1 87/87、G0 16/16、FEP-0 2/2 工程通过，A2 聚合门禁严格 READY。当前 26 READY、0 BLOCKED；当前 G0 范围 b2fd984536e0 已由项目用户确认，G0/FEP-0 严格 READY。原问题、失败尝试及旧确认完整保留，hosted CI/RELEASE 独立验收。见[当前报告](./audit/PROVIDER-A2-comprehensive-review-2026-10-07.md)。

> 历史快照（本轮整改前）：2026-10-07 旧 READY 复评完成：F0/A1 87/87、G0 16/16、FEP-0 2/2 工程检查通过；项目用户已确认当前 G0 文稿，确认后 FEP-0 2/2 实际重评通过；当前 25 READY、0 BLOCKED。历史正式/hosted CI 不迁移。见[复评报告](./audit/Core-plan-READY-reassessment-2026-10-07.md)。

> 2026-10-07 BFF-FE-007 再次复核通过：活动问题 0，31/31 控制点 PASS，严格 DEVELOPMENT READY。当前报告已移除已关闭问题明细和整改过程，保留历史归档及当前有效证据。


> 版本：3.80
> 更新时间：2026-10-14
> 状态：R1/A2/BFF003/BFF005/A3与TP02限定本地DEVELOPMENT READY；正式/目标/发布未执行。
> 依据：[网站与终端设计方案](./SumAlpha-QuantOS-Web-and-Terminal-Design.md)、[Terminal 全量前端页面设计规格](./SumAlpha-QuantOS-Terminal-Frontend-Design-Spec.md)、[QuantOS 可执行开发计划](./SumAlpha-QuantOS-Development-Plan.md)  
> 目标：第一期交付官网与 `app.sumalpha.ai` Web Terminal；在页面、字段、请求响应、权限、实时流、风险审批、订单与审计链路上与后端保持可验证的一致性。第二期 Desktop 范围见[独立执行计划](./SumAlpha-QuantOS-Desktop-Development-Execution-Plan.md)。

## 版本变更说明

- `3.80`：2026-10-14从5fa0fb04完整复验42节点/141组，共源恢复R1/A2/BFF003/BFF005/A3并重新绑定TP02；保留旧失败与canonical归档，外部/性能/正式接受仍独立。见[复验报告](./audit/PROVIDER-A3-readmission-2026-10-14.md)。

- `3.79`：建立 A3_LOCAL 聚合回执和五回执事务发布；复评当前源码完整闭包，绑定直接消费者回执同 SHA、哈希与严格内容证明。见[本地验收规程](./operations/provider-a3-local-admission.md)。

- `3.78`：组件 CI 与手动候选签名/目标检查分离；正式校验显式选择冻结 SHA，文档/证据记录不追逐 HEAD；旧功能回执保留并撤回受影响 READY。

- `3.77`：完成 BFF-FE-005 C12 七操作与当前源全闭包；42 节点 / 139 组 PASS，四消费者本地 READY；PROVIDER:A3、正式/目标/性能独立。见[本轮报告](./audit/BFF-FE-005-development-2026-10-13.md)。

- `3.75`：建立并实际执行 A2/R1/BFF003 当前源码完整本地功能闭包；135 组全部 PASS，只发布三个消费者限定 READY；外部环境/性能发布移交、正式确认和 UI 集成独立。见[本轮报告](./audit/A3-local-admission-2026-10-12.md)。

- `3.74`：复评A2/R1-SERVICE前置回执；逐项登记BFF-FE-003之后全部任务和检查点的外部环境/性能发布移交，取消G8实际testnet的早期门槛；保留本机功能联调和全部原目标。

- `3.73`：R04公共校验与研究消费专用本地完成Gate；同步Beta目标验收义务，正式验收独立。

- `3.72`：实现TP03/TP04/F0独立本地开发Gate与R04实施准入，后续22任务外部环境/性能移交测试和发布；保留原严格失败证据。

- `3.71`：定位Supabase Auth数据库500和只读状态，新增写入前置拒绝、错误白名单及F09有界收尾回归；冻结新源码完整复验TP03/TP04/F0。见[本轮报告](./audit/F0-target-failures-remediation-2026-10-12.md)。

- `3.70`：修复TP04完整Python计数校验，保留失败/旧组件证据；从冻结源码复评TP03/TP04/F0必要前置，源码漂移撤销R03旧READY。见[本轮记录](./audit/TP04-python-receipt-readmission-2026-10-12.md)。

- `3.69`：R03限定本地功能准入与Supabase最终发布验收分离；功能/取消/恢复/权限/质量要求保留，LOCAL_READY不授予上游数据库READY；历史失败与32事实限时用途保留。见[范围调整](./audit/R03-local-gate-policy-2026-10-11.md)。

- `3.68`：开发Supabase平台超限/磁盘压力确认；精确退役本轮100任务和1工具，独立读回pending=0、32事实hash不变；普通新连接写入25006，待平台容量恢复后完整复验。R03 Gate仍BLOCKED。见[恢复报告](./audit/R03-supabase-recovery-2026-10-11.md)。

- `3.67`：R02保留32事实限时用途独立确认；当前前置53 PASS/5 FAIL/2 NOT RUN，开发Supabase只读使F07和fixture收尾阻塞；R03新工程目标PASS、admission实际拒绝，Gate BLOCKED。见[当前报告](./audit/R03-prerequisite-readmission-2026-10-11.md)。

- `3.66`：TP09当前必要闭包刷新，14节点/56实际命令组PASS，严格DEVELOPMENT READY；工程和正式/发布验收独立。见[本轮报告](./audit/TP09-development-2026-10-11.md)。
- `3.65`：TP03当前必要闭包刷新，13节点/53实际命令组PASS，严格DEVELOPMENT READY；工程和正式/发布验收独立。见[本轮报告](./audit/TP03-readmission-2026-10-11.md)。
- `3.64`：TP11 OpenStock限定评估、两份自有DataSnapshot映射及独立widget拒绝、真实字节血缘/质量/F05 Gate与生产排除；必要14节点/56有效组（原55PASS/1超时FAIL、同源完整补测PASS）并严格DEVELOPMENT READY。真实数据/运行时、正式和发布独立。见[TP11报告](./audit/TP11-development-2026-10-11.md)。

- `3.63`：先行刷新TP05当前开发准入；修复旧Python总数等值检查，完整13节点/53组实测与严格内容校验PASS，正式与生产独立。见[TP05刷新报告](./audit/TP05-readmission-2026-10-11.md)。

- `3.62`：TP10 ValueCell限定信息架构评估刷新，12项来源分级与可验设计锚点、5项设计后续、10项ADR差异、源码/运行时排除；功能输入变化后原回执全部转NOT_ASSESSED，必要F0/TP10闭包13节点/53组实际PASS，严格DEVELOPMENT READY；12项补充UI源结构只读审阅单独绑定。正式/页面/发布独立。见 [TP10报告](./audit/TP10-development-2026-10-11.md)。

- `3.61`：TP08 固定来源重验、三项可执行离线映射与许可证/隔离边界刷新；原回执因功能输入变化全部转 NOT_ASSESSED，必要 F05/F0 闭包 13 节点/53 组实测通过，严格 DEVELOPMENT READY；正式 ACCEPTED/运行时/发布仍未授予。详见 [TP08 报告](./audit/TP08-development-2026-10-10.md)。

- `3.60`：冻结4875b140完成TP05受控数据provider、许可证与生产制品排除Gate，必要13节点/53组实际复评PASS；13 DEVELOPMENT READY、146 NOT_ASSESSED、0 BLOCKED。见[本轮报告](./audit/TP05-development-2026-10-10.md)。
- `3.59`：冻结e27d5dab完成TP04/TP03/F08/F0必要14节点、56组实际功能复评及严格内容校验；14 DEVELOPMENT READY、145 NOT_ASSESSED、0 BLOCKED，正式/hosted CI/发布独立。见[本轮报告](./audit/TP04-development-2026-10-10.md)。

- `3.58`：冻结3ab1df6完成TP03/F08/F05/F0必要13节点、53组实际功能复评及严格内容校验；13 DEVELOPMENT READY、146 NOT_ASSESSED、0 BLOCKED。TP02/TP01-C/D/R01/R02旧Gate本轮未重授，正式/hosted CI/发布独立。见[本轮报告](./audit/TP03-development-2026-10-10.md)。

- `3.57`：TP03受控Signal adapter、100条实际schema/双RPC重放、scoped Artifact/取消/deadline、独立wheel和Research UI响应桥接完成；13旧Gate撤销，必要13节点/53组实际复评待执行。见[本轮报告](./audit/TP03-development-2026-10-10.md)。

- `3.56`：同步TP02冻结c3f86f5必要13节点/53组实际开发复评与严格READY，146 NOT_ASSESSED；前端、R1整体、正式及发布范围不扩大。见[核心报告](./audit/TP02-development-2026-10-09.md)。

- `3.55`：TP02实现改变功能输入，撤销16旧Gate为NOT_ASSESSED，必要13节点/53组开发复评待执行；历史正式确认与原CI保留。见[核心报告](./audit/TP02-development-2026-10-09.md)。

- `3.54`：同步TP01-D当前16节点/62组开发闭包严格READY及143 NOT_ASSESSED，前端任务/页面/正式和发布范围保持独立；原失败与历史回执保留。见[核心报告](./audit/TP01-D-selective-absorption-2026-10-09.md)。

- `3.53`：再次逐项复核R02原13项发现，阻塞1/高危5/中危6/低危1全部CLOSED；重构[活跃报告](./audit/R02-comprehensive-review-2026-10-07.md)，原件及关闭依据独立归档。功能Gate/六类行为变异、回执与用户确认校验通过；27/27开发控制、26/28原完整范围、14 READY/145 NOT_ASSESSED保持。补充独立操作说明勘误；本轮无新数据库执行、无功能输入变化，不扩大授权或迁移发布/远程CI结论。

- `3.52`：项目用户明确确认CORE:R02当前DEVELOPMENT文稿及边界；原答复、记录时间、不可变文稿与范围摘要单独保存，人工确认和57/57工程证据严格核验PASS。当前14 DEVELOPMENT READY/145 NOT_ASSESSED不扩展，开发27/27、原完整26/28保持；发布C25/C26、新SHA远程CI、R01 B01/FA-H01及用途许可待办。原manifest正式字段与历史文稿不重写。见[确认验收报告](./audit/R02-user-confirmed-development-acceptance-2026-10-09.md)。

- `3.51`：冻结7f18b8b重新执行R02必要14节点/57组并严格验收，恢复DEVELOPMENT READY14/NOT_ASSESSED145；修复F06/F02/R02连接生命周期、F09/Engine进程监督与当前失败回执，保留全部历史轮次FAIL/提前退出及实际收尾。R02开发27/27、原完整26/28，正式确认/发布/新hosted CI分别待验。见[当前报告](./audit/R02-current-development-admission-2026-10-09.md)。

- `3.50`：归档8408122的TP01-E远程工程验证：六场景与23回归通过，严格候选阻断后摘要/原件实际上传并下载；主线8/8 push成功，F04未触发不计PASS。自然schedule及上游候选采用保持待验，不授予阶段或正式验收。见[报告](./audit/TP01-E-remote-verification-2026-10-08.md)。

- `3.49`：修复TP01-E定时任务混淆监测完成与候选同步阻断的问题，保留严格人工同步Gate；补齐失败摘要/原报告/决策上传、异常输入及严重性保留。真实上游候选仍BLOCKED；新SHA远程workflow待验证，159节点NOT_ASSESSED不变。见[整改报告](./audit/TP01-E-scheduled-remediation-2026-10-08.md)。

- `3.48`：记录41a3b27同SHA主线CI修复验收9/9 PASS及F02/F05/正式下载原始回执；全部运行10成功/1定时TP01同步阻断，不隐藏待人工决策与失败时上传缺口。本机补充payload下载超时记NOT_RUN；当前159节点NOT_ASSESSED，未授予阶段/正式/发布准入。见[验收报告](./audit/CI-41a3b27-acceptance-2026-10-08.md)。

- `3.47`：修复c6e55f6 CI同集群双库重建的共享角色重复创建，并补齐R02 API schema事务回放映射；历史迁移字节与checksum不变，权限/漂移/签名Gate保留。聚焦静态及已配置Supabase角色验证分别记账；当前159节点NOT_ASSESSED，不恢复旧准入或扩大范围。见[CI续修报告](./audit/CI-c6e55f6-remediation-2026-10-08.md)。

- `3.46`：修复c7a4d65远程CI的R02破坏测试Cargo缓存污染与PRE-03版本检查遗漏；原14份开发回执因当前输入漂移不再有效，转NOT_ASSESSED并保留全部原件。没有降低Gate或重建数据库；功能完成状态、发布移交及历史正式确认不变。见[整改报告](./audit/CI-c7a4d65-remediation-2026-10-08.md)。

- `3.45`：R02当前开发准入闭合，完整57/57实际复评通过，14节点DEVELOPMENT READY、145节点NOT_ASSESSED。R02调整后开发27/27、原完整范围26/28；C25代表性性能/C26部署与候选同SHA CI留Beta，R01 B01/FA-H01继续OPEN/PARTIAL。仅当前功能工程回执，不补写正式ACCEPTED、不迁移G0或旧hosted CI；失败历史和原批准完整保留。见[本轮报告](./audit/R02-development-admission-2026-10-08.md)。

- `3.44`：第二轮 8 份根目录文档均有用途，全部保留迁入 execution；保留业务正文、历史交付/验收状态，同步活动引用和两项检查脚本。目录合计 33 份执行产物，历史审计/回执/签署原件不重写；原 159 个 stage_gate 继续 NOT_ASSESSED，不用本轮静态验证恢复 READY。

- `3.43`：完成执行文档用途核对，25 份全部保留迁入 `docs/execution/`；同步当前计划、ADR、读取脚本、受控输入路径和字段字典生成器。历史审计/回执/确认原件不改字节，旧路径由[目录索引](./execution/README.md)定位。路径/门禁输入变化后，旧 26 READY 明确归档并清为 NOT_ASSESSED，G0 新输入确认恢复 PENDING；本次只验收迁移及相关本地回归，不冒充 Supabase 重跑、新 hosted CI 或正式验收。见[整理报告](./audit/Execution-document-organization-2026-10-07.md)。

- `3.42`：再次核验PROVIDER:A2原四项问题全部关闭；本轮127项针对性测试、11项真实证据异常探针及26个READY节点内容核验通过，20项目标源码与原提交/当前文件一致。核验64acc87 hosted CI 10/10成功（9项工程及Dependency Graph），数据库重建、签名/下载验签与A2聚合成功。当前报告移除已关闭问题及整改过程，保留初审、关闭记录和重构前原件；仅文档/证据变化，不修改功能输入、阶段回执或G0已确认范围。

- `3.41`：修复共享Storage fixture缺列；87组有效结果PASS，原86PASS/1协议I/O失败与同源完整补测分开保留，21基础回执重新发布。两BFF语义/变异及127门禁负向通过，A2严格READY；当前 26 READY、0 BLOCKED。项目用户已确认当前 G0 范围 `52fee5f6e499`，G0/FEP-0 严格 READY。 新hosted CI未执行，历史正式字段不迁移。

- `3.40`：完成 PROVIDER:A2 四项整改；逐 API 成功状态和不可变执行提交/源码校验、26 API 专用聚合 policy/manifest、递归依赖、31 项负向及强制 CI 入口生效。全依赖 87/87 实际复评通过；身份/Audit 新语义与 8/5 项变异拒绝通过，127 项门禁负向及 11 项真实原件异常探针通过。两子任务目标字节未变，复用原 51/83 次 Supabase 目标及 7/13 项内容溯源；未把原目标改记为本轮执行。当前 26 READY、0 BLOCKED；当前 G0 范围 b2fd984536e0 已由项目用户确认，G0/FEP-0 严格 READY。当前检查报告重构，初审与旧报告保留原件。

- `3.39`：再次核对 BFF-FE-007 原 9 项问题，均已解决；三组业务回归重跑通过，13 项目标源码摘要与不可变执行提交一致。当前复审报告仅保留结论、完成统计、验证依据和后续边界；历史问题与过程完整归档，任务卡同步当前有效功能回执。未修改功能源码、规范需求或 G0 已确认范围。

- `3.38`：完成核心任务格式重构引起的旧 READY 复评：F0/A1 完整 87/87、G0 16/16、FEP-0 2/2 工程检查通过，基础 21 节点及两项 BFF 当前严格 READY。身份/审计 BFF 自身功能输入未变，实际重跑本地语义/变异并核对旧目标证据的 7/13 项摘要，未将原目标调用改记为本轮执行。旧 G0 确认 `900e809c60dd` 完整归档，新 `1d2bce97fcfb` 文稿已由项目用户本会话明确确认；原答复与文稿/范围摘要已保存，确认后 FEP-0 两项实际重评通过，当前 25 READY、0 BLOCKED，历史正式和 hosted CI 不迁移。见[复评报告](./audit/Core-plan-READY-reassessment-2026-10-07.md)。

- `3.37`：项目用户明确答复“确认 G0 DEVELOPMENT 文稿”，当前范围 `900e809c60dd` 与功能输入一致；保存原答复/文稿/范围摘要，G0 核验原 16/16 工程执行后严格 READY。确认后 FEP-0 两项实际重评 PASS、八依赖及 23 节点闭包 READY；加上身份与 Audit 两项 A2 当前共 25 READY、0 BLOCKED。原 PENDING 及历史确认保留，hosted CI/RELEASE 独立。见[当前确认验收报告](./audit/G0-FEP0-user-confirmed-acceptance-2026-10-07.md)。

- `3.36`：补齐 BFF-FE-007 live 六 API、F05 主体隔离读模型、持久导出 worker/私有产物/原子一次性下载及范围、脱敏、完整性、分页、过期、consumer 与功能准入整改。原复审报告与失败尝试保留；当前源码和依赖的实际工程/目标回执已复评通过；F0/A1 的 87 个独立命令组、身份 20 API 和 Audit 六 API 通过，G0 16 项及 FEP-0 两项工程检查通过，变更后的 G0 范围待项目用户确认。见[当前报告](./audit/BFF-FE-007-comprehensive-review-2026-10-06.md)与[runtime 说明](./execution/BFF-FE-007-runtime.md)。

- `3.35`：项目用户明确确认当前 G0 文稿，原答复/文稿/范围摘要保存并核验；原 PENDING 工程回执保留，G0 严格 READY。确认后实际重评 FEP-0 两项 PASS，八依赖及其 23 节点闭包 READY，连同 A2 当前共 24 READY、0 BLOCKED。完整 87/16 项实际工程回执仍绑定原冻结源码，formal/RELEASE 独立。见[确认验收报告](./audit/G0-FEP0-user-confirmed-acceptance-2026-10-06.md)。

- `3.34`：核验已推送 `3799c4c` 的 9/9 hosted CI 全部成功，原失败步骤、Python 129 PASS / 91.20% 覆盖、A2 离线语义与构建下载验签实际通过，CI 整改技术验收闭环。既有完整 87/87 工程回执按当前内容核验有效；22 READY、2 BLOCKED（G0 当前范围确认），formal/RELEASE 独立。见[验收报告](./audit/CI-3799c4c-acceptance-2026-10-06.md)。

- `3.33`：修复 5da474e 的上游 Python lint 扫描和 A2 离线 Rust 缺少依赖预取，补齐失败日志归档及 pytest 归属边界；完整 87/87、G0 16/16、FEP-0 2/2 工程 PASS，A2 当前内容 READY。22 READY、2 BLOCKED（当前 G0 用户确认待办），历史原件保留，未推送、新 hosted CI 待验证。见[整改报告](./audit/CI-5da474e-remediation-2026-10-06.md)。

- `3.32`：修复 e0e9cbc 的子模块未检出及 RLS DO/FOREACH 静态识别错误，并升级 source-map-js 1.2.2 修复本轮新发现的 SCA 漏洞；固定 pin、迁移 SQL 与权限不变。冻结 `14bf36c` 完整 F0/A1 87/87、G0 16/16、FEP-0 2/2 工程 PASS；A2 本地及内容门禁 READY，已有正常目标七项摘要一致。当前 22 READY，G0/FEP-0 新范围用户确认仍 BLOCKED；历史原件保留，未推送、最新 hosted CI NOT_RUN、formal/RELEASE 不迁移。见[整改报告](./audit/CI-e0e9cbc-remediation-2026-10-06.md)。

- `3.31`：修复 f764bc6 的五类 CI 故障；冻结源码 `02f26c0` 完整执行 F0/A1 86/86 PASS、21 READY，G0 16/16 和 FEP-0 2/2 工程 PASS。A2 新 Supabase 正常目标 51 次调用覆盖 20 API、14 强断言且恢复通过，目标七项源码摘要与当前一致；本地正负/mutation 回归及严格内容门禁 READY。当前共 22 READY，G0/FEP-0 新范围确认待办为 BLOCKED；历史用户批准、原失败和旧目标回执保留，hosted CI 未推送执行，formal/RELEASE 不迁移。见[CI 整改报告](./audit/CI-f764bc6-remediation-2026-10-05.md)。

- `3.30`：在 `f2283fa` 逐项复核 BFF-FE-001 原 2 高危、4 中危均已关闭；当前活动问题为 0，24/24 控制点及 20/20 API 满足，严格 DEVELOPMENT 门禁 READY。重新执行聚焦语义、8 项 mutation、22 项契约负向、14 项阶段正负与 transport 检查；既有 Supabase 目标证据按内容核验，本轮未重跑目标测试。主报告整理为[当前结论](./audit/BFF-FE-001-comprehensive-review-2026-10-05.md)，[历史发现](./audit/BFF-FE-001-findings-archive-2026-10-05.md)与[关闭依据](./audit/BFF-FE-001-closed-findings-2026-10-05.md)独立归档。

- `3.29`：在 `72d12b0` 再次核验 FEP-0 原 2 个阻塞项均已关闭；5 项当前门禁、141 项专项回归、12 项独立反证通过，161 份证据摘要一致，20/20 控制点、8/8 直接依赖、23/23 闭包节点 READY。主报告整理为[当前结论](./audit/FEP-0-comprehensive-review-2026-10-05.md)，原始发现及关闭依据独立归档。本轮未重跑完整工程或 Supabase，既有功能回执和用户确认保持有效。

- `3.28`：项目用户确认 G0 当前文稿（范围 `9630623790b8`），原始答复与文稿/范围摘要绑定；保留原 pending 工程 manifest。严格 G0 READY 核验通过，在文档提交 `a805b50` 实际重评 FEP-0 两项并消费八个 READY 依赖，FEP-0 DEVELOPMENT READY、20/20 控制点、23/23 闭包节点 READY。86/16 项工程执行仍准确绑定冻结源码 `04229ce`，没有冒充新 SHA 正式验收；发布要求继续独立。见[最终整改复验报告](./audit/FEP-0-remediation-2026-10-05.md)。

- `3.27`：FEP-0 整改在冻结源码 `04229ce` 完整执行 86/86 F0/A1 检查并刷新 21 个 READY；G0 16/16 和 FEP-0 2/2 工程通过，独立内容校验及 CI 接线生效。当前 G0 用户确认尚缺，G0/FEP-0 保持 BLOCKED，控制点 18 PASS/2 PENDING，八直接依赖 7 READY/1 BLOCKED；原失败轮、旧用户确认和正式回执全部保留。见[整改复验报告](./audit/FEP-0-remediation-2026-10-05.md)。

- `3.26`：按 FEP-0 初审补齐 F0 六项当前功能验收、F0 聚合与 FEP-0 独立内容校验/CI。新增脚本改变旧功能清单，保留原证据并重评；G0 旧用户确认保留原件，更新范围需确认新文稿。当前结论以 stage_gate 和[整改报告](./audit/FEP-0-remediation-2026-10-05.md)为准，正式字段不自动迁移。

- `3.25`：再次复核 G0 原 1 阻塞、4 中危全部关闭；137 项专项回归、11 项独立反证及当前功能回执核验通过，24/24 控制点满足。主报告整理为[当前结论](./audit/FRONTEND-GATE-G0-comprehensive-review-2026-10-05.md)，历史发现与关闭依据独立归档；G0 保持 DEVELOPMENT READY，既有 65/16 项工程证据内容有效，本轮未重跑 Supabase。

- `3.24`：项目用户明确确认当前 G0 DEVELOPMENT 文稿，原答复与不可变文稿/范围摘要绑定保存。确认提交 `92dddbd` 上重新执行 65/65 上游及 16/16 G0 检查，14 个上游节点及 G0 READY，24/24 控制点满足；原 5 项 G0 问题关闭。见[用户确认验收报告](./audit/FRONTEND-GATE-G0-user-confirmed-acceptance-2026-10-05.md)。继续 A2/API；新页面仍须 PROVIDER:ALL，历史正式字段/RELEASE 不自动通过。

- `3.23`：按用户要求，所有原六方/多角色验收确认改为 Codex 拟定文稿、项目用户一人确认；角色保留为审阅维度，旧签署/测试保留历史。统一规程覆盖 G0–G8、provider 最终评审、RELEASE 与 Desktop；变更后的范围/校验器输入须复评，不把流程授权视为 G0 文稿确认。

- `3.22`：G0 工程整改增加内容绑定功能清单、PoC 执行日志、生产 BFF 导入边界和遗留子项阶段治理，PRE-01 同步 API 1.5.0。当前六方 DEVELOPMENT 范围确认暂缺，G0 保持 BLOCKED；正式 staging/签署仍按 RELEASE 验收。上游变更后回执独立复验，历史证据保留。本轮 65 项上游与 16 项 G0 实际执行通过，控制点 23/24；见[G0 整改复验报告](./audit/FRONTEND-GATE-G0-remediation-2026-10-05.md)。

- `3.21`：P0 原 3 项发现再次核验关闭；当前 P0 及 11 个功能前置证据有效，七项契约执行反证均拒绝。报告与规程对齐 DEVELOPMENT 输入摘要准入，保留历史 formal 回执；当前 HEAD 未重新取得正式同 SHA 回执，本轮未执行数据库。

- `3.20`：独立复核 PROVIDER:A1 原 6 项发现全部关闭；活跃报告整理为当前状态，原始问题与失败记录归档。重新执行 Rust/HTTP、业务 mutation、数据库执行状态和回执回归，14 节点功能证据仍有效；本轮未重跑 Supabase，不改写 formal 验收状态。

- `3.19`：关闭 PROVIDER:A1 原 6 项发现；65 项完整功能检查当前有效结果全部通过，自底向上登记 14 节点 READY。包括独立三轮构建、实际覆盖率、Supabase 1 万事件/并发/Storage/RLS/F06；原完整轮与同源聚焦复验分开保留。历史 formal 字段/notes 不迁移，G0、PROVIDER:ALL、RELEASE 不自动放行。

- `3.18`：重新核对 BFF-FE-000 原 14 项发现，13 项工程问题关闭，B-01 维持最终 RELEASE 评审待办；活跃报告精简并归档历史发现，任务卡/总结同步 API 1.5.0 / 52 schemas。当前 P0 同 SHA 回执未在本轮重验，不改变阶段 READY 或正式 ACCEPTED。

- `3.17`：统一 DEVELOPMENT 功能开发、INTEGRATION 功能联调、RELEASE 发布前验收。保留全部任务、依赖、业务指标和历史状态；增加独立 `stage_gate` 记录。全量 API 功能准入后推进页面开发，G0–G8 按各窗口功能范围评估；性能、长稳、部署/staging、远程同 SHA CI 与发布签署集中到 RELEASE-GATE:BETA 及核心 LIVE-READINESS。所有新增阶段记录为 NOT_ASSESSED，本次规划调整不产生验收通过。

以下版本条目是历史决策记录；当前阶段归属以 3.74、第 2.1/2.3 节及各检查点为准。

- `3.16`：按用户要求将 B-01 的真实 staging 验收移至 A1 最后评审（RE_REVIEW → ACCEPTED 前）；开发阶段只运行工程基线检查，staging 待执行不阻塞开发完成或 REVIEW_READY。保留最终目标证据、联合签署和正式检查点；其他阶段要求不变。

- `3.15`：按 BFF-FE-000 独立复审修正同源生成、SSE、安全输入、兼容性、语义门禁、mock/provider harness 与文档基线；工程复验与目标 staging/签署分别记账，PROVIDER:A1/G0 尚未关闭。

- `3.14`：P0 三项问题关闭，16/16 控制点通过；登记修复提交的真实 Supabase F06 与 P0 联合回执，仅放行 A1。文档提交后的新 HEAD 仍须取得自身 Git notes 回执。

- `3.13`：P0新增独立同SHA验收回执门禁，契约测试加入实际断言计数；目标验收完成后记录A1准入，Git notes承载提交后回执以避免自引用。
- `3.12`：PRE-06 再复核补齐跳过测试组、非执行分支和未等待截图断言的拒绝机制；当前结论绑定独立重放，原整改证据保留。
- `3.11`：PRE-06 修复9项复审问题，冻结fixture集合与关键分支100%门禁，补齐macOS视觉矩阵及两应用性能/CI失败证据；工程验证与正式目标/G0签署分开记录。
- `3.10`：PRE-05 再复核补齐短秘密与应用生产环境文件产物扫描，原9项问题关闭、16/16仓库控制点通过；主报告保留当前验收视图，历史发现与本轮证据独立归档。
- `3.9`：PRE-05 关闭9项环境审计问题；配置与客户端产物双层秘密检查、原值/DSN/callback/issuer约束、Next同源dotenv解析和模板身份回归纳入验收，文档明确普通dev mock与目标环境边界。

- `3.8`：PRE-04 再复验补齐后端任务全文匹配和本地实现三类证据完整性校验，38项回归通过；9/9问题关闭，主报告收敛为当前验收视图，历史记录保留。

- `3.7`：PRE-04 关闭9项审计问题；23个一期P0单元和辅助契约齐备，字段字典以受控wire/domain映射生成，Gap按published/planned准确分级；补齐32项失败关闭回归，原生接口移至二期承接。
- `3.6`：PRE-03 再复验补齐 workspace importer/链接目标检查与逐应用 `.env.local` 构建绑定；10/10 问题关闭，主报告收敛为当前验收视图并保留历史证据。
- `3.5`：PRE-03 整改对齐一期 Web 范围；前端任务不再包含指定模型复审块，校验器保留任务/依赖/顺序检查，模型状态仅作未运行边界。运行时配置、构建来源、资源和浏览器 smoke、锁一致性与负向 CI 纳入工程验收。

- `3.4`：PRE-02 再复验补齐 Storybook 配置覆盖/死分支的门禁遗漏，27 项 Gate 回归与 18 项 UI 测试通过；主报告收敛为当前验收结果，历史问题和关闭依据独立归档。指定模型与正式 G0 状态不变。

- `3.3`：PRE-02 关闭 8 项工程审计问题；冻结完整 Web token、受控译文、状态/组件身份及可执行 Storybook 配置，基础对比度扩展为 252 组。Badge 统一主题/语言与未知回退，原生参考由二期承接；指定模型与正式 G0 未据此验收。

- `3.2`：PRE-01 再复验关闭原 8 项发现；补齐 P05 元数据下载和 P21 告警订阅追踪，新增 operationId 到页面契约的负向门禁。同步一期 30 页面、132 Story、220 场景定义及当前报告入口；指定模型与正式 G0 状态不变。

- `3.1`：与核心计划v3.19协调服务准入与完整业务验收；保留P0/A1–A6全量API先行。里程碑移至实际关闭窗口末尾，补准备/provider/G0–G8检查点与跨文档依赖；G5在I6、G4在I7关闭。已有开发与复审状态不变，新增检查点均未验收。

- `3.0`：完成 A2/BFF-FE-007 仓库交付；发布 OpenAPI 1.3.0 的 Audit 搜索/证据链分页与受控导出 create/status/cancel/download 契约，增加 Rust 本地参考 provider、Terminal typed gateway、可破坏 Gate 及验收证据。真实 Postgres 审计读模型、对象存储签名 URL、staging 消费者/provider 签署与 GPT-6 Astra 复审仍为独立未执行项。
- `2.9`：完成 A2/BFF-FE-001 仓库交付；发布 OpenAPI 1.2.0 的 cookie session、CSRF、recent-auth、MFA 因素保护与 auditRef 契约，增加 Rust 本地参考 provider、撤销 SSE、前端 client 与可破坏 Gate。真实 IdP/Postgres、staging 消费者/provider 签署、GitHub CI 与 GPT-6 Astra 复审仍为独立未执行项。
- `2.8`：完成 A1/BFF-FE-000 仓库交付；冻结 C01–C17、一期 22 页的 published/planned operationId catalog，补齐 sort/filter、ETag、错误 correlation header 基线，并将依赖、生成漂移、页面追踪、CI 接线和负向破坏检查纳入可重放 Gate。A2–A6 provider 实现、staging 回执与 GPT-6 Astra 复审未据此提前完成。
- `2.7`：PRE-06 按 Web-only 边界完成当前仓库复核；将 Terminal 与官网的 Chromium/Firefox/WebKit、axe、真实入库视觉基线完整性、性能预算、BFF 1.1.0 contract fixture 与可破坏 Gate 接入 CI；Desktop 原生/深链测试迁至二期手动 workflow。本地 macOS 浏览器验收不代表 GitHub Actions、Linux 视觉或 staging 已运行。
- `2.6`：PRE-05 按 Web-only 边界完成当前仓库复核；冻结 local-mock、local-integrated、staging 三套 profile，将公开变量 allowlist、URL/callback、环境/mode、secret 负向扫描接入官网与 Terminal 的构建期 fail-fast，并从一期 Gate 排除 Desktop 环境。仓库 Gate 完成不代表 staging 基础设施或账号已配置。
- `2.5`：产品阶段调整为第一期仅交付 Web；迁出 Tauri、P16、桌面环境、原生测试、签名更新与 Desktop Gate 至独立第二期计划。第一期保留浏览器平台能力 P17 和 C17 Web 契约，不以已有桌面 PoC 扩大一期范围。
- `2.4`：PRE-04 接口盘点完成当前仓库复核；同步 BFF OpenAPI 1.1.0、55 operations、41 schemas 与 Proto 38 messages/15 enums 的实际基线，以 PRE-01 动态 P0 页面集合校验 C01–C17、GAP-01–17、144 行字段字典、owner 和 mock 状态，并新增六类可破坏 Gate。开发状态与接口实现状态、GPT-6 Astra 复审状态继续分开记录。
- `2.3`：PRE-03 技术栈落地完成当前仓库复核；固定 Node 24.12.0，按实际锁文件校验前端依赖，强化构建路由的可破坏 Gate，并以隔离环境重放 bootstrap/build/test。开发状态与 GPT-6 Astra 复审状态继续分开记录。
- `2.2`：PRE-02 设计系统预研完成当前仓库复核；强化 token/状态映射、36 组 WCAG 对比度、18 条规范安全文案、组件清单和 Storybook 骨架的可破坏 Gate。开发状态与 GPT-6 Astra 复审状态继续分开记录。
- `2.1`：PRE-01 需求拆解完成当前仓库复核；官网七页由聚合七态改为逐页七态，新增可执行的页面/Story/权限/场景/追踪完整性 Gate。开发状态与 GPT-6 Astra 复审状态继续分开记录。
- `2.0`：页面 API 与前端功能独立排期；先完成全量页面 API 开发与 provider 验证，再依业务依赖推进前端。FEP/Gate、UI、WEB、PRE、BFF-FE 与 C01–C17 标识保持稳定；P16 自 2.5 起迁入第二期。
- FEP-1 及 UI-101–UI-104、WEB-101 标记已开发完成，保留集成晋级条件，清除历史复验证据；为 GPT-6 Astra 设置全新复审入口。
- 核心计划继续采用[核心计划字段约定](./SumAlpha-QuantOS-Development-Plan.md#plan-review-schema) `quantos-plan-review/v1`；一期前端任务采用 `quantos-web-task/v1`，不包含指定模型复审字段，工程检查结果存于任务链接的审计报告。校验：`node scripts/check-development-plans.mjs`；结构通过不等于 Codex 平台加载、模型调用或真实联调验收通过。

## 1. 执行原则、范围与当前基线

### 1.1 不可变原则

1. 第一期只交付 Web；业务实现集中在 `apps/terminal`、领域组件、BFF client、路由和权限判断，不引入原生平台分支。
2. 浏览器只访问 Gateway/BFF，不直连 Supabase 数据库、Realtime 原始表、NATS、Engine、Execution Gateway 或 venue。
3. 服务端是领域状态、权限、capability、mode、数据时效与风险结论的唯一权威；前端只保留查询缓存、布局、偏好和未提交草稿。
4. `TradeProposal` 永远显示为“不可执行建议”；前端不得创建或修改 `RiskDecision`、拼装 `TradeCommand`、持有交易密钥或乐观展示订单成功。
5. 当前交付仅覆盖单主租户、单主工作区、单优先 venue、Research/Paper/Shadow。Assisted Live 只做 M5 testnet 评审准备，必须由服务端 flag/capability 放行；Guarded Live 不进入本计划。
6. 所有写操作必须幂等、可追踪、可审计；高风险动作必须执行“刷新对象版本与可操作性 → 必要的 MFA/审批 → 服务端最终校验 → 展示 correlation ID”。

### 1.2 交付范围

| 产品面 | 本计划交付 | 不交付 |
|---|---|---|
| 官网 | 首页、产品、架构与安全、使用场景、文档、访问申请、登录；后续补开发者与状态页 | 收益宣传、公众投资推荐、社区/跟单 |
| Terminal Web | P01–P15、P17–P23 全部页面与全局状态 | P16、原生平台能力、移动端高风险操作、浏览器内回测/任意脚本 |
| 模式 | Research、Paper、Shadow；M5 testnet 条件入口 | 默认生产实盘、Guarded Live |

### 1.3 工程基线与实施要求

`apps/website`、`apps/terminal`、`packages/ui`、`packages/domain-ui`、`packages/api-client` 承载第一期 Web 应用；QuantOS TypeScript Protobuf 类型和 U01/S04/X06/L03 场景测试继续作为契约与场景输入。目标运行时、设计系统、查询/表格/图表/表单、i18n、MSW、Storybook 与真实 BFF HTTP transport 按第 2 节实施。`InMemory*Backend` 只能作为场景 fixture，不能作为生产接口契约。

先冻结 OpenAPI/BFF 页面契约、建立真实应用运行时，并把已有 fixture 转成由同一 schema 驱动的 mock。FEP-1 的开发状态见第 4.2 节，不将初始工程骨架描述当作当前完成度结论。

### 1.4 设计稿与页面 API 覆盖要求

1. `design/` 中除 P16 外的 22 组高保真设计稿均须形成实际 React Web 页面；`UI-VIS-000`、`UI-P01`–`UI-P15`、`UI-P17`–`UI-P23` 是第 4.2 节可独立关闭的交付子任务。P16 迁入第二期计划。
2. F03、F06、F07、R01–R04、S01–S04、X01–X06、L01–L03 的服务能力与安全时序不能替代页面级 BFF HTTP 路径、method、响应 envelope、分页、异步任务与实时订阅 OpenAPI。
3. C01–C17 逻辑契约通过第 4.1 节 `BFF-FE-000`–`BFF-FE-011` 转为可生成客户端的版本化 OpenAPI，覆盖页面聚合、设置、报告、告警、运维治理与平台能力。
4. 同 schema MSW 仅支持 `UI Complete`；契约达到 `Implemented`，并在获准工程联调环境以真实 BFF/服务验证权限、实时、错误、审计与 provider/consumer contract 后方可 `Integrated`。发布前另取 staging/部署环境回执。页面自定义 DTO、静态 JSON 或 `InMemory*Backend` 不得替代接口交付。新增页面仍须满足第 4 节全量 API 的功能准入。

## 2. 技术栈与工程决策

以下选型继承两份设计文档，并在阶段 FEP-0 通过 ADR 锁定版本；没有 ADR 不得替换核心框架。

| 层 | 选型 | 执行约束 |
|---|---|---|
| 官网 | Next.js App Router + React + TypeScript | SSG/SSR、SEO、内容安全、访问申请；与 Terminal 分应用构建 |
| Terminal Web | Next.js App Router + React + TypeScript | 业务路由全部 `noindex, nofollow`；第一期不包含原生壳与本地平台能力 |
| 样式与无障碍 | Tailwind CSS + Radix UI + QuantOS Design System | token 集中管理；状态必须有文字、图标、语义色和读屏标签 |
| 服务端状态 | TanStack Query | 统一 query key、缓存、失效、重试和实时投影合并；领域真相不进 Zustand |
| 本地 UI 状态 | Zustand | 仅布局、抽屉、筛选偏好和未提交草稿；交易命令和权限禁止持久化 |
| 表格 | TanStack Table + TanStack Virtual | 服务端分页/筛选/排序；URL 同步；大列表虚拟化 |
| 图表 | ECharts + Lightweight Charts | 风险/P&L/归因使用 ECharts；OHLCV/K 线使用 Lightweight Charts |
| 表单 | React Hook Form + Zod | Zod schema 优先从 OpenAPI/领域 schema 生成或薄封装；服务端校验仍为准 |
| 国际化 | next-intl | 首发中英文；时间、币种、数字格式统一；安全文案不可随意改写 |
| 契约 | OpenAPI + 生成式 TypeScript client；Proto/JSON Schema 为领域事实来源 | 禁止页面手写重复 DTO；Buf breaking 与 client generation diff 进入 CI |
| 实时 | SSE 为任务/事件流默认方案，WebSocket 仅用于确需双向或聚合频道的场景 | 必须支持游标续传、乱序/重复去重、断线回补和权限变更断开 |
| 测试 | Vitest + React Testing Library + MSW + Playwright + axe + 视觉回归 | fixture 固定 clock/ID；覆盖目标 Web 浏览器 |
| 组件文档 | Storybook | 覆盖默认、加载、空、错误、无权、陈旧、离线、危险确认状态 |
| 观测 | Sentry/OTel Web SDK（按隐私策略启用） | 错误含 correlation ID；token、密钥、完整敏感载荷不得上报 |
| 包管理/构建 | 现有 pnpm workspace；Next.js 构建 | 锁文件、Node/pnpm 版本固定；Web 制品生成 manifest 与 SBOM |

### 2.1 统一阶段与依赖消费规则

```json
{
  "schema": "quantos-plan-stages/v1",
  "dependency_basis": "stage_gate",
  "early_required": [
    "contracts",
    "data-integrity",
    "authorization",
    "idempotency-recovery",
    "deadline-semantics"
  ],
  "release_required": [
    "performance",
    "soak",
    "deployment",
    "same-sha-ci",
    "release-authorization",
    "r03-supabase-target-acceptance",
    "supabase-target-acceptance",
    "external-environment-acceptance"
  ],
  "release_checkpoints": [
    "RELEASE-GATE:BETA",
    "RELEASE-GATE:LIVE-READINESS"
  ],
  "local_dependency_receipts": {
    "CORE:R03": {
      "profile": "R03_LOCAL",
      "schema": "quantos-r03-development/v2",
      "manifest": "audit/evidence/r03-20261011/manifest.json",
      "prerequisites": [
        "CORE:F07",
        "CORE:F08",
        "CORE:R02",
        "CORE:TP02",
        "CORE-GATE:F0"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE-GATE:F0": {
      "profile": "R04_LOCAL",
      "schema": "quantos-local-development/v1",
      "manifest": "audit/evidence/local-development-20261012/core-gate-f0.json",
      "prerequisites": [
        "CORE:F01",
        "CORE:F02",
        "CORE:F03",
        "CORE:F04",
        "CORE:F05",
        "CORE:F06",
        "CORE:F07",
        "CORE:F08",
        "CORE:F09",
        "CORE:TP01-A",
        "CORE:TP01-B"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE:TP03": {
      "profile": "R04_LOCAL",
      "schema": "quantos-local-development/v1",
      "manifest": "audit/evidence/local-development-20261012/core-tp03.json",
      "prerequisites": [
        "CORE:F08",
        "CORE:F05",
        "CORE-GATE:F0"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE:TP04": {
      "profile": "R04_LOCAL",
      "schema": "quantos-local-development/v1",
      "manifest": "audit/evidence/local-development-20261012/core-tp04.json",
      "prerequisites": [
        "CORE:F08",
        "CORE:TP03",
        "CORE-GATE:F0"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE:TP01-C": {
      "profile": "TP01-C_LOCAL",
      "schema": "quantos-tp01-c-local-development/v1",
      "manifest": "audit/evidence/tp01-c-local-20261012/manifest.json",
      "prerequisites": [
        "CORE:TP01-B",
        "CORE:F08",
        "CORE-GATE:F0"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE:TP01-D": {
      "profile": "TP01-D_LOCAL",
      "schema": "quantos-tp01-d-local-development/v1",
      "manifest": "audit/evidence/tp01-d-local-20261012/manifest.json",
      "prerequisites": [
        "CORE:TP01-C",
        "CORE:R02",
        "CORE-GATE:F0"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "PROVIDER:A2": {
      "profile": "A2_LOCAL",
      "schema": "quantos-research-local-admission/v1",
      "manifest": "audit/evidence/provider-a3-local-20261013/a2-local.json",
      "prerequisites": [
        "FE:BFF-FE-001",
        "FE:BFF-FE-007",
        "PROVIDER:A1"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE-GATE:R1-SERVICE": {
      "profile": "R1_LOCAL",
      "schema": "quantos-research-local-admission/v1",
      "manifest": "audit/evidence/provider-a3-local-20261013/r1-local.json",
      "prerequisites": [
        "CORE:R01",
        "CORE:R02",
        "CORE:TP01-C",
        "CORE:TP01-D",
        "CORE:TP02",
        "CORE:TP03",
        "CORE:TP04",
        "CORE:TP05",
        "CORE:TP08",
        "CORE:TP09",
        "CORE:TP10",
        "CORE:TP11",
        "CORE:R03",
        "CORE:R04"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "FE:BFF-FE-003": {
      "profile": "BFF003_LOCAL",
      "schema": "quantos-research-local-admission/v1",
      "manifest": "audit/evidence/provider-a3-local-20261013/bff003-local.json",
      "prerequisites": [
        "FE:BFF-FE-001",
        "FE:BFF-FE-007",
        "CORE:F07",
        "CORE:F08",
        "CORE:R02",
        "CORE:R03",
        "CORE:R04",
        "CORE-GATE:R1-SERVICE",
        "PROVIDER:A2"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "FE:BFF-FE-005": {
      "profile": "BFF005_LOCAL",
      "schema": "quantos-research-local-admission/v1",
      "manifest": "audit/evidence/provider-a3-local-20261013/bff005-local.json",
      "prerequisites": [
        "FE:BFF-FE-001",
        "CORE:R01",
        "CORE:R02",
        "CORE-GATE:R1-SERVICE",
        "PROVIDER:A2"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "PROVIDER:A3": {
      "profile": "A3_LOCAL",
      "schema": "quantos-research-local-admission/v1",
      "manifest": "audit/evidence/provider-a3-local-20261013/a3-local.json",
      "prerequisites": [
        "FE:BFF-FE-003",
        "FE:BFF-FE-005",
        "PROVIDER:A2"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    },
    "CORE:TP02": {
      "profile": "TP02_LOCAL",
      "schema": "quantos-tp02-local-development/v1",
      "manifest": "audit/evidence/tp02-local-20261013/manifest.json",
      "prerequisites": [
        "CORE:F08",
        "CORE-GATE:F0"
      ],
      "release_checkpoint": "RELEASE-GATE:BETA"
    }
  }
}
```

| 阶段 | 目标与准入证据 | 阻塞范围 |
|---|---|---|
| DEVELOPMENT | P0、A1–A6：可运行实现、冻结契约/生成 client、数据正确性、权限隔离、幂等/恢复、超时与取消语义、基本回归；涉及数据库执行时使用现有配置的 Supabase 并记录实际结果 | 功能、契约、安全或不可恢复的数据错误阻塞相关依赖；性能基线记录不达标项 |
| INTEGRATION | I1–I10：逐页实现及本机真实 UI/BFF/服务组合的完整业务链、跨模块一致性、受控失败与恢复；外部连接使用自有合成输入或端口适配器，环境与替代范围写入证据；全部外部环境验收归 RELEASE | 对应功能链路未通过阻塞其依赖的功能联调；不要求先取得发布环境签署 |
| RELEASE | 功能闭环后在明确目标环境、负载、用途与授权下验证性能、长稳、staging/部署、远程同 SHA CI、发布回滚及签署 | 不达标阻止 Beta 发布或 testnet/Live 准备正式验收；仍可推进不依赖缺陷的功能 |

任务与检查点的 `stage_gate` 记录阶段准入；原 `development_status` 继续描述实现进度，原 `review_status`、`source_commit`、`evidence` 继续保留正式全量复审与历史回执。三个维度分别统计，不能把待发布验收计成未实现功能，也不能把阶段 READY 计成正式 ACCEPTED。

`stage_gate.status=NOT_ASSESSED` 表示尚需依据已有实现和实际证据进行聚焦功能评估，不能自动放行；此状态的 `input_digest` 必须为 null、`evidence` 必须为空。`BLOCKED` 可保留失败的输入摘要和证据，保留阻塞原因与实际结果。转为 `READY` 必须提供 `input_digest=sha256:<64hex>` 及非空证据：输入清单记录受检代码/契约/配置/测试/依赖证据的路径与内容摘要、运行环境、命令、结果、范围及遗留项；摘要绑定该清单。受检输入改变时重评受影响范围。仅规划文档或无关文件变动不要求重复全套真实环境/长稳测试；不能借此略过受影响功能回归。

`depends_on`、`core_prerequisites`、`closes_core` 和全部任务 ID 保留：任何节点转阶段 READY 前，其全部前置节点的阶段记录必须 READY；开发/联调按依赖节点 `stage_gate` 声明的功能范围消费，跨阶段消费已完成的前置阶段能力，不要求上游尚未关闭的正式全量 `review_status`。同一 INTEGRATION 窗口的页面可以先开发，再完成自身联调；它的下游依赖仍须等待所需功能准入。`CORE:<ID>` 的完整功能范围、`SERVICE:*` 的服务子范围保持区分，不能以部分 mock 或服务测试冒充整项功能闭环。RELEASE 检查点汇总所有延期项和正式环境要求，不自动继承前置工程 PASS；其阶段 READY 还要求自身正式 `review_status=ACCEPTED`、完整源码 SHA 和真实发布验收证据，输入清单摘要及开发证据不能替代。

现有 `pnpm check:p0`、A1 development/final-review、前端/核心 Gate 中可能仍混合多个阶段。本次不改运行 Gate 语义，不宣称已有命令自动支持阶段放行；已有独立功能子检查可分别记录结果和性能诊断，混合 runner 未拆分时不得忽略失败或将整条记为 PASS。受此影响的任务须先拆出可验证的功能 runner，再评估阶段 READY。本次纯文档变更只运行计划结构/依赖回归，不重跑数据库/provider 或长稳。旧同 SHA 正式回执只证明其原提交，不传递到新 HEAD；发布候选仍须取得自身的远程同 SHA CI 和目标环境回执。


### 2.2 验收人工确认

所有原六方/多角色项目验收确认统一按[用户确认流程](./gate-records/user-acceptance-confirmation-workflow.md)：Codex 拟稿，项目用户一人确认；无需各角色分别签署。适用于本计划所有 Gate/provider 与后续 RELEASE。角色保留审阅维度与工程 owner，技术验证及范围边界照常执行。历史版本中的多方签署仅按当时事实保留。

### 2.3 BFF-FE-003 后续任务的发布移交契约

本节适用于 BFF-FE-005 起的全部后续任务、PROVIDER:A3–A6/ALL、FRONTEND-GATE:G1–G8、FRONTEND-WINDOW:I4/I5 和 FEP-1–FEP-8。外部环境与性能指标仅在 RELEASE 阻止发布，不阻止 DEVELOPMENT/INTEGRATION 功能准入；未实现、契约不一致、越权、错误数据、重复副作用或恢复错误仍阻塞对应功能。依赖 ID、阶段顺序、授权/许可和正式用户确认规则保持有效。当前任务 BFF-FE-003 及其上游回执不由本次后续范围迁移自动放行。

每张任务卡登记责任任务、发布入口和 NOT_RUN；机器清单为 `scripts/frontend-gate-handoff-policy.json`，`node scripts/check-frontend-gate-handoff.mjs` 校验完整覆盖及原条款保留。混合 runner 未拆分时记录其实际失败，不得忽略失败宣称 READY；需先提供功能 runner 与独立目标回执入口。当前修改只落实阶段契约，不生成缺失的功能准入。

按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。

第7.4节全部原阈值、每路由G0预算、取消≤2s、证据还原≤5分钟、Lighthouse/帧率/延迟、持续窗口，以及第10节全量发布要求均保留。开发期性能采样属于诊断，不作为 Gate；功能测试的deadline/取消、限流、幂等、资源有界与故障恢复正确性不得延期。G8/FEP-8 以本机组合验证条件入口，实际testnet与外部venue运行归核心 RELEASE-GATE:LIVE-READINESS；本机证据不扩大任何真实用途授权。

## 3. 前期准备窗口（P0）

### 3.1 工作包与产出

迭代 `P0`（W1–W2）完成准备任务的 DEVELOPMENT 工程评估。准备检查点的阶段 READY 仅放行 A1 功能开发；FEP-0/G0 在 A1 完成功能冻结，正式全量验收的剩余项由 RELEASE 收口。

<a id="task-pre-01"></a>
#### PRE-01：需求拆解

- task_id: `PRE-01`
- task_type: `PREPARATION`
- iteration: `P0`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: []
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：需求拆解
- 主要动作：将官网页面、P01–P15/P17–P23、全局壳、角色、状态和关键流程拆为 Web story；每项标注 P0/P1、角色、路由和风险级别
- 产出：[页面台账](./execution/PRE-01-page-ledger-and-stories.md)、[路由/权限矩阵](./execution/PRE-01-route-permission-matrix.md)、[验收场景表](./execution/PRE-01-acceptance-scenarios.md)
- 完成标准：页面覆盖率 100%；每页至少有默认/加载/空/错误/无权/陈旧/离线状态
- 当前数量：一期 30 页面单元；124 页面 Story + 8 流程 Story；210 页面七态 + 10 流程场景；30 行页面追踪。
- 仓库复验：2026-10-02 PASS，10/10 控制点通过，原 8/8 问题关闭；见[当前报告](./audit/PRE-01-comprehensive-review-2026-10-02.md)与[可重放证据](./audit/evidence/pre01-recheck-20261002/manifest.json)。此结果不代表指定模型、正式 G0、provider/staging 或页面运行验收。

<a id="task-pre-02"></a>
#### PRE-02：设计系统预研

- task_id: `PRE-02`
- task_type: `PREPARATION`
- iteration: `P0`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-01"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：设计系统预研
- 主要动作：固化 token、密度、断点、主题、状态枚举、金融数值、图表、表格、危险动作模式
- 产出：[Design token ADR](./adr/20260814-pre02-design-tokens.md)、[组件清单](./execution/PRE-02-component-inventory.md)、Storybook 骨架；[受控规则基线](./execution/PRE-02-design-system-baseline.json)。
- 仓库复验：2026-10-02 再复验 PASS，14/14 控制点、原 8/8 问题关闭；27 项 Gate + 18 项 UI 回归、252 对比度配对和四组 Chromium 基础核验通过。见[PRE-02 当前报告](./audit/PRE-02-comprehensive-review-2026-10-02.md)及[复验清单](./audit/evidence/pre02-recheck-20261002/manifest.json)。一期 Web 验收不要求 P16/native，指定模型、正式 G0 与页面/目标环境验收独立记录。
- 完成标准：WCAG 2.2 AA 基础检查通过；通用安全文案全部入 i18n

<a id="task-pre-03"></a>
#### PRE-03：技术栈落地

- task_id: `PRE-03`
- task_type: `PREPARATION`
- iteration: `P0`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-02", "CORE:F01"]
- core_prerequisites: ["CORE:F01"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：技术栈落地
- 主要动作：在现有 workspace 引入并验证目标依赖；建立 Next.js 官网与 Web Terminal PoC
- 产出：运行时 ADR、依赖锁、最小 Web 构建与路由 smoke
- 仓库再复验：2026-10-02 PASS，原10/10问题关闭、15/15控制点通过，当前各等级活动问题均为0；29项关键依赖、Web正负套件27项、Desktop显式参考4项、177项单元测试及实际Chromium/标准启动验证通过。干净源码、可用下载缓存与local-mock条件下主链32.278秒；`.env.local`/注入配置及旧回执拒绝均实测。见[当前复审报告](./audit/PRE-03-comprehensive-review-2026-10-02.md)及[本轮证据清单](./audit/evidence/pre03-recheck-20261002/manifest.json)。远端CI、正式G0、指定模型与provider/staging仍未验收。
- 完成标准：新环境 ≤30 分钟完成 bootstrap/build/test；官网与 Web Terminal 目标路由可打开

<a id="task-pre-04"></a>
#### PRE-04：接口盘点

- task_id: `PRE-04`
- task_type: `PREPARATION`
- iteration: `P0`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-01", "CORE:F03", "CORE:F06"]
- core_prerequisites: ["CORE:F03", "CORE:F06"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：接口盘点
- 主要动作：对照 F03、F05–F09、R02–R04、S01–S04、X01–X06、L01–L03 与现有 Proto/API client，建立本计划第 5 节契约台账
- 产出：OpenAPI gap list、字段字典、接口责任人、mock 状态
- 仓库复验：2026-10-02 PASS，原9/9问题关闭、16/16控制点通过；补齐任务引用及实现证据完整性漏检，38项盘点回归通过。23个P0单元、383行wire/计划字段、62 published/46 planned能力准确登记。后续接口实现与目标验收不据此完成。见[当前复验报告](./audit/PRE-04-comprehensive-review-2026-10-02.md)及[证据清单](./audit/evidence/pre04-recheck-20261002/manifest.json)。
- 完成标准：每个 P0 页面有 Query/Command/Realtime 依赖；无“待开发时再定”字段

<a id="task-pre-05"></a>
#### PRE-05：环境方案

- task_id: `PRE-05`
- task_type: `PREPARATION`
- iteration: `P0`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-03", "PRE-04"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：环境方案
- 主要动作：建立 local/mock、local-integrated、staging 三套 Web 配置，定义 BFF origin、OIDC callback、feature flags、观测和测试账号
- 产出：`.env.example`、配置校验、开发说明
- 完成标准：缺必需变量 fail-fast；客户端 bundle 不含 server secret；环境/mode 明确分离
- 仓库复核：2026-10-02，原9项问题已关闭，16/16控制点通过；补齐短秘密与生产环境文件秘密扫描后，36项PRE-05回归及三profile×两应用构建通过。见[当前验收报告](./audit/PRE-05-comprehensive-review-2026-10-02.md)和[复核证据](./audit/evidence/pre05-recheck-20261002/manifest.json)。当前模板只证明配置准备，正式G0与真实staging/provider验收仍独立记录。

<a id="task-pre-06"></a>
#### PRE-06：测试基线

- task_id: `PRE-06`
- task_type: `PREPARATION`
- iteration: `P0`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-04", "PRE-05"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：测试基线
- 主要动作：建立 MSW contract fixtures、Playwright project、axe、视觉基线、性能预算
- 产出：测试目录与 CI job
- 完成标准：故意破坏 schema、权限、敏感字段或视觉基线能使 CI 失败；开发以同源 runner 的可重放负向检查验证，远程同 SHA CI 的实际运行证据在 RELEASE 验收
- 仓库复核：2026-10-02，原9项问题关闭；H-02残余的测试跳过/非执行断言已补修。当前结果见[PRE-06复审报告](./audit/PRE-06-comprehensive-review-2026-10-02.md)和[再复核证据](./audit/evidence/pre06-recheck-20261002/manifest.json)。10个fixture逐项受检（2个仅inventory），五个关键政策文件逐文件100%，Linux/macOS各12张视觉基线；本地工程验收与远端CI、Linux执行及正式G0/owner签署分别记录。

<a id="acceptance-preparation-p0"></a>
#### PREPARATION:P0：验收检查点

准备任务全部标准与PoC通过，owner/环境/mock/设计/接口台账和测试基线齐备；仅放行A1，不宣称正式OpenAPI或全部provider验收。

```json
{
  "checkpoint_id": "PREPARATION:P0",
  "acceptance_window": "P0",
  "depends_on": [
    "FE:PRE-01",
    "FE:PRE-02",
    "FE:PRE-03",
    "FE:PRE-04",
    "FE:PRE-05",
    "FE:PRE-06"
  ],
  "required_scope": "准备任务全部标准与PoC通过，owner/环境/mock/设计/接口台账和测试基线齐备；仅放行A1，不宣称正式OpenAPI或全部provider验收。",
  "review_status": "ACCEPTED",
  "source_commit": "0149e5681fde7c6b75f891f6708d63726f075fc9",
  "evidence": [
    "audit/evidence/p0-preparation-remediation-20261002/source-0149e56/web/p0-receipt.json",
    "audit/evidence/p0-preparation-remediation-20261002/source-0149e56/f06-target/f06-receipt.json",
    "audit/PREPARATION-P0-remediation-2026-10-02.md"
  ],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

上方 `required_scope/review_status/source_commit/evidence` 保留历史完整范围及原回执事实。当前 P0 的 `stage_gate` 按第 2.1 节 DEVELOPMENT 范围核验工程标准、PoC、owner/环境/mock/设计/接口台账与测试基线，以功能输入清单和实际证据决定准入；NOT_ASSESSED 仍须聚焦评估。上方正式 `source_commit/evidence` 登记历史版本，不迁移旧 PASS。`pnpm check:p0`、`refs/notes/p0-acceptance` 及同 SHA F06 回执继续用于其原有正式验收范围；若需对新候选作正式同 SHA 声明，须独立生成该候选回执。仅本计划文字调整不触发全套真实 Supabase 验收重跑。原操作见[P0验收规程](./execution/P0-acceptance-runbook.md)，命令范围按第 2.1 节核对。

2026-10-05 [P0 聚焦复核](./audit/PREPARATION-P0-comprehensive-review-2026-10-02.md)：原 3 项发现均已关闭，12 节点 DEVELOPMENT 证据递归核验通过；历史 formal 字段及阶段输入摘要保持不变。当前 formal `check:p0` 缺少本提交回执时仍按原规则失败，不将 DEVELOPMENT READY 改写为正式 ACCEPTED。

## 4. 页面 API 前置与前端迭代计划

排期基准为 3–4 名前端、1 名 BFF 联调接口人、1 名 QA，2 周一个 Sprint。窗口表示依赖满足后的建议顺序；开发依赖按 `stage_gate` 判断。外部服务的必要功能未就绪时顺延依赖工作；部署/staging、性能或长稳待验收单独列入 RELEASE，不顺延无关功能开发。官网可与同一前端迭代的 Terminal 工作并行。

- A1 既有 `DEFERRED_TO_FINAL_REVIEW` 继续适用，并将阶段分离推广到 A2–A6 和页面：工程交付与基本回归支持 `development_status=COMPLETED`、`REVIEW_READY` 和经评估的阶段 READY；真实 staging、性能和发布签署在 RELEASE 执行，正式 `RE_REVIEW → ACCEPTED` 仍须所要求的完整证据。A1 现有开发入口为 `pnpm check:bff-a1-development`，最后评审入口为 `pnpm check:bff-a1-final-review`；其他命令不因此被视为已有阶段模式。
- 功能执行顺序保留：`P0 → A1 → A2 → A3 → A4 → A5 → A6 → I1 → I2 → I3 → I4 → I5 → I6 → I7 → I8 → I9 → CORE-GATE:L4-SERVICE → I10`。Beta 发布验收在 I9 功能闭环后独立执行，testnet/Live 准备正式验收在 I10 与核心 L4 功能闭环后执行。
- P0 阶段 READY 后进入 A1；A1 完成 G0/FEP-0 功能冻结。G0 最小冻结面与 A6 全量 API 功能检查点 `PROVIDER:ALL` 均须阶段 READY，才开始新页面实现；它们的正式 staging/签署状态分别保留。
- `A1–A6` 先完成全部页面 API 的 OpenAPI、生成 client、实现、授权、安全/错误/幂等/实时恢复及 provider 功能验证；全部 API 和 `PROVIDER:ALL` 的 DEVELOPMENT 准入通过后进入页面开发。无需等待全部 API 的正式 `review_status=ACCEPTED`；consumer/UI 功能 E2E 在 I1–I10 验证，发布环境回执在 RELEASE 验证。
- `Reviewed + Mocked` 至少领先页面一个 Sprint 的要求保留，实际新页面准入还要求全量 API 功能实现就绪。mock 可用于契约/组件 fixture 和 UI Complete，不能替代 API 实现与真实功能联调。
- `CORE:<ID>` 指完整核心功能范围；服务前置使用 `SERVICE:*` / `CORE-GATE:*SERVICE`。U01/S04/X06/TP01/L03/L04 由 `closes_core` 映射在页面闭环后作完整功能及正式复审；FEP-7 需要 R1/S2/X3 的功能 Gate，FEP-8 需要 L4 服务功能 Gate。正式全量验收和阶段准入分别记录。
- 同一迭代按条目顺序和 `depends_on` 拓扑执行；任务→阶段检查点→功能里程碑顺序保持。FEP 编号表达稳定业务范围；FEP-5 审计基础先于 Research/Release 跳转，FEP-4 市场先行、订单标记及收益报表在订单/对账后交付。跨页面双向跳转不形成循环开发依赖。
- FEP-1 已完成开发的事实保留；I1 安排功能复核、集成与逐页验证。`UNSPECIFIED` 实现状态需执行前盘点。新增 `stage_gate` 均为 NOT_ASSESSED；历史正式状态、通过/失败证据和遗留问题均保留，本次不产生自动准入。
- 每个窗口末尾填报阶段证据，功能依赖满足后继续下一窗口；正式 `ACCEPTED` 仍需绑定完整源码 SHA 的全部要求回执。结构校验只验证计划，不能替代功能运行或发布验收。

| 迭代 | 建议窗口 | 阶段 | 范围与出口 |
|---|---|---|---|
| P0 | W1–W2 | DEVELOPMENT | PRE-01–PRE-06；工程/契约准备，阶段准入 A1 |
| A1 | W3–W4 | DEVELOPMENT | BFF-FE-000；G0/FEP-0 功能冻结 |
| A2 | W5–W6 | DEVELOPMENT | BFF-FE-001、007；provider 功能验证 |
| A3 | W7–W8 | DEVELOPMENT | BFF-FE-003、005；provider 功能验证 |
| A4 | W9–W10 | DEVELOPMENT | BFF-FE-006、004；provider 功能验证 |
| A5 | W11–W12 | DEVELOPMENT | BFF-FE-009、008、010；provider 功能验证 |
| A6 | W13–W14 | DEVELOPMENT | BFF-FE-002、011；PROVIDER:ALL 全量 API 功能准入 |
| I1 | W15–W16 | INTEGRATION | FEP-1：共享壳、认证、设置、官网，G1 功能闭环 |
| I2 | W17–W18 | INTEGRATION | FEP-5 审计基础；FEP-2 Snapshot → Research → Artifact，G2 |
| I3 | W19–W20 | INTEGRATION | FEP-3 草稿 → 回测 → Release，G3 |
| I4 | W21–W22 | INTEGRATION | FEP-4 市场部分；FEP-5 组合与建议，I4 功能检查点 |
| I5 | W23–W24 | INTEGRATION | FEP-5 preflight → 审批 → Command/Order，I5 功能检查点 |
| I6 | W25–W26 | INTEGRATION | FEP-5 对账，G5 功能闭环 |
| I7 | W27–W28 | INTEGRATION | FEP-4 订单标记、Performance/报表，G4 功能闭环 |
| I8 | W29–W30 | INTEGRATION | FEP-6 Alerts → Operations/Admin，G6 功能闭环 |
| I9 | W31–W32 | INTEGRATION | FEP-7/G7 全业务链候选；汇总性能基线和待优化项 |
| I10 | W33–W34 | INTEGRATION | FEP-8/G8 获准 testnet 功能联调，保持模式/flag 边界 |
| RELEASE-BETA | I9 功能闭环后，按环境与优化工作估算 | RELEASE | RELEASE-GATE:BETA；性能、获准长稳、部署/CI 与签署 |
| RELEASE-LIVE | I10 与核心 L4 功能闭环后，另行安排 | RELEASE | 核心 RELEASE-GATE:LIVE-READINESS；正式 testnet/Live 准备验收，不启用生产实盘 |

### 4.1 页面 API 开发任务（先行）

F03 的领域协议和 R/S/X 服务能力不能替代页面 BFF 契约。以下 operation 名称表达能力，不预设 URL；最终 path、method、request/response schema、分页和 envelope 必须由 BFF 在版本化 OpenAPI 中发布，前端只使用生成 client。每项“目标阶段与验收”保持原业务 Gate 绑定：先在 A 迭代验证功能实现，后在对应 I 迭代完成功能联调；性能及正式环境指标在 RELEASE 收口。

跨计划功能路线：核心 F0 → R1 服务 → TP01 服务子范围 → S2 服务 → X3 服务 → A1–A6 全量 API → I1–I8 与核心 R1/S2/X3 完整功能 Gate → I9/Beta 功能候选 → 核心 L4 服务准备 → I10/G8 → 核心 L03/L04 与 L4 完整功能 Gate。每一步消费对应 `stage_gate` READY；P0 可在其功能依赖满足后提前完成。Beta 与 Live 准备分别通过独立 RELEASE 检查点正式验收。稳定验收单位见[核心计划第2.8节](./SumAlpha-QuantOS-Development-Plan.md#28-跨计划验收单位与证据规则)。

#### 迭代 A1：页面 API 基线开发与功能冻结

<a id="task-bff-fe-000"></a>
##### BFF-FE-000：页面 BFF OpenAPI 基线

- task_id: `BFF-FE-000`
- task_type: `PAGE_API`
- iteration: `A1`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-04", "PRE-06", "CORE:F03", "CORE:F05", "CORE:F06", "PREPARATION:P0"]
- core_prerequisites: ["CORE:F03", "CORE:F05", "CORE:F06"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：建立页面 BFF OpenAPI 基线；统一 session 注入、错误 envelope、cursor 分页、sort/filter、202 job、Idempotency-Key、ETag/objectVersion、correlation ID、SSE event envelope；生成 TS client/Zod/MSW
- 领域接口背景：F03 有领域 Proto/OpenAPI 生成，但无第一期 22 个 Web Terminal 页面完整 API 清单
- 覆盖契约/页面：C01–C17；P01–P15/P17–P23
- 目标阶段与验收：FEP-0/G0：每个 `UI-Pxx` 可追踪到 operationId；生成漂移、provider/consumer contract 与敏感字段扫描进入 CI
- 当前工程复核：[2026-10-04 活跃复核报告](./audit/BFF-FE-000-comprehensive-review-2026-10-03.md)；API 1.5.0 / 62 published / 46 planned / 52 schemas；原 6 高危、6 中危、1 低危工程问题已关闭，当前活动工程缺陷 0，历史发现与关闭索引已归档。B-01 为 `DEFERRED_TO_FINAL_REVIEW`，真实 staging/联合签署在 RELEASE 执行，不阻塞开发完成或 REVIEW_READY，未标为 CLOSED/PASS。2026-10-05 已补齐当前适用的功能输入与实际检查，BFF-FE-000/P0/PROVIDER:A1 的 DEVELOPMENT stage_gate 为 READY，见 [PROVIDER:A1 整改报告](./audit/PROVIDER-A1-remediation-2026-10-05.md)；历史 P0 formal notes 不迁移，G0 与 RELEASE 状态独立。证据见[本轮清单](./audit/evidence/bff-fe-000-recheck-20261004/manifest.json)，阶段归属继续按第 2.1 节。 以上为迁移前内容回执；本次文档路径迁移后阶段准入为 NOT_ASSESSED，见[目录整理报告](./audit/Execution-document-organization-2026-10-07.md)。

<a id="acceptance-provider-a1"></a>
##### PROVIDER:A1：验收检查点

当前功能复验（2026-10-05）：原 1 阻塞、1 高危、3 中危、1 低危全部 CLOSED；活动问题 0，21/21 控制点通过，含本节点的 14 节点 DEVELOPMENT READY。`pnpm check:provider-a1` 复核当前输入/日志/产物及递归依赖，41 项回执测试、24 项非 DB Rust、38 次 reference HTTP、2 项业务 mutation 和 DB 执行状态检查通过。既有 65 项功能结果继续有效，本轮未重跑 Supabase。当前结论见[活跃复核报告](./audit/PROVIDER-A1-comprehensive-review-2026-10-04.md)，原始发现见[历史归档](./audit/PROVIDER-A1-findings-archive-2026-10-04.md)，修复过程见[整改报告](./audit/PROVIDER-A1-remediation-2026-10-05.md)；持续验收按[功能验收规程](./execution/PROVIDER-A1-functional-acceptance.md)。可作为后续 API 开发前置；G0、PROVIDER:ALL 和 RELEASE 独立评估。下方正式 review_status/source_commit/evidence 保留原事实。

A1 DEVELOPMENT 验证 OpenAPI/生成 client、schema、安全负向及已实现功能的 provider/consumer harness，按输入清单评估阶段 READY；A2–A6 未交付 provider 不属 A1 实现范围。B-01 staging 继续 DEFERRED_TO_FINAL_REVIEW，正式目标回执和签署由 RELEASE 收口，不能据工程通过改为正式 ACCEPTED。

```json
{
  "checkpoint_id": "PROVIDER:A1",
  "acceptance_window": "A1",
  "depends_on": [
    "FE:BFF-FE-000",
    "PREPARATION:P0"
  ],
  "required_scope": "A1 DEVELOPMENT 验证 OpenAPI/生成 client、schema、安全负向及已实现功能的 provider/consumer harness，按输入清单评估阶段 READY；A2–A6 未交付 provider 不属 A1 实现范围。B-01 staging 继续 DEFERRED_TO_FINAL_REVIEW，正式目标回执和签署由 RELEASE 收口，不能据工程通过改为正式 ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

##### G0 契约与工程功能冻结要求

以下冻结与 PoC 要求形成 G0 的 DEVELOPMENT 证据；新页面还须等待 PROVIDER:ALL 的全量 API 功能准入。发布用户确认在 RELEASE 完成：

- BFF 发布版本化 OpenAPI，至少冻结会话/上下文、Research、DataSnapshot、Strategy、Portfolio/Risk、Proposal/Approval/Order 与统一错误模型；未实现接口允许 mock，但 schema 不允许另起一套。
- 生成 client 与 Proto/JSON Schema 一致性检查进入 CI；现有手写 `InMemory*Backend` 已迁移为实现生成接口的测试 adapter，或明确标记为待删除。
- 页面台账能追踪到 `页面 → 前端任务 → BFF 契约 → 后端计划任务 → 测试用例 → Gate`。
- Web 页面 PoC、OIDC callback PoC、SSE 断线续传 PoC 均通过。
- Codex 按产品、前端、BFF、QA、安全、风控六个审阅维度拟定契约/功能范围文稿，由项目用户一人确认；未冻结项仍需责任人、截止日和兼容策略。RELEASE 的人工验收同样采用单用户确认。

<a id="acceptance-frontend-gate-g0"></a>
##### FRONTEND-GATE:G0：验收检查点

当前 DEVELOPMENT 再复核（2026-10-05）：原 1 阻塞、4 中危全部 CLOSED，活动问题 0；137 项专项回归、11 项独立反证通过，当前用户确认和 14 上游/G0 回执内容有效，24/24 控制点满足，阶段 READY。见[当前复审结论](./audit/FRONTEND-GATE-G0-comprehensive-review-2026-10-05.md)、[关闭依据](./audit/FRONTEND-GATE-G0-closed-findings-2026-10-05.md)及[既有完整验收](./audit/FRONTEND-GATE-G0-user-confirmed-acceptance-2026-10-05.md)。本轮未重跑 65 项上游、16 项 G0 或 Supabase；PROVIDER:ALL 与 RELEASE 独立验收，下方正式字段保留原事实。

工程复验入口为 `pnpm check:g0-engineering`，严格阶段准入为 `pnpm check:g0-development`；范围请求由 `pnpm scope:g0-development` 生成，项目用户当前确认记录写入 [G0-current-scope-confirmations.json](./gate-records/G0-current-scope-confirmations.json)。遗留子项见 [当前处置台账](./gate-records/G0-current-disposition.md)。工程 PASS 与用户范围确认分开记录，缺确认不能 READY。

G0 DEVELOPMENT 完成上方契约/工程冻结、追踪关系、PoC 和功能范围确认后评估阶段 READY；新页面还须全量 API 的 PROVIDER:ALL 阶段准入。正式 G0 用户确认、staging 与发布证据在 RELEASE 完成，历史正式复审状态独立保留。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G0",
  "acceptance_window": "A1",
  "depends_on": [
    "PREPARATION:P0",
    "PROVIDER:A1",
    "FE:BFF-FE-000"
  ],
  "required_scope": "G0 DEVELOPMENT 完成上方契约/工程冻结、追踪关系、PoC 和功能范围确认后评估阶段 READY；新页面还须全量 API 的 PROVIDER:ALL 阶段准入。正式 G0 用户确认、staging 与发布证据在 RELEASE 完成，历史正式复审状态独立保留。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-0"></a>
### FEP-0：准备与契约

- task_id: `FEP-0`
- task_type: `MILESTONE`
- iteration: `A1`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["CORE-GATE:F0", "PRE-01", "PRE-02", "PRE-03", "PRE-04", "PRE-05", "PRE-06", "FRONTEND-GATE:G0"]
- core_prerequisites: ["CORE-GATE:F0"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：工程运行时、设计系统、接口台账、环境、测试底座
- 验收边界：`pnpm check:fep0` 消费 CORE-GATE:F0、六 PRE 与当前 G0 的完整功能 manifest、执行日志/产物及递归证据；八项 READY 才能登记里程碑 READY。`pnpm check:fep0:engineering` 可核验唯一剩余 G0 用户确认的 BLOCKED 工程回执，不构成准入。
- 主要后端依赖：CORE-GATE:F0
- 交付节点与放行条件：G0：Web 栈、OpenAPI、会话、错误、mock 与浏览器 PoC 冻结
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

重构前功能复核：原 2/2 阻塞项已关闭，20/20 控制点满足；[主报告](./audit/FEP-0-comprehensive-review-2026-10-05.md)与[关闭依据](./audit/FEP-0-closed-findings-2026-10-05.md)记录当前准入及历史追溯。

- 当前工程复核：2026-10-07，当前范围的两项工程检查PASS，八依赖及当前状态严格核验；项目用户已确认当前 G0 范围 `52fee5f6e499`，G0/FEP-0 严格 READY。 见[CI整改报告](./audit/CI-47cb743-remediation-2026-10-07.md)和[当前功能回执](./audit/evidence/fep0-remediation-20261005/ci-47cb743-user-confirmed-20261007/fep0.json)。 以上为迁移前内容回执；本次文档路径迁移后阶段准入为 NOT_ASSESSED，见[目录整理报告](./audit/Execution-document-organization-2026-10-07.md)。

#### 迭代 A2：页面 API 开发与 provider 功能验证

<a id="task-bff-fe-001"></a>
##### BFF-FE-001：身份、会话与设置 API

- task_id: `BFF-FE-001`
- task_type: `PAGE_API`
- iteration: `A2`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "CORE:F06", "PROVIDER:A1"]
- core_prerequisites: ["CORE:F06"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：session/context/reauth/MFA/logout/access request；profile/locale/theme；active sessions revoke；trusted devices revoke；notification preferences/subscriptions；安全操作与审计引用
- 领域接口背景：F06 定义 Auth/RBAC/主上下文；未定义完整登录恢复、个人资料、会话、可信设备、通知偏好页面 API
- 覆盖契约/页面：C01、C17；P01/P15
- 目标阶段与验收：FEP-1/G1：401/403/404、CSRF、recent-auth、最后有效因素保护与撤销后实时失效测试通过
- 工程整改与复验：[当前复审结论](./audit/BFF-FE-001-comprehensive-review-2026-10-05.md)、[逐项关闭依据](./audit/BFF-FE-001-closed-findings-2026-10-05.md)、[2026-10-05 整改记录](./audit/BFF-FE-001-remediation-2026-10-05.md)。历史 2026-10-05 API 1.5.0 / 62 operations / 52 schemas 的 reference 与 Supabase + 本机 live BFF 结果保留；当前 API 1.6.0 / 63 operations / 54 schemas 由 A2_LOCAL 消费者限定功能回执验证，当前目标执行 NOT_RUN。staging 与签署仍按 FINAL 评审执行，PROVIDER:A2/G1 的正式复审状态由对应正式回执决定；功能准入另按 stage_gate 评估。
- 阶段执行：`pnpm check:bff-fe-001` 为 local_contract；`pnpm check:bff-fe-001:development` 校验本任务源码/执行/目标证据及 BFF-FE-000、CORE:F06、PROVIDER:A1 的递归有效 READY 回执；正负门禁为 `pnpm test:bff-fe-001:development`。当前整改入口：[2026-10-05 问题关闭与复验](./audit/BFF-FE-001-remediation-2026-10-05.md)。

历史功能复核（2026-10-05 / `f2283fa`）：原 2 高危、4 中危均 CLOSED；活动问题 0，24/24 控制点、20/20 API 满足，BFF-FE-001 DEVELOPMENT READY。目标证据源码内容一致，未重跑 Supabase；PROVIDER:A2/ALL 与 RELEASE 仍独立验收。

重构前依赖复验（2026-10-07）：共享 BFF/迁移改动后，BFF-FE-001 已重新执行实际 Supabase 身份/设置回归和清理，当前严格 DEVELOPMENT READY；见[新回执](./audit/evidence/bff-fe-001-remediation-20261005/bff007-sharp-20261007/a2.json)。旧源码回执保留历史。

- 当前工程复核：2026-10-07，PROVIDER:A2 新增高危/中危门禁缺口已关闭；当前 DEVELOPMENT 严格 READY。三组语义、22 项契约/44 项阶段负向及 8 项真实变异拒绝通过；7 项目标源码与原 Git 提交/当前内容一致，复用原 51 次 Supabase 调用和14断言及清理，未重跑目标。见[当前功能回执](./audit/evidence/bff-fe-001-remediation-20261005/ci-47cb743-final-reassessment-20261007/a2.json)和[当前报告](./audit/BFF-FE-001-comprehensive-review-2026-10-05.md)。 以上为迁移前内容回执；本次文档路径迁移后阶段准入为 NOT_ASSESSED，见[目录整理报告](./audit/Execution-document-organization-2026-10-07.md)。

<a id="task-bff-fe-007"></a>
##### BFF-FE-007：Audit 与导出 API

- task_id: `BFF-FE-007`
- task_type: `PAGE_API`
- iteration: `A2`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-001", "CORE:F05", "PROVIDER:A1"]
- core_prerequisites: ["CORE:F05"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：audit search/get chain；correlation/causation pagination；redacted payload；export create/status/cancel/download metadata；短时 URL、水印、retention
- 领域接口背景：F05/X06 有审计账本目标，未定义 Explorer 搜索、证据链和安全导出页面 API
- 覆盖契约/页面：C10；P04/P07/P09–P14/P22/P23
- 目标阶段与验收：FEP-5/G5：功能联调验证 correlation ID 证据链完整、越权/过期下载拒绝和导出全过程审计；≤5 分钟还原在 RELEASE 的目标数据规模下验收，开发/联调记录基线

当前复核（2026-10-07）：活动问题 0，31/31 控制点 PASS，严格 DEVELOPMENT READY；新增执行提交溯源门禁缺口已关闭。三组语义和5项真实变异拒绝通过；13项目标源码与不可变提交及当前内容一致，复用原83次调用/45断言和清理，本轮未重跑目标。见[当前报告](./audit/BFF-FE-007-comprehensive-review-2026-10-06.md)、[当前功能回执](./audit/evidence/bff-fe-007-remediation-20261006/ci-47cb743-reassessment-20261007/development.json)与[窗口严格复核](./audit/evidence/ci-47cb743-remediation-20261007/closure-verification.json)。

已关闭问题和整改过程见[历史归档](./audit/BFF-FE-007-remediation-history-2026-10-07.md)。`pnpm check:bff-fe-007:development` 验证当前输入、三项依赖、业务语义/变异及目标证据；local contract 检查单独通过不构成功能准入。十页面联调、目标规模下五分钟还原、部署/hosted CI 与 RELEASE 继续按对应阶段验收；运行配置见[runtime 说明](./execution/BFF-FE-007-runtime.md)。

<a id="acceptance-provider-a2"></a>
##### PROVIDER:A2：验收检查点

A2 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 当前开发按A2_LOCAL/R1_LOCAL/BFF003_LOCAL/BFF005_LOCAL分别校验17/27/40/40节点必要功能闭包，绑定同一冻结源码、实际测试日志和产物摘要；只有对应消费者登记DEVELOPMENT READY，上游独立Gate不自动放行。Supabase、外部环境及性能统一移交RELEASE-GATE:BETA，不作为开发阻塞；正式ACCEPTED须项目用户确认。

```json
{
  "checkpoint_id": "PROVIDER:A2",
  "acceptance_window": "A2",
  "depends_on": [
    "FE:BFF-FE-001",
    "FE:BFF-FE-007",
    "PROVIDER:A1"
  ],
  "required_scope": "A2 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 当前开发按A2_LOCAL/R1_LOCAL/BFF003_LOCAL/BFF005_LOCAL分别校验17/27/40/40节点必要功能闭包，绑定同一冻结源码、实际测试日志和产物摘要；只有对应消费者登记DEVELOPMENT READY，上游独立Gate不自动放行。Supabase、外部环境及性能统一移交RELEASE-GATE:BETA，不作为开发阻塞；正式ACCEPTED须项目用户确认。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "READY",
    "input_digest": "sha256:3bb5a36fa37bfc43bea5ded2775fdfe52d37fdf80d7a2e07e7a4fbaa8f82e429",
    "evidence": [
      "audit/evidence/provider-a3-local-20261013/a2-local.json"
    ]
  }
}
```

历史工程复核（2026-10-07）：当前活动问题0，24/24控制点PASS，26/26 API成功目标证据及三项直接依赖有效，DEVELOPMENT严格READY、formalAccepted=false。本轮127项针对性回归、11项异常证据拒绝及26个READY节点核验通过；64acc87的A2聚合及全部工程hosted CI成功。当前[功能manifest](./audit/evidence/provider-a2-remediation-20261007/ci-47cb743-reassessment-20261007/provider-a2.json)继续按内容绑定；执行 `pnpm check:provider-a2 && pnpm test:provider-a2`。见[当前复核报告](./audit/PROVIDER-A2-comprehensive-review-2026-10-07.md)及[本轮核验](./audit/evidence/provider-a2-recheck-64acc87-20261007/verification.json)。 以上为迁移前内容回执；本次文档路径迁移后阶段准入为 NOT_ASSESSED，见[目录整理报告](./audit/Execution-document-organization-2026-10-07.md)。

#### 迭代 A3：页面 API 开发与 provider 功能验证

<a id="task-bff-fe-003"></a>
##### BFF-FE-003：Research、Snapshot 与 Artifact API

- task_id: `BFF-FE-003`
- task_type: `PAGE_API`
- iteration: `A3`
- stage_gate: {"stage":"DEVELOPMENT","status":"READY","input_digest":"sha256:a345c6bc7437184d5ba2459ca0531c533f0ab9bc8fd8ffe2ea12ed7ff6fe16a6","evidence":["audit/evidence/provider-a3-local-20261013/bff003-local.json"]}
- depends_on: ["BFF-FE-001", "BFF-FE-007", "CORE:F07", "CORE:F08", "CORE:R02", "CORE:R03", "CORE:R04", "CORE-GATE:R1-SERVICE", "PROVIDER:A2"]
- core_prerequisites: ["CORE:F07", "CORE:F08", "CORE:R02", "CORE:R03", "CORE:R04", "CORE-GATE:R1-SERVICE"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 需求描述：Research list/create/get/cancel；stream subscribe/replay；Artifact/Evidence get；Snapshot list/get；统一 cursor/filter、sequence/afterSequence 和 202 状态引用
- 领域接口背景：R02–R04/F07 已定义 Snapshot/Research/Artifact 服务能力，缺页面级列表/筛选/详情/流式封装
- 覆盖契约/页面：C03/C04；P03–P05
- 目标阶段与验收：FEP-2/G2：创建、取消、断线续传、重复/乱序、质量/许可阻断与 Audit 关联 contract 全绿

- 历史工程复核：2026-10-12 九项 C03/C04 页面 API、持久适配器、生成契约及本地正负验证已实现；工程结果见[交付报告](./audit/BFF-FE-003-implementation-2026-10-12.md)。2026-10-13 已按当前冻结源码完整重跑 BFF003_LOCAL 闭包，限定 DEVELOPMENT READY。数据库、hosted CI、UI/consumer 和正式验收保持发布/集成阶段范围。

- 当前工程回执：2026-10-13 冻结 1ee328c7 的完整聚合闭包 140 组 PASS，BFF003_LOCAL 已同源复评 DEVELOPMENT READY。见[当前验收报告](./audit/PROVIDER-A3-development-2026-10-13.md)。

- 验收边界：BFF003_LOCAL完整40节点本地功能准入；A2_LOCAL与R1_LOCAL回执须同候选、覆盖全部必要检查与负向产物。外部环境、Supabase及性能由RELEASE-GATE:BETA实际验收，不阻塞开发。

<a id="task-bff-fe-005"></a>
##### BFF-FE-005：市场目录、报价与 K 线 API

- task_id: `BFF-FE-005`
- task_type: `PAGE_API`
- iteration: `A3`
- stage_gate: {"stage":"DEVELOPMENT","status":"READY","input_digest":"sha256:cbe0c97a623059691b07ba69d61fd2b00905defbb17c2993b8230729287aa887","evidence":["audit/evidence/provider-a3-local-20261013/bff005-local.json"]}
- depends_on: ["BFF-FE-001", "CORE:R01", "CORE:R02", "CORE-GATE:R1-SERVICE", "PROVIDER:A2"]
- core_prerequisites: ["CORE:R01", "CORE:R02", "CORE-GATE:R1-SERVICE"]
- closes_core: []
- development_status: `COMPLETED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：instrument catalog/watchlist；authorized VenueQuote；candle series/history/realtime；series metadata、quality/gaps/event markers；symbol/venue/product/timezone/interval capability
- 领域接口背景：R01/R02 定义行情与快照，未定义市场目录、跨 venue 报价、K 线与图表元数据页面 API
- 覆盖契约/页面：C12；P18/P19/P20；C16 告警订阅由 BFF-FE-010 承接，不转授该任务完成
- 目标阶段与验收：FEP-4/G4：报价和 candle 均含 source/venue/asOf/quality/license；切换维度不混用缓存，断流可回补且不拼接

- 历史工程回执（基础设施修复前）：2026-10-13 七个 C12 API、R01 许可盘口、R02 来源授权、K 线/gap/恢复及持久适配器已实现；完整本地闭包 139 组 PASS，BFF005_LOCAL READY。数据库候选迁移未应用；consumer/UI、目标环境、性能和正式确认另验。见[交付与验收报告](./audit/BFF-FE-005-development-2026-10-13.md)。

- 当前工程回执：2026-10-13 冻结 1ee328c7 的完整聚合闭包 140 组 PASS，BFF005_LOCAL 已同源复评 DEVELOPMENT READY。见[当前验收报告](./audit/PROVIDER-A3-development-2026-10-13.md)。

<a id="acceptance-provider-a3"></a>
##### PROVIDER:A3：验收检查点

A3 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "PROVIDER:A3",
  "acceptance_window": "A3",
  "depends_on": [
    "FE:BFF-FE-003",
    "FE:BFF-FE-005",
    "PROVIDER:A2"
  ],
  "required_scope": "A3 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "READY",
    "input_digest": "sha256:863dfce855955d4e3d8001eef8ad352677627b4209d1d7cab6a6fc11ffada5f4",
    "evidence": [
      "audit/evidence/provider-a3-local-20261013/a3-local.json"
    ]
  }
}
```

当前聚合工程回执：`A3_LOCAL` 绑定 BFF003/BFF005/A2 三份已发布回执及 42 节点完整功能闭包；140/140 组 PASS，DEVELOPMENT READY。正式检查点仍 NOT_STARTED，外部/性能 RELEASE NOT_RUN。见[聚合验收报告](./audit/PROVIDER-A3-development-2026-10-13.md)。

#### 迭代 A4：页面 API 开发与 provider 功能验证

<a id="task-bff-fe-006"></a>
##### BFF-FE-006：Portfolio、Risk、Proposal、Approval 与 Order API

- task_id: `BFF-FE-006`
- task_type: `PAGE_API`
- iteration: `A4`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-003", "BFF-FE-005", "BFF-FE-007", "CORE:X01", "CORE:X02", "CORE:X03", "CORE:X04", "CORE:TP07", "CORE-GATE:X3-SERVICE", "PROVIDER:A3"]
- core_prerequisites: ["CORE:X01", "CORE:X02", "CORE:X03", "CORE:X04", "CORE:TP07", "CORE-GATE:X3-SERVICE"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：portfolio/risk projection；proposal list/get/evaluate；preflight/order capabilities；approval list/get/decide/MFA；command-ref submit；order list/get/cancel request/stream
- 领域接口背景：X01–X04 定义风险和执行服务，缺 Portfolio/Proposal/Approval/Trade Ticket/Order 页面组合契约
- 覆盖契约/页面：C06–C09/C13；P08–P11/P20
- 目标阶段与验收：FEP-5/G5：七类拒绝、职责分离、重复 1,000 次幂等、202 受理和订单事实流全部通过

<a id="task-bff-fe-004"></a>
##### BFF-FE-004：Strategy、Backtest 与 Release API

- task_id: `BFF-FE-004`
- task_type: `PAGE_API`
- iteration: `A4`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-003", "BFF-FE-006", "BFF-FE-007", "CORE:S01", "CORE:S02", "CORE:S03", "CORE-GATE:X3-SERVICE", "SERVICE:S04", "PROVIDER:A3"]
- core_prerequisites: ["CORE:S01", "CORE:S02", "CORE:S03", "CORE-GATE:X3-SERVICE", "SERVICE:S04"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：strategy list/draft get/save；static check；backtest create/get/stream；release create/list/get；allowedTargets；approval timeline；expectedVersion/409 diff
- 领域接口背景：S01–S04 有 Strategy/Backtest/Release 能力，缺完整页面 API 与编辑冲突模型
- 覆盖契约/页面：C05/C08；P06/P07
- 目标阶段与验收：FEP-3/G3：并发编辑无静默覆盖；校验失败、未审批及非法 target 均由服务端拒绝

<a id="acceptance-provider-a4"></a>
##### PROVIDER:A4：验收检查点

A4 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "PROVIDER:A4",
  "acceptance_window": "A4",
  "depends_on": [
    "FE:BFF-FE-006",
    "FE:BFF-FE-004",
    "PROVIDER:A3"
  ],
  "required_scope": "A4 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

#### 迭代 A5：页面 API 开发与 provider 功能验证

<a id="task-bff-fe-009"></a>
##### BFF-FE-009：Reconciliation 与账本 API

- task_id: `BFF-FE-009`
- task_type: `PAGE_API`
- iteration: `A5`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-006", "BFF-FE-007", "CORE:X05", "CORE-GATE:X3-SERVICE", "PROVIDER:A4"]
- core_prerequisites: ["CORE:X05", "CORE-GATE:X3-SERVICE"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：reconciliation list/get；break list/get；ledger entries；request rerun/re-evaluation；status stream；Order/Fill/Audit/Alert evidence refs；禁止任何 edit-ledger operation
- 领域接口背景：X05 定义 reconciliation worker/ledger，但未定义完整页面读写契约
- 覆盖契约/页面：C15/C09/C10/C16；P22/P11/P21
- 目标阶段与验收：FEP-5/G5：差异状态跨页面一致；重跑幂等；schema 和权限负向测试证明前端无法改账

<a id="task-bff-fe-008"></a>
##### BFF-FE-008：Performance 与报表 API

- task_id: `BFF-FE-008`
- task_type: `PAGE_API`
- iteration: `A5`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-009", "CORE:X01", "CORE:X05", "CORE-GATE:X3-SERVICE", "PROVIDER:A4"]
- core_prerequisites: ["CORE:X01", "CORE:X05", "CORE-GATE:X3-SERVICE"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：performance summary/time series/attribution/drawdown/fees；valuation and ledger versions；report create/status/get/download；period/method/currency/coverage/provisional
- 领域接口背景：X01/X05 提供 Portfolio/对账基础；总计划未定义 Performance/Report API，原 C14 已标记“需 BFF 新增页面模型”
- 覆盖契约/页面：C14/C15；P21
- 目标阶段与验收：FEP-4/G4：所有结果含 account/currency/method/asOf/ledgerVersion/valuationSnapshotId；未对账数据强制 provisional

<a id="task-bff-fe-010"></a>
##### BFF-FE-010：Operations、Admin 与 Alert API

- task_id: `BFF-FE-010`
- task_type: `PAGE_API`
- iteration: `A5`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-001", "BFF-FE-007", "BFF-FE-009", "CORE:F09", "CORE-GATE:X3-SERVICE", "SERVICE:X06", "PROVIDER:A4"]
- core_prerequisites: ["CORE:F09", "CORE-GATE:X3-SERVICE", "SERVICE:X06"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：service health/metrics projection；incident list/get/timeline；approved Runbook actions/prechecks；member/role/policy/capability/flag CRUD with versioning；alert list/get/ack/unack/subscriptions/stream
- 领域接口背景：F09/X06 有观测、运维目标；F06 有策略能力，未定义 Incident/Admin/Alert 页面 API
- 覆盖契约/页面：C11/C16；P13/P14/P23/P02
- 目标阶段与验收：FEP-6/G6：无任意命令参数；最后管理员和职责分离保护；ack 不改变 resolved；所有治理变更可审计

<a id="acceptance-provider-a5"></a>
##### PROVIDER:A5：验收检查点

A5 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "PROVIDER:A5",
  "acceptance_window": "A5",
  "depends_on": [
    "FE:BFF-FE-009",
    "FE:BFF-FE-008",
    "FE:BFF-FE-010",
    "PROVIDER:A4"
  ],
  "required_scope": "A5 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

#### 迭代 A6：页面 API 开发与 provider 功能验证

<a id="task-bff-fe-002"></a>
##### BFF-FE-002：Command Center 聚合 API

- task_id: `BFF-FE-002`
- task_type: `PAGE_API`
- iteration: `A6`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-003", "BFF-FE-006", "BFF-FE-010", "CORE:F09", "CORE-GATE:X3-SERVICE", "PROVIDER:A5"]
- core_prerequisites: ["CORE:F09", "CORE-GATE:X3-SERVICE"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：authorized command summary、priority queue、system health、risk/data/order/run counters、recent activity；返回 sampledAt/asOf、source 和资源级跳转引用
- 领域接口背景：F09、R/X 有指标和事件，未定义 Command Center 聚合页面模型
- 覆盖契约/页面：C02；P02
- 目标阶段与验收：FEP-1/G1：单次聚合或受控并发、不同角色字段裁剪和无权对象负向测试通过；开发记录请求/延迟预算基线，无界扇出须修复，目标负载性能预算在 RELEASE 达标

<a id="task-bff-fe-011"></a>
##### BFF-FE-011：Web 浏览器平台能力 API

- task_id: `BFF-FE-011`
- task_type: `PAGE_API`
- iteration: `A6`
- stage_gate: {"stage":"DEVELOPMENT","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-001", "BFF-FE-010", "CORE-GATE:X3-SERVICE", "PROVIDER:A5"]
- core_prerequisites: ["CORE-GATE:X3-SERVICE"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：server-visible BrowserCapabilities、浏览器权限策略/permission state、下载记录与平台降级说明；不得返回 token、secret 或本地敏感内容
- 领域接口背景：浏览器权限和下载策略需要页面级 BFF 模型，不能直接暴露内部会话或存储实现
- 覆盖契约/页面：C17；P17
- 目标阶段与验收：FEP-1/G1：浏览器 capability、permission state、短时下载与敏感字段负向测试通过

<a id="acceptance-provider-a6"></a>
##### PROVIDER:A6：验收检查点

A6 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "PROVIDER:A6",
  "acceptance_window": "A6",
  "depends_on": [
    "FE:BFF-FE-002",
    "FE:BFF-FE-011",
    "PROVIDER:A5"
  ],
  "required_scope": "A6 全部 API 在 DEVELOPMENT 完成实现、OpenAPI/生成 client、schema/权限/错误/幂等/恢复/审计及安全负向功能验证，按输入清单评估阶段 READY；consumer/UI 功能链在对应 I 迭代验证，staging、性能与正式签署在 RELEASE 完成。A1 基线只负责 catalog/生成与 harness，不代替本窗口 provider 实现。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="acceptance-provider-all"></a>
##### PROVIDER:ALL：验收检查点

全部 12 个 API 的实现、OpenAPI/生成 client、权限/幂等/错误/实时恢复/审计/敏感字段功能检查和 G0 功能冻结通过后，评估 DEVELOPMENT 阶段 READY，允许 I1 起新页面实现；不要求全部 API 先取得正式 ACCEPTED。staging、部署、性能与完整签署由 RELEASE 汇总，Paper/Shadow 功能准入不启用 M5 target。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "PROVIDER:ALL",
  "acceptance_window": "A6",
  "depends_on": [
    "PROVIDER:A1",
    "PROVIDER:A2",
    "PROVIDER:A3",
    "PROVIDER:A4",
    "PROVIDER:A5",
    "PROVIDER:A6",
    "FE:BFF-FE-000",
    "FE:BFF-FE-001",
    "FE:BFF-FE-002",
    "FE:BFF-FE-003",
    "FE:BFF-FE-004",
    "FE:BFF-FE-005",
    "FE:BFF-FE-006",
    "FE:BFF-FE-007",
    "FE:BFF-FE-008",
    "FE:BFF-FE-009",
    "FE:BFF-FE-010",
    "FE:BFF-FE-011",
    "FRONTEND-GATE:G0"
  ],
  "required_scope": "全部 12 个 API 的实现、OpenAPI/生成 client、权限/幂等/错误/实时恢复/审计/敏感字段功能检查和 G0 功能冻结通过后，评估 DEVELOPMENT 阶段 READY，允许 I1 起新页面实现；不要求全部 API 先取得正式 ACCEPTED。staging、部署、性能与完整签署由 RELEASE 汇总，Paper/Shadow 功能准入不启用 M5 target。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "DEVELOPMENT",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

### 4.2 前端功能与逐页设计稿交付（后行）

以下 `UI-Pxx` 是各阶段 UI 任务的交付子任务。`design/` 中列出的有效稿是页面默认态的内容结构与视觉基准；若同一页面存在多个版本，以本节指定版本为准，旧版本仅保留追溯。开发必须将设计稿制作成可运行、可路由、可鉴权、可访问且接入生成式 BFF client 的 React 页面，同时按设计规范补齐加载、空、错误、无权、陈旧、离线/断线和危险确认状态。设计稿中的示例数据只能进入 Storybook/MSW fixture，不能硬编码进生产页面。

每个 `UI-Pxx` 工程交付附设计稿对照、路由/权限测试、七态 Storybook、MSW 契约用例、键盘/axe 检查、1440 视觉基线及至少一个目标浏览器的关键功能 E2E；进入 INTEGRATION 阶段 READY 还须真实 BFF/服务接口和跨模块业务链证据。staging、完整视觉/浏览器矩阵与签署在 RELEASE 汇总。仅静态 HTML、截图复刻或无接口组件不视为功能实现完成。

开发产物与对应基本测试齐备后可 `REVIEW_READY → IN_REVIEW`；功能问题按 `CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW` 修复。阶段 READY 依据第 2.1 节评估；正式 `ACCEPTED` 仍须完整复审，缺其目标环境可保留正式 BLOCKED 而不清除已证实的工程进度。`UI Complete → Integrated → Done` 按第 7.5 节分别描述 UI 实现、真实功能联调、正式发布验收，原契约状态链保持独立。

#### 迭代 I1：W15–W16

<a id="task-ui-103"></a>
##### UI-103：QuantOS UI/domain-ui、主题、i18n、表格/时间线/确认框

- task_id: `UI-103`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["PRE-02", "PRE-03", "PRE-06", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- 状态范围：已开发完成；UI Complete。组件及 Storybook 属于交付范围，本轮复审从空白开始。
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：QuantOS UI/domain-ui、主题、i18n、表格/时间线/确认框
- 接口绑定：无业务接口
- 验收重点：所有组件状态进 Storybook；键盘、焦点、200% 缩放和读屏通过

<a id="task-ui-vis-000"></a>
##### UI-VIS-000：第一期 Web Terminal 共用视觉体系；以 P02 与 P20 v3 为全局基准

- task_id: `UI-VIS-000`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-103", "BFF-FE-001", "BFF-FE-010", "BFF-FE-011", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P01–P15/P17–P23 共用视觉体系；以 P02 与 P20 v3 为全局基准
- 实际页面/路由交付：App Shell、导航、顶栏、状态条、栅格、token、边框、表格、表单、图表、Badge、危险确认与状态语义
- 契约绑定：C01、C16、C17
- 所属阶段：FEP-1；P0 的设计预研只提供输入，UI-VIS-000 完整交付在 I1 验收
- 页面级完成标准：抽取为 `packages/ui`/`domain-ui`，禁止逐页复制样式；开发建立 1440 视觉基线并验证关键状态，RELEASE 完成基准视觉回归设计签署；语义色不得挪作装饰色

<a id="task-ui-102"></a>
##### UI-102：OIDC、callback、MFA、401/403/404/maintenance/offline

- task_id: `UI-102`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-VIS-000", "BFF-FE-001", "BFF-FE-006", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- 状态范围：已开发完成；UI Complete / Contract Integrated。真实 IdP/MFA 功能联调是 G1 阶段 READY 的前置；staging 签署是正式 Done 的前置。
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：OIDC、callback、MFA、401/403/404/maintenance/offline
- 接口绑定：C01、C08
- 验收重点：401 清内存态；403/404 不泄露对象存在性；return path 不含敏感参数

<a id="task-ui-101"></a>
##### UI-101：App Shell、路由守卫、主工作区/账户/mode/数据新鲜度/风险/连接状态

- task_id: `UI-101`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-102", "BFF-FE-001", "BFF-FE-002", "BFF-FE-010", "BFF-FE-000", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- 状态范围：已开发完成；UI Complete / Mocked。BFF-FE-002 发布后使用生成 client + 同 schema MSW；真实 BFF 功能联调前不得升级 Integrated，staging 签署在 RELEASE 完成。
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：App Shell、路由守卫、主工作区/账户/mode/数据新鲜度/风险/连接状态
- 接口绑定：C01、C02、C16
- 验收重点：守卫严格按 session → tenant/workspace → RBAC/capability → resource → mode → data 顺序；任一步失败停止后续请求

<a id="task-ui-104"></a>
##### UI-104：Profile/安全/通知/浏览器能力

- task_id: `UI-104`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-101", "BFF-FE-001", "BFF-FE-011", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- 状态范围：已开发完成；UI Complete / Local Provider Implemented。BFF-FE-001/011 Web 契约完成真实功能联调后才可 Integrated，staging 签署在 RELEASE 完成。
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Profile/安全/通知/浏览器能力
- 接口绑定：C17
- 验收重点：会话撤销、通知降级、下载说明可用；小屏无高风险按钮

<a id="task-web-101"></a>
##### WEB-101：官网首页、产品、架构安全、场景、访问申请、登录

- task_id: `WEB-101`
- task_type: `WEBSITE`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-103", "UI-102", "BFF-FE-001", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `COMPLETED`
- 状态范围：已开发完成；UI Complete / Local Provider Implemented。Terminal Auth/BFF 真实功能联调后配置获准环境的 BFF origin 并评估 G1 阶段准入；发布前取得 staging/目标 CDN origin 证据并验证 Lighthouse。
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：官网首页、产品、架构安全、场景、访问申请、登录
- 接口绑定：Access Request/Auth
- 验收重点：开发验证 SEO、隐私、防滥用和禁用词功能；Lighthouse 采集基线，评分目标在 RELEASE 通过
- 官网功能细则：首期七页为首页、产品、架构安全、使用场景、文档中心、访问申请、登录；使用场景 `/use-cases`、文档中心 `/docs`。复用冻结 design token（深色默认 + 浅色媒体查询）；文档中心支持搜索空态、首页文档入口及可展开的版本化正文。访问申请使用 C01 `submitAccessRequest` 生成类型，包含团队、用途、市场、预期模式（expectedMode）与隐私说明版本；支持 honeypot、客户端校验、pending 防重复、离线禁用/中止、429 文案及错误后输入保留，202 仅显示“已受理”。未配置 BFF origin 时使用同源 `/v1/access-requests`；登录页仅作 Terminal 受控入口，不内嵌认证。首页 title template 避免重复，官网 lint 覆盖 App Router TSX；SEO 包含 canonical/robots/sitemap。

<a id="task-ui-p01"></a>
##### UI-P01：P01-Identity-Access-Recovery-High-Fidelity-v1.png

- task_id: `UI-P01`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-102", "UI-VIS-000", "BFF-FE-001", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P01-Identity-Access-Recovery-High-Fidelity-v1.png`
- 实际页面/路由交付：`/login`、`/mfa`、`/access-request`、`/unauthorized`、`/offline`
- 契约绑定：C01
- 所属阶段：FEP-1
- 页面级完成标准：登录、MFA、访问申请、恢复与返回安全路由均可运行；错误不泄露账户存在性

<a id="task-ui-p02"></a>
##### UI-P02：P02-Command-Center-High-Fidelity-v1.png

- task_id: `UI-P02`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-101", "UI-VIS-000", "BFF-FE-002", "BFF-FE-006", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P02-Command-Center-High-Fidelity-v1.png`
- 实际页面/路由交付：`/command`
- 契约绑定：C02、C06、C16
- 所属阶段：FEP-1
- 页面级完成标准：卡片按 capability 裁剪；汇总状态、待办、健康与最近活动来自 BFF；无静态业务数据

<a id="task-ui-p15"></a>
##### UI-P15：P15-Profile-Security-and-Notification-Settings-High-Fidelity-v2.png

- task_id: `UI-P15`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-104", "UI-VIS-000", "BFF-FE-001", "BFF-FE-011", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P15-Profile-Security-and-Notification-Settings-High-Fidelity-v2.png`
- 实际页面/路由交付：`/settings/profile`、`/settings/notifications`、`/settings/security`
- 契约绑定：C01、C17
- 所属阶段：FEP-1
- 页面级完成标准：资料、区域、通知矩阵、MFA、会话、可信设备和安全操作全部接入接口

<a id="task-ui-p17"></a>
##### UI-P17：P17-Web-Browser-Capability-High-Fidelity-v2.png

- task_id: `UI-P17`
- task_type: `FRONTEND`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-104", "UI-VIS-000", "BFF-FE-001", "BFF-FE-011", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "PROVIDER:ALL", "FRONTEND-GATE:G0"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P17-Web-Browser-Capability-High-Fidelity-v2.png`
- 实际页面/路由交付：`/settings/browser`
- 契约绑定：C17、BrowserCapabilities
- 所属阶段：FEP-1
- 页面级完成标准：浏览器权限、下载、存储、兼容性与响应式能力检测落地；非浏览器能力不进入一期范围

<a id="acceptance-frontend-gate-g1"></a>
##### FRONTEND-GATE:G1：验收检查点

按 FEP-1 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G1",
  "acceptance_window": "I1",
  "depends_on": [
    "FE:UI-103",
    "FE:UI-VIS-000",
    "FE:UI-102",
    "FE:UI-101",
    "FE:UI-104",
    "FE:WEB-101",
    "FE:UI-P01",
    "FE:UI-P02",
    "FE:UI-P15",
    "FE:UI-P17",
    "CORE:F06",
    "CORE:F09",
    "PROVIDER:ALL"
  ],
  "required_scope": "按 FEP-1 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-1"></a>
##### FEP-1：壳与官网

- task_id: `FEP-1`
- task_type: `MILESTONE`
- iteration: `I1`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PRE-06", "CORE:F06", "CORE:F09", "UI-103", "UI-VIS-000", "UI-102", "UI-101", "UI-104", "WEB-101", "UI-P01", "UI-P02", "UI-P15", "UI-P17", "FRONTEND-GATE:G1"]
- core_prerequisites: ["CORE:F06", "CORE:F09"]
- closes_core: []
- development_status: `COMPLETED`
- 状态范围：已开发完成范围为 UI-101–UI-104、WEB-101；逐页 UI-Pxx 与 G1 的集成验收仍按独立条目判定。
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：官网首期；P01、P02、P15、P17；App Shell、路由、主题、i18n、全局状态
- 主要后端依赖：CORE:F06、CORE:F09
- 交付节点与放行条件：G1：认证/RBAC/模式/陈旧/离线/响应式可用，官网内容合规
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I2：W17–W18

<a id="task-ui-507"></a>
##### UI-507：Audit Explorer 与受控导出

- task_id: `UI-507`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-101", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Audit Explorer 与受控导出
- 接口绑定：C10
- 验收重点：correlation/causation 链完整；导出异步、短时 URL、授权和审计

<a id="task-ui-p12"></a>
##### UI-P12：P12-Audit-Explorer-and-Export-Jobs-High-Fidelity-v1.png

- task_id: `UI-P12`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-507", "UI-VIS-000", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P12-Audit-Explorer-and-Export-Jobs-High-Fidelity-v1.png`
- 实际页面/路由交付：`/audit`、`/audit/:correlationId`、`/exports/:exportId`
- 契约绑定：C10
- 所属阶段：FEP-5
- 页面级完成标准：服务端搜索/分页、因果链、脱敏载荷、异步导出和短时下载状态落地

<a id="task-ui-204"></a>
##### UI-204：DataSnapshot 目录/详情、质量/许可/时效

- task_id: `UI-204`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-101", "BFF-FE-003", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：DataSnapshot 目录/详情、质量/许可/时效
- 接口绑定：C04
- 验收重点：`failed/degraded/expired/license missing` 明确阻断后续策略/交易用途

<a id="task-ui-p05"></a>
##### UI-P05：P05-Data-Snapshot-Catalog-and-Detail-High-Fidelity-v1.png

- task_id: `UI-P05`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-204", "UI-VIS-000", "BFF-FE-003", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P05-Data-Snapshot-Catalog-and-Detail-High-Fidelity-v1.png`
- 实际页面/路由交付：`/data-snapshots`、`/data-snapshots/:snapshotId`
- 契约绑定：C04
- 所属阶段：FEP-2
- 页面级完成标准：目录、详情、血缘、质量、许可、时效与阻断状态均由接口驱动

<a id="task-ui-201"></a>
##### UI-201：Research 列表、新建与表单校验

- task_id: `UI-201`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-204", "BFF-FE-003", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Research 列表、新建与表单校验
- 接口绑定：C03、C04
- 验收重点：请求含 capability、snapshot、budget、deadline；后端拒绝字段原位显示

<a id="task-ui-p03"></a>
##### UI-P03：P03-Research-List-and-New-Research-High-Fidelity-v1.png

- task_id: `UI-P03`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-201", "UI-VIS-000", "BFF-FE-003", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P03-Research-List-and-New-Research-High-Fidelity-v1.png`
- 实际页面/路由交付：`/research`、`/research/new`
- 契约绑定：C03、C04
- 所属阶段：FEP-2
- 页面级完成标准：列表分页/筛选与创建表单落地；预算、deadline、snapshot、capability 校验与 202 受理正确

<a id="task-ui-202"></a>
##### UI-202：Research 详情、SSE 流、取消与恢复

- task_id: `UI-202`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-201", "BFF-FE-003", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Research 详情、SSE 流、取消与恢复
- 接口绑定：C03
- 验收重点：以 sequence/cursor 去重；断线从最后确认游标回补；取消返回受理态而非伪造已取消

<a id="task-ui-203"></a>
##### UI-203：Artifact/Evidence 详情与交叉跳转

- task_id: `UI-203`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-202", "UI-507", "BFF-FE-003", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Artifact/Evidence 详情与交叉跳转
- 接口绑定：C04、C10
- 验收重点：显示 input/content/environment hash、Engine/prompt/code 版本、证据与 correlation ID

<a id="task-ui-p04"></a>
##### UI-P04：P04-Research-and-Artifact-Detail-High-Fidelity-v1.png

- task_id: `UI-P04`
- task_type: `FRONTEND`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-202", "UI-203", "UI-VIS-000", "BFF-FE-003", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G1"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P04-Research-and-Artifact-Detail-High-Fidelity-v1.png`
- 实际页面/路由交付：`/research/:runId`、`/artifacts/:artifactId`
- 契约绑定：C03、C04、C10
- 所属阶段：FEP-2
- 页面级完成标准：SSE 续传/去重、取消受理、Artifact/Evidence/Audit 跳转及全部终态落地

<a id="acceptance-frontend-gate-g2"></a>
##### FRONTEND-GATE:G2：验收检查点

按 FEP-2 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G2",
  "acceptance_window": "I2",
  "depends_on": [
    "FE:UI-204",
    "FE:UI-P05",
    "FE:UI-201",
    "FE:UI-P03",
    "FE:UI-202",
    "FE:UI-203",
    "FE:UI-P04",
    "CORE-GATE:R1-SERVICE",
    "PROVIDER:ALL"
  ],
  "required_scope": "按 FEP-2 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-2"></a>
##### FEP-2：研究闭环

- task_id: `FEP-2`
- task_type: `MILESTONE`
- iteration: `I2`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "UI-P17", "CORE-GATE:R1-SERVICE", "UI-204", "UI-P05", "UI-201", "UI-P03", "UI-202", "UI-203", "UI-P04", "FRONTEND-GATE:G2"]
- core_prerequisites: ["CORE-GATE:R1-SERVICE"]
- closes_core: ["CORE:U01", "CORE:TP01"]
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P03–P05；Research 创建、流式、取消、Artifact、DataSnapshot
- 主要后端依赖：CORE-GATE:R1-SERVICE
- 交付节点与放行条件：G2 功能准入验证固定输入可追溯与重放、取消/超时/终态/资源释放和基本浏览器用例；取消 ≤2s 在功能联调采样并于 RELEASE 指定环境验收，目标 Web 浏览器完整同用例全绿亦由 RELEASE 收口
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I3：W19–W20

<a id="task-ui-301"></a>
##### UI-301：Strategy 目录与 Lab 草稿

- task_id: `UI-301`
- task_type: `FRONTEND`
- iteration: `I3`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-203", "UI-204", "BFF-FE-004", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G2"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Strategy 目录与 Lab 草稿
- 接口绑定：C05
- 验收重点：自动保存带版本；409 保留草稿并提供 diff，不覆盖服务端

<a id="task-ui-p06"></a>
##### UI-P06：P06-Strategy-Catalog-and-Strategy-Lab-High-Fidelity-v1.png

- task_id: `UI-P06`
- task_type: `FRONTEND`
- iteration: `I3`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-301", "UI-VIS-000", "BFF-FE-004", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G2"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P06-Strategy-Catalog-and-Strategy-Lab-High-Fidelity-v1.png`
- 实际页面/路由交付：`/strategies`、`/strategies/new`、`/strategies/:strategyId/lab`
- 契约绑定：C05
- 所属阶段：FEP-3
- 页面级完成标准：目录、Lab、版本化草稿、自动保存、校验与 409 diff 可用

<a id="task-ui-302"></a>
##### UI-302：静态检查、回测队列与报告

- task_id: `UI-302`
- task_type: `FRONTEND`
- iteration: `I3`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-301", "BFF-FE-004", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G2"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：静态检查、回测队列与报告
- 接口绑定：C05
- 验收重点：固定 snapshot/clock/cost/slippage/environment hash；泄漏检查失败阻断 Release

<a id="task-ui-303"></a>
##### UI-303：不可变 Release、审批申请与目标选择

- task_id: `UI-303`
- task_type: `FRONTEND`
- iteration: `I3`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-302", "UI-507", "BFF-FE-004", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G2"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：不可变 Release、审批申请与目标选择
- 接口绑定：C05、C08
- 验收重点：hash/参数/回测/数据/证据齐全；目标完全取自后端 `allowedTargets`

<a id="task-ui-p07"></a>
##### UI-P07：P07-Backtest-Detail-and-Strategy-Release-High-Fidelity-v1.png

- task_id: `UI-P07`
- task_type: `FRONTEND`
- iteration: `I3`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-302", "UI-303", "UI-VIS-000", "BFF-FE-004", "BFF-FE-006", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-005", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G2"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P07-Backtest-Detail-and-Strategy-Release-High-Fidelity-v1.png`
- 实际页面/路由交付：`/backtests/:runId`、`/releases`、`/releases/:releaseId`
- 契约绑定：C05、C08、C10
- 所属阶段：FEP-3
- 页面级完成标准：回测详情、校验报告、不可变 Release、审批时间线和 allowedTargets 落地

<a id="acceptance-frontend-gate-g3"></a>
##### FRONTEND-GATE:G3：验收检查点

按 FEP-3 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G3",
  "acceptance_window": "I3",
  "depends_on": [
    "FE:UI-301",
    "FE:UI-P06",
    "FE:UI-302",
    "FE:UI-303",
    "FE:UI-P07",
    "CORE-GATE:S2-SERVICE",
    "SERVICE:S04",
    "PROVIDER:ALL"
  ],
  "required_scope": "按 FEP-3 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-3"></a>
##### FEP-3：策略治理

- task_id: `FEP-3`
- task_type: `MILESTONE`
- iteration: `I3`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "UI-P04", "CORE-GATE:S2-SERVICE", "SERVICE:S04", "UI-301", "UI-P06", "UI-302", "UI-303", "UI-P07", "FRONTEND-GATE:G3"]
- core_prerequisites: ["CORE-GATE:S2-SERVICE", "SERVICE:S04"]
- closes_core: ["CORE:S04"]
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P06–P07；草稿、静态检查、回测、Release、审批时间线
- 主要后端依赖：CORE-GATE:S2-SERVICE、SERVICE:S04
- 交付节点与放行条件：G3：未验证/未审批不可部署；M3/M4 仅 Paper/Shadow
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I4：W21–W22

<a id="task-ui-401"></a>
##### UI-401：Market Catalog、Watchlist、VenueQuote

- task_id: `UI-401`
- task_type: `FRONTEND`
- iteration: `I4`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-101", "UI-204", "BFF-FE-005", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G3"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Market Catalog、Watchlist、VenueQuote
- 接口绑定：C12
- 验收重点：每行含 source、venue、asOf、latency、quality、capability；不同产品不前端合并

<a id="task-ui-p18"></a>
##### UI-P18：P18-Markets-Overview-and-Instrument-Detail-High-Fidelity-v2.png

- task_id: `UI-P18`
- task_type: `FRONTEND`
- iteration: `I4`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-401", "UI-VIS-000", "BFF-FE-005", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G3"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P18-Markets-Overview-and-Instrument-Detail-High-Fidelity-v2.png`
- 实际页面/路由交付：`/markets`、`/markets/:symbol`
- 契约绑定：C12、C16
- 所属阶段：FEP-4
- 页面级完成标准：市场目录、自选、报价比较、标的详情、许可/质量/as_of 与告警偏好接口化

<a id="task-ui-501"></a>
##### UI-501：Portfolio 与 Risk

- task_id: `UI-501`
- task_type: `FRONTEND`
- iteration: `I4`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-101", "BFF-FE-006", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G3"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Portfolio 与 Risk
- 接口绑定：C06、C16
- 验收重点：asOf/stale、仓位、P&L、敞口、规则命中、kill switch 常驻；陈旧即阻断写操作

<a id="task-ui-p08"></a>
##### UI-P08：P08-Portfolio-and-Risk-High-Fidelity-v1.png

- task_id: `UI-P08`
- task_type: `FRONTEND`
- iteration: `I4`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-501", "UI-VIS-000", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G3"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P08-Portfolio-and-Risk-High-Fidelity-v1.png`
- 实际页面/路由交付：`/portfolio`、`/risk`、`/risk/rules/:ruleId`
- 契约绑定：C06
- 所属阶段：FEP-5
- 页面级完成标准：仓位、估值、P&L、敞口、规则、stale 与 kill switch 状态可验证；陈旧时禁写

<a id="task-ui-502"></a>
##### UI-502：Proposal 与风险评估

- task_id: `UI-502`
- task_type: `FRONTEND`
- iteration: `I4`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-203", "UI-501", "UI-507", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G3"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Proposal 与风险评估
- 接口绑定：C07
- 验收重点：永久显示 `executable=false` 语义；过期 Proposal 不允许评估

<a id="task-ui-p09"></a>
##### UI-P09：P09-TradeProposal-List-and-Detail-High-Fidelity-v1.png

- task_id: `UI-P09`
- task_type: `FRONTEND`
- iteration: `I4`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-502", "UI-VIS-000", "BFF-FE-006", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G3"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P09-TradeProposal-List-and-Detail-High-Fidelity-v1.png`
- 实际页面/路由交付：`/proposals`、`/proposals/:proposalId`
- 契约绑定：C07、C10
- 所属阶段：FEP-5
- 页面级完成标准：列表/详情/证据/反方观点/失效时间落地；始终显示不可执行语义

<a id="acceptance-frontend-window-i4"></a>
##### FRONTEND-WINDOW:I4：验收检查点

I4 本窗口任务完成功能实现与必要的真实 BFF/服务联调后评估 INTEGRATION 阶段 READY，允许进入下一功能窗口；G4/G5 跨窗口功能闭环随后完成，性能、staging 与正式发布验收不作为本窗口开发准入。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-WINDOW:I4",
  "acceptance_window": "I4",
  "depends_on": [
    "FE:UI-401",
    "FE:UI-P18",
    "FE:UI-501",
    "FE:UI-P08",
    "FE:UI-502",
    "FE:UI-P09",
    "PROVIDER:ALL"
  ],
  "required_scope": "I4 本窗口任务完成功能实现与必要的真实 BFF/服务联调后评估 INTEGRATION 阶段 READY，允许进入下一功能窗口；G4/G5 跨窗口功能闭环随后完成，性能、staging 与正式发布验收不作为本窗口开发准入。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

#### 迭代 I5：W23–W24

<a id="task-ui-503"></a>
##### UI-503：Trade Ticket preflight

- task_id: `UI-503`
- task_type: `FRONTEND`
- iteration: `I5`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-401", "UI-501", "UI-502", "BFF-FE-005", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Trade Ticket preflight
- 接口绑定：C12、C13、C07
- 验收重点：每一步重新取报价、余额、限额、venue 健康、对象版本和 mode；只预填 intent，不生成 command

<a id="task-ui-504"></a>
##### UI-504：Approval、MFA、职责分离

- task_id: `UI-504`
- task_type: `FRONTEND`
- iteration: `I5`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-503", "UI-102", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Approval、MFA、职责分离
- 接口绑定：C08
- 验收重点：自批/过期/冲突/额度变化明确拒绝；不采用乐观更新

<a id="task-ui-p10"></a>
##### UI-P10：P10-Approvals-and-RiskDecision-Detail-High-Fidelity-v1.png

- task_id: `UI-P10`
- task_type: `FRONTEND`
- iteration: `I5`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-504", "UI-VIS-000", "BFF-FE-006", "BFF-FE-007", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P10-Approvals-and-RiskDecision-Detail-High-Fidelity-v1.png`
- 实际页面/路由交付：`/approvals`、`/approvals/:approvalId`
- 契约绑定：C07、C08、C10
- 所属阶段：FEP-5
- 页面级完成标准：RiskDecision、规则命中、MFA、职责分离、同意/拒绝/过期/冲突状态落地

<a id="task-ui-505"></a>
##### UI-505：Command 提交、Order/Fill 时间线、撤单请求

- task_id: `UI-505`
- task_type: `FRONTEND`
- iteration: `I5`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-504", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Command 提交、Order/Fill 时间线、撤单请求
- 接口绑定：C09
- 验收重点：提交只传服务端 command ref 与 Idempotency-Key；重复提交只产生一笔下游订单

<a id="task-ui-p20"></a>
##### UI-P20：P20-Trade-Ticket-Controlled-Order-Entry-High-Fidelity-v3.png

- task_id: `UI-P20`
- task_type: `FRONTEND`
- iteration: `I5`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-503", "UI-504", "UI-505", "UI-VIS-000", "BFF-FE-005", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P20-Trade-Ticket-Controlled-Order-Entry-High-Fidelity-v3.png`
- 实际页面/路由交付：`/trade`、`/trade/:symbol`
- 契约绑定：C07–C09、C12、C13
- 所属阶段：FEP-5
- 页面级完成标准：订单意图、执行上下文、preflight、证据关联、风险评估、审批与 command ref 提交严格按服务端时序实现

<a id="task-ui-p11"></a>
##### UI-P11：P11-Orders-and-Execution-Detail-High-Fidelity-v1.png

- task_id: `UI-P11`
- task_type: `FRONTEND`
- iteration: `I5`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-505", "UI-VIS-000", "BFF-FE-006", "BFF-FE-007", "BFF-FE-009", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-008", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P11-Orders-and-Execution-Detail-High-Fidelity-v1.png`
- 实际页面/路由交付：`/orders`、`/orders/:orderId`
- 契约绑定：C09、C10、C15
- 所属阶段：FEP-5
- 页面级完成标准：Order/Fill 时间线、部分成交、拒绝、撤单请求、断流回补与证据链落地

<a id="acceptance-frontend-window-i5"></a>
##### FRONTEND-WINDOW:I5：验收检查点

I5 本窗口任务完成功能实现与必要的真实 BFF/服务联调后评估 INTEGRATION 阶段 READY，允许进入下一功能窗口；G4/G5 跨窗口功能闭环随后完成，性能、staging 与正式发布验收不作为本窗口开发准入。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-WINDOW:I5",
  "acceptance_window": "I5",
  "depends_on": [
    "FE:UI-503",
    "FE:UI-504",
    "FE:UI-P10",
    "FE:UI-505",
    "FE:UI-P20",
    "FE:UI-P11",
    "PROVIDER:ALL"
  ],
  "required_scope": "I5 本窗口任务完成功能实现与必要的真实 BFF/服务联调后评估 INTEGRATION 阶段 READY，允许进入下一功能窗口；G4/G5 跨窗口功能闭环随后完成，性能、staging 与正式发布验收不作为本窗口开发准入。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

#### 迭代 I6：W25–W26

<a id="task-ui-506"></a>
##### UI-506：Reconciliation 与账本差异

- task_id: `UI-506`
- task_type: `FRONTEND`
- iteration: `I6`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-505", "UI-507", "BFF-FE-009", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I5"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Reconciliation 与账本差异
- 接口绑定：C15、C16
- 验收重点：不能手工改账；差异贯通 Order/Fill/Performance/Alert/Audit

<a id="task-ui-p22"></a>
##### UI-P22：P22-Reconciliation-and-Funds-Ledger-High-Fidelity-v1.png

- task_id: `UI-P22`
- task_type: `FRONTEND`
- iteration: `I6`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-506", "UI-VIS-000", "BFF-FE-006", "BFF-FE-007", "BFF-FE-009", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-008", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-WINDOW:I5"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P22-Reconciliation-and-Funds-Ledger-High-Fidelity-v1.png`
- 实际页面/路由交付：`/reconciliation`、`/reconciliation/:runId`
- 契约绑定：C09、C10、C15
- 所属阶段：FEP-5
- 页面级完成标准：对账运行、差异、资金账本、证据、重跑请求与状态流落地；无手工改账入口

<a id="acceptance-frontend-gate-g5"></a>
##### FRONTEND-GATE:G5：验收检查点

按 FEP-5 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G5",
  "acceptance_window": "I6",
  "depends_on": [
    "FE:UI-507",
    "FE:UI-P12",
    "FE:UI-501",
    "FE:UI-P08",
    "FE:UI-502",
    "FE:UI-P09",
    "FE:UI-503",
    "FE:UI-504",
    "FE:UI-P10",
    "FE:UI-505",
    "FE:UI-P20",
    "FE:UI-P11",
    "FE:UI-506",
    "FE:UI-P22",
    "CORE-GATE:X3-SERVICE",
    "SERVICE:X06",
    "PROVIDER:ALL"
  ],
  "required_scope": "按 FEP-5 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-5"></a>
##### FEP-5：风险与执行闭环

- task_id: `FEP-5`
- task_type: `MILESTONE`
- iteration: `I6`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "UI-P07", "CORE-GATE:X3-SERVICE", "SERVICE:X06", "UI-507", "UI-P12", "UI-501", "UI-P08", "UI-502", "UI-P09", "UI-503", "UI-504", "UI-P10", "UI-505", "UI-P20", "UI-P11", "UI-506", "UI-P22", "FRONTEND-GATE:G5", "FRONTEND-WINDOW:I5"]
- core_prerequisites: ["CORE-GATE:X3-SERVICE", "SERVICE:X06"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P08–P12、P20、P22；Portfolio/Risk、Proposal、Trade Ticket、Approval、Order、Reconciliation、Audit
- 主要后端依赖：CORE-GATE:X3-SERVICE、SERVICE:X06
- 交付节点与放行条件：G5 功能准入验证七类高风险用例全绿、完整证据链可还原、无直连 venue；≤5 分钟还原在 RELEASE 指定数据规模验收
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I7：W27–W28

<a id="task-ui-402"></a>
##### UI-402：OHLCV/K 线、指标、订单/成交标记

- task_id: `UI-402`
- task_type: `FRONTEND`
- iteration: `I7`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-401", "UI-505", "BFF-FE-005", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G5"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：OHLCV/K 线、指标、订单/成交标记
- 接口绑定：C12、C09
- 验收重点：series 元数据完整；切 venue/product 清空旧 series；断流停在最后确认时间

<a id="task-ui-p19"></a>
##### UI-P19：P19-Candlestick-and-Market-Analysis-High-Fidelity-v4.png

- task_id: `UI-P19`
- task_type: `FRONTEND`
- iteration: `I7`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-402", "UI-VIS-000", "BFF-FE-005", "BFF-FE-006", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G5"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P19-Candlestick-and-Market-Analysis-High-Fidelity-v4.png`
- 实际页面/路由交付：`/markets/:symbol/chart`
- 契约绑定：C09、C12
- 所属阶段：FEP-4
- 页面级完成标准：Symbol/Venue/Product/Timezone/Quality 可选；周期仅 1m/5m/15m/1h/4h/1D/1W/自定义；K 线、指标、事件、数据缺口和元数据落地

<a id="task-ui-403"></a>
##### UI-403：Performance、归因、周期报表

- task_id: `UI-403`
- task_type: `FRONTEND`
- iteration: `I7`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-506", "BFF-FE-008", "BFF-FE-009", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G5"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Performance、归因、周期报表
- 接口绑定：C14、C15
- 验收重点：金额/币种/估值/账本版本/口径齐全；未对账数据标为 provisional

<a id="task-ui-p21"></a>
##### UI-P21：P21-Performance-and-Reports-High-Fidelity-v1.png

- task_id: `UI-P21`
- task_type: `FRONTEND`
- iteration: `I7`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-403", "UI-VIS-000", "BFF-FE-008", "BFF-FE-009", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-010", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G5"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P21-Performance-and-Reports-High-Fidelity-v1.png`
- 实际页面/路由交付：`/performance`、`/performance/reports/:reportId`
- 契约绑定：C14、C15
- 所属阶段：FEP-4
- 页面级完成标准：收益、归因、回撤、费用、口径、provisional 和报表生成/下载落地

<a id="acceptance-frontend-gate-g4"></a>
##### FRONTEND-GATE:G4：验收检查点

按 FEP-4 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G4",
  "acceptance_window": "I7",
  "depends_on": [
    "FE:UI-401",
    "FE:UI-P18",
    "FE:UI-402",
    "FE:UI-P19",
    "FE:UI-403",
    "FE:UI-P21",
    "CORE-GATE:X3-SERVICE",
    "PROVIDER:ALL"
  ],
  "required_scope": "按 FEP-4 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-4"></a>
##### FEP-4：市场与分析

- task_id: `FEP-4`
- task_type: `MILESTONE`
- iteration: `I7`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "UI-P07", "CORE-GATE:X3-SERVICE", "UI-401", "UI-P18", "UI-402", "UI-P19", "UI-403", "UI-P21", "FRONTEND-GATE:G4"]
- core_prerequisites: ["CORE-GATE:X3-SERVICE"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P18–P19、P21；市场目录、报价、K 线、订单标记、收益与报表
- 主要后端依赖：CORE-GATE:X3-SERVICE
- 交付节点与放行条件：G4：来源/venue/as_of/quality/口径完整；断流不拼接；provisional 正确
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I8：W29–W30

<a id="task-ui-603"></a>
##### UI-603：Alerts 收件箱

- task_id: `UI-603`
- task_type: `FRONTEND`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-506", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Alerts 收件箱
- 接口绑定：C16
- 验收重点：BFF 授权/去重/限速；ack 仅代表已读，不代表解决；离线禁写

<a id="task-ui-p23"></a>
##### UI-P23：P23-Alerts-Inbox-and-Response-High-Fidelity-v1.png

- task_id: `UI-P23`
- task_type: `FRONTEND`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-603", "UI-VIS-000", "BFF-FE-007", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P23-Alerts-Inbox-and-Response-High-Fidelity-v1.png`
- 实际页面/路由交付：`/alerts`、`/alerts/:alertId`
- 契约绑定：C10、C11、C16
- 所属阶段：FEP-6
- 页面级完成标准：授权收件箱、详情、ack/unack、处置导航、订阅与实时状态落地；ack 不等于 resolved

<a id="task-ui-601"></a>
##### UI-601：Operations/Incident/Runbook

- task_id: `UI-601`
- task_type: `FRONTEND`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-603", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Operations/Incident/Runbook
- 接口绑定：C11、C16
- 验收重点：只能触发服务端批准 actionId；无任意命令/脚本入口

<a id="task-ui-p13"></a>
##### UI-P13：P13-Operations-and-Incident-Detail-High-Fidelity-v2.png

- task_id: `UI-P13`
- task_type: `FRONTEND`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-601", "UI-VIS-000", "BFF-FE-010", "BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P13-Operations-and-Incident-Detail-High-Fidelity-v2.png`
- 实际页面/路由交付：`/operations`、`/operations/incidents/:incidentId`
- 契约绑定：C11、C16
- 所属阶段：FEP-6
- 页面级完成标准：7 个服务健康视图、告警、incident 时间线、Runbook 检查与受控 actionId 调用落地

<a id="task-ui-602"></a>
##### UI-602：Admin 治理

- task_id: `UI-602`
- task_type: `FRONTEND`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-601", "BFF-FE-001", "BFF-FE-010", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：Admin 治理
- 接口绑定：C11、C01
- 验收重点：成员、角色、policy、capability、flag 全量审计；最后管理员保护；职责分离

<a id="task-ui-p14"></a>
##### UI-P14：P14-Admin-Governance-High-Fidelity-v2.png

- task_id: `UI-P14`
- task_type: `FRONTEND`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["UI-602", "UI-VIS-000", "BFF-FE-001", "BFF-FE-010", "BFF-FE-000", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-011", "PROVIDER:ALL", "FRONTEND-GATE:G4"]
- core_prerequisites: []
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：`P14-Admin-Governance-High-Fidelity-v2.png`
- 实际页面/路由交付：`/admin/members`、`/admin/policies`、`/admin/capabilities`、`/admin/flags`
- 契约绑定：C01、C11
- 所属阶段：FEP-6
- 页面级完成标准：成员/角色/策略/能力/开关、版本冲突、职责分离、签名与审计落地

<a id="acceptance-frontend-gate-g6"></a>
##### FRONTEND-GATE:G6：验收检查点

按 FEP-6 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G6",
  "acceptance_window": "I8",
  "depends_on": [
    "FE:UI-603",
    "FE:UI-P23",
    "FE:UI-601",
    "FE:UI-P13",
    "FE:UI-602",
    "FE:UI-P14",
    "CORE-GATE:X3-SERVICE",
    "SERVICE:X06",
    "PROVIDER:ALL"
  ],
  "required_scope": "按 FEP-6 业务范围、页面功能标准及第 7 节 INTEGRATION 要求，验证真实 BFF/服务的权限、实时、错误、审计、关键浏览器用例与恢复一致性后评估阶段 READY；受影响安全与正确性缺陷必须修复。页面闭环后复审 closes_core 的完整核心功能；性能目标、staging/部署、完整视觉/浏览器矩阵及正式签署由 RELEASE 收口。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-6"></a>
##### FEP-6：Web 运维治理

- task_id: `FEP-6`
- task_type: `MILESTONE`
- iteration: `I8`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "UI-P21", "CORE-GATE:X3-SERVICE", "SERVICE:X06", "UI-603", "UI-P23", "UI-601", "UI-P13", "UI-602", "UI-P14", "FRONTEND-GATE:G6"]
- core_prerequisites: ["CORE-GATE:X3-SERVICE", "SERVICE:X06"]
- closes_core: ["CORE:X06"]
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P13、P14、P23；Operations、Admin、Alerts
- 主要后端依赖：CORE-GATE:X3-SERVICE、SERVICE:X06
- 交付节点与放行条件：G6：受控 Runbook、职责分离、Web 通知、权限与离线禁写通过
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I9：W31–W32

<a id="acceptance-frontend-gate-g7"></a>
##### FRONTEND-GATE:G7：验收检查点

G7 在 I9 完成 Paper/Shadow 全业务链功能联调、权限/审计/恢复及关键浏览器回归，汇总所有性能/兼容/视觉基线和待整改项后评估 INTEGRATION 阶段 READY，形成 Beta 功能候选；核心完整功能范围保持独立验证。Beta 正式发布必须另通过 RELEASE-GATE:BETA，不能用功能候选替代性能、长稳、部署或签署。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G7",
  "acceptance_window": "I9",
  "depends_on": [
    "CORE-GATE:R1",
    "CORE-GATE:S2",
    "CORE-GATE:X3",
    "CORE:TP01",
    "PROVIDER:ALL",
    "FRONTEND-GATE:G1",
    "FRONTEND-GATE:G2",
    "FRONTEND-GATE:G3",
    "FRONTEND-GATE:G4",
    "FRONTEND-GATE:G5",
    "FRONTEND-GATE:G6"
  ],
  "required_scope": "G7 在 I9 完成 Paper/Shadow 全业务链功能联调、权限/审计/恢复及关键浏览器回归，汇总所有性能/兼容/视觉基线和待整改项后评估 INTEGRATION 阶段 READY，形成 Beta 功能候选；核心完整功能范围保持独立验证。Beta 正式发布必须另通过 RELEASE-GATE:BETA，不能用功能候选替代性能、长稳、部署或签署。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-7"></a>
##### FEP-7：硬化与 Beta

- task_id: `FEP-7`
- task_type: `MILESTONE`
- iteration: `I9`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "UI-P01", "UI-P02", "UI-P03", "UI-P04", "UI-P05", "UI-P06", "UI-P07", "UI-P08", "UI-P09", "UI-P10", "UI-P11", "UI-P12", "UI-P13", "UI-P14", "UI-P15", "UI-P17", "UI-P18", "UI-P19", "UI-P20", "UI-P21", "UI-P22", "UI-P23", "WEB-101", "CORE-GATE:R1", "CORE-GATE:S2", "CORE-GATE:X3", "CORE:TP01", "FRONTEND-GATE:G7"]
- core_prerequisites: ["CORE-GATE:R1", "CORE-GATE:S2", "CORE-GATE:X3", "CORE:TP01"]
- closes_core: []
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:BETA；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：全业务链功能回归、可访问性与安全、故障恢复；汇总兼容/性能/视觉基线和待优化项，在 RELEASE 完成全量目标验收
- 主要后端依赖：CORE-GATE:R1、CORE-GATE:S2、CORE-GATE:X3、CORE:TP01
- 交付节点与放行条件：G7：Paper + Shadow Beta 功能候选通过，功能阻断级缺陷为 0；发布需另通过 RELEASE-GATE:BETA
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

#### 迭代 I10：W33–W34

<a id="acceptance-frontend-gate-g8"></a>
##### FRONTEND-GATE:G8：验收检查点

G8 在 I10 以本机真实 UI/BFF/服务组合及自有合成 venue 验证 testnet 条件入口、UI/API flag 关闭不可达、模式/权限/MFA/职责分离、审批与审计恢复，评估 INTEGRATION 阶段 READY；实际 testnet 连接和运行、外部环境、性能/长稳/部署与正式签署全部归 RELEASE-GATE:LIVE-READINESS，实际运行仍须有效范围授权，不启用生产实盘。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。

```json
{
  "checkpoint_id": "FRONTEND-GATE:G8",
  "acceptance_window": "I10",
  "depends_on": [
    "CORE:L01",
    "CORE:L02",
    "SERVICE:L03",
    "SERVICE:L04",
    "CORE-GATE:L4-SERVICE",
    "PROVIDER:ALL",
    "FE:FEP-7"
  ],
  "required_scope": "G8 在 I10 以本机真实 UI/BFF/服务组合及自有合成 venue 验证 testnet 条件入口、UI/API flag 关闭不可达、模式/权限/MFA/职责分离、审批与审计恢复，评估 INTEGRATION 阶段 READY；实际 testnet 连接和运行、外部环境、性能/长稳/部署与正式签署全部归 RELEASE-GATE:LIVE-READINESS，实际运行仍须有效范围授权，不启用生产实盘。 外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "INTEGRATION",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

<a id="task-fep-8"></a>
##### FEP-8：M5 评审准备

- task_id: `FEP-8`
- task_type: `MILESTONE`
- iteration: `I10`
- stage_gate: {"stage":"INTEGRATION","status":"NOT_ASSESSED","input_digest":null,"evidence":[]}
- depends_on: ["BFF-FE-000", "BFF-FE-001", "BFF-FE-002", "BFF-FE-003", "BFF-FE-004", "BFF-FE-005", "BFF-FE-006", "BFF-FE-007", "BFF-FE-008", "BFF-FE-009", "BFF-FE-010", "BFF-FE-011", "FEP-7", "CORE:L01", "CORE:L02", "SERVICE:L03", "SERVICE:L04", "CORE-GATE:L4-SERVICE", "FRONTEND-GATE:G8"]
- core_prerequisites: ["CORE:L01", "CORE:L02", "SERVICE:L03", "SERVICE:L04", "CORE-GATE:L4-SERVICE"]
- closes_core: ["CORE:L03", "CORE:L04"]
- development_status: `UNSPECIFIED`
- workflow: `DEVELOPMENT → REVIEW_READY → IN_REVIEW → CHANGES_REQUESTED → FIX_VALIDATION → RE_REVIEW → ACCEPTED`
- 阶段执行：本机功能实现与真实模块组合验证；受影响成功/拒绝/恢复及基本浏览器用例必须通过；合成数据及受控边界的结果注明范围。发布阶段：RELEASE-GATE:LIVE-READINESS；按责任任务适用范围验收：Supabase/PostgreSQL迁移/RLS/事务、真实IdP/Auth/私有Storage、外部数据源/venue/testnet、staging/部署、远程同SHA CI及全部性能/容量/长稳/恢复时限，在有效环境与用途授权下按候选完整源码SHA实际验收；原阈值不降低，未执行NOT_RUN。
- 验收边界：外部环境及性能指标全部移交RELEASE；DEVELOPMENT与INTEGRATION只验证本机真实模块的功能、契约、权限、数据完整性、幂等/恢复和deadline语义；目标回执NOT_RUN，不代替正式ACCEPTED。
- 需求描述：P10/P11 的 testnet 条件入口、MFA 与双人审批
- 主要后端依赖：CORE:L01、CORE:L02、SERVICE:L03、SERVICE:L04、CORE-GATE:L4-SERVICE
- 交付节点与放行条件：G8：本机真实 UI/BFF/服务组合验证 testnet 条件入口、flag 关闭不可达、MFA/职责分离、模式/权限/审批和审计恢复；实际 testnet 连接、运行与全部环境/性能验收归 RELEASE-GATE:LIVE-READINESS，不开启生产实盘
- 范围说明：本记录位于功能窗口末尾；依赖子任务和对应 Gate 的阶段准入满足后可完成本里程碑功能评估，正式全量复审仍独立。closes_core 是后续完整核心功能/正式复审映射，不作为页面前置。

## 5. 接口对接清单与契约基线

### 5.1 契约状态说明

《可执行开发计划》冻结的是领域对象、协议元数据、错误稳定性、幂等/审计要求和业务时序，并没有给出第一期 22 个 Web Terminal 页面完整 REST URL 与统一 JSON envelope。下表中的 C01–C17 是前端需要 BFF 冻结的**逻辑契约包**，不是对尚未发布 HTTP 路径的臆造。实际路径、method、分页格式和 envelope 必须以版本化 OpenAPI 为准；页面只能引用生成 client。

### 5.2 页面—接口—后端任务映射

| 契约 | 页面 | 必需 Query/Command/Realtime | 关键请求/响应字段 | 后端计划依赖 |
|---|---|---|---|---|
| C01 Session/Context | P01、全局、P15 | session、workspace/account context、capabilities、reauth/MFA、logout | actorId、tenantId、workspaceId、accountId、mode、environment、capabilities、mfaState、expiresAt | F06、L03 |
| C02 Command Center | P02 | summary query、authorized event projection | riskPosture、dataFreshness、pendingApprovals、failedRuns、orderSummary、alerts、sampledAt | F09、R03、X01–X06 |
| C03 Research Runtime | P03/P04 | list/create/get/cancel、SSE stream/replay | runId、capability、dataSnapshotId、budget、deadlineAt、status、inputHash、engineVersion、artifactRefs、evidenceRefs、sequence、correlationId | F07/F08、R03、U01 |
| C04 Snapshot/Artifact | P04/P05 | list/get snapshot、get artifact/attachment | snapshotId、schemaVersion、window、sources、quality、contentHash、licenseLabel、capturedAt、maxAge；artifactId、hypothesis、summary、engine/prompt/codeVersion、environmentHash | R02/R03、F05 |
| C05 Strategy | P06/P07 | draft list/get/save、static check、backtest create/get、release create/get/list | strategyId、draftVersion、expectedVersion、parameters、snapshotId、reportHash、leakViolations、source/image/parameterHash、allowedTargets、approvalState | S01–S04 |
| C06 Portfolio/Risk | P02/P08 | portfolio/risk query、kill switch command、authorized realtime | accountId、asOf、stale、positions、Money/Decimal values、P&L、exposure、hitRules、limitIds、verdict、killSwitch | X01/X02 |
| C07 Proposal/Risk Evaluation | P09/P20 | list/get proposal、request evaluation | proposalId、accountId、symbol、action、quantity/notional、signal、rationale、counterViews、evidenceRefs、expiresAt、`executable=false`；decisionId、verdict、hitRules、limitIds、signer、decidedAt | R04、X02 |
| C08 Approval/MFA | P07/P10/P20 | list/get/decide approval、MFA challenge、reauth | approvalId、originator、objectVersion、decision、reason/note、mfaChallengeRef、status、expiresAt、signature、commandRef | F06、X03、L03 |
| C09 Command/Order | P11/P19/P20 | submit command ref、list/get order、cancel request、order event stream | commandId、decisionId、accountId、venue、symbol、intent、side、quantity、prices、idempotencyKey、expiresAt；orderId、status、filledQuantity、averageFillPrice、Fill、sequence、correlationId | X03/X04、L01 |
| C10 Audit/Export | P04/P07/P09–P13 | search events、get evidence chain、create/poll/download export | correlationId、causationId、actor、occurredAt、objectRef、hash、redactedPayload、retention；exportId、scope、status、expiresAt、signedUrl | F05、X06 |
| C11 Ops/Admin | P13/P14 | health/incident/admin query、approved runbook/member/policy/capability/flag commands | service health、latency、DLQ、incidentId、actionId、configVersion、memberId、role/capability/flag、audit ref | F06/F09、X06 |
| C12 Market/Candle | P18/P19/P20 | catalog/quote/candle query、authorized realtime | canonicalSymbol、productType、venue、bid/ask、fee/slippageEstimate、lotSize、source、asOf、latency、quality；interval、timezone、OHLCV、gaps | R01/R02、L01 |
| C13 Trade Preflight | P20 | order capabilities、preflight/risk refresh | accountId、mode、venue options、supportedIntent、balance/position snapshot refs、quoteRef、limit impact、objectVersion、blockingReasons | X01–X03、L01 |
| C14 Performance/Report | P21 | performance query、create/poll/download report | accountId、currency、method、ledgerVersion、valuationSnapshotId、coverage、asOf、P&L/return/drawdown/fees、provisional；period/reportVersion | X01/X05，需 BFF 新增页面模型 |
| C15 Reconciliation | P22/P21/P11 | list/get/request rerun、status realtime | runId、accountId、venue、window、ledgerVersion、matched/investigating/resolved、breakId、internal/external values、reason、evidenceRefs | X05 |
| C16 Alert/Notification | P02/P13/P23、全局 | list/get/ack/unack/subscriptions、authorized realtime | alertId、severity、domain、account/venue、status、occurredAt、asOf、objectRef、correlationId、ackActor/At | F09、X05/X06 |
| C17 Settings/Browser Platform | P15/P17 | profile/session/device/notification/download query/commands | locale、timezone、theme、session/device、browser notification permission、download record；不得包含领域秘密 | F06、F09 |

### 5.3 字段与序列化规则

| 类型/字段 | 统一规则 | 前端处理 |
|---|---|---|
| `CommandMetadata` | `request_id`、`tenant_id`、`workspace_id`、`actor`、`correlation_id`、可选 `causation_id`、`mode`、`environment`、`issued_at` | tenant/actor 从受信会话由 BFF 注入，客户端不得伪造；页面至少能显示 correlation ID |
| ID | 领域主键和引用使用 UUID；显示层不解析 ID 业务含义 | 视为 opaque string，不排序、不重组、不放敏感上下文到 URL |
| 时间 | Proto Timestamp / PostgreSQL `timestamptz`；HTTP 使用带时区 RFC 3339 | 内部保持 UTC；展示按用户时区并同时提供原始时间；禁止本地无时区字符串 |
| 精确数值 | 数量/价格/比率采用 `DecimalValue.value` 字符串；金额采用 `MoneyValue {currencyCode, units, nanos}` | 禁止先转 IEEE-754 number 再做交易计算；用十进制定点库格式化 |
| 枚举 | 以 F03 Proto 为准：mode、quality、verdict、order status、intent、side 等 | 未知枚举必须显示“未知/需升级”并阻断高风险动作，不能落入默认 allow |
| hash/version | content/source/image/parameter/input/environment/report hash 与 objectVersion/ETag | 完整保留；危险动作前刷新并携带 expected version，409 不自动覆盖 |
| 可空性 | OpenAPI `required`/nullable 与 Proto field behavior 对齐 | 不用空字符串代替缺失；新增可选字段向后兼容，移除/改义属于 breaking |
| 分页/排序 | BFF 必须统一 cursor、pageSize、sort、filter 结构 | 大表只做服务端分页/排序/筛选；游标不持久化为领域数据 |
| 敏感字段 | BFF 先脱敏；Vault/venue/model secret 永不进入 schema | 日志、URL、analytics、Sentry、导出与浏览器存储均做负向检查 |

JSON 字段命名以 OpenAPI 生成结果为准。若采用 Proto JSON 映射，应统一输出 lowerCamelCase；任何 snake_case ↔ camelCase 转换只能集中在生成/transport 层，页面组件不得自行映射。

### 5.4 请求、响应与错误格式冻结项

G0 期间由 BFF 与前端共同冻结以下内容：

- 认证使用 HttpOnly/Secure/SameSite cookie 或等价服务端会话；浏览器不持久化长期 token。
- 所有 command 携带 `Idempotency-Key`；同一业务意图重试复用原 key，新意图生成新 key。高风险请求同时携带对象版本、短时 reauth/MFA 引用和客户端 request ID。
- BFF 返回或响应头携带 `correlation_id`；任何失败提示、订单详情和 Audit 跳转均可引用。
- 成功响应需区分同步完成（200/201）、异步受理（202 + job/run/status ref）和无内容（204）；前端不得把 202 显示为业务完成。
- 错误 envelope 至少冻结 `code`、安全可展示 `message`、`correlationId`、可选 `fieldErrors`、`retryAfter`、`currentVersion`；不得把堆栈、SQL、路径或凭据返回客户端。
- 401、403、404、409、422、429、5xx 严格执行设计规范第 6.2 节；未知错误 fail closed。
- 数据列表统一冻结 cursor/pageSize/nextCursor，实时事件统一冻结 streamId/sequence/eventId/occurredAt/correlationId/payloadVersion。

### 5.5 三条关键交互时序

**研究任务：** 获取 session/capability 与快照 → `create research`（Idempotency-Key）→ 接收 202/runId/correlationId → 以 sequence 订阅 SSE → 重复/乱序去重 → 断线按 afterSequence 回补 → cancel 返回 `cancel_requested` → 仅服务端终态显示 Cancelled/Succeeded/Failed → Artifact/Evidence 可跳 Audit。

**策略发布：** 加载 draft + objectVersion → 保存携带 expectedVersion → static check → 固定 DataSnapshot 发起 backtest → 校验环境/成本/泄漏报告 → 创建不可变 Release → 服务端返回 allowedTargets → 提交审批 → 审批通过后才可显示 Paper/Shadow 部署动作；任何 409/版本变化退回复核。

**建议到订单：** Proposal（不可执行）→ 刷新 proposal/snapshot/quote/account/venue/mode → request RiskDecision → deny 时终止；approval_required 时 MFA/审批且禁止自批 → 服务端签发短时 TradeCommand → 提交仅传 command ref + Idempotency-Key → Execution Gateway 再校验 → 返回受理/订单 ref → 订阅 Order/Fill 事实；过期、陈旧、kill switch、venue 异常或版本变化均退回相应前置步骤。

### 5.6 页面 API 任务入口与执行规则

`BFF-FE-000`–`BFF-FE-011` 的唯一任务定义及全量排期已前置到第 4.1 节。本节保留契约规则入口；C01–C17 仅为接口映射，不与前端任务混排。

#### 5.6.1 API 缺口任务执行规则

- `BFF-FE-000` 由 BFF TL 主责，Codex 综合前端、QA、安全与领域审阅维度拟稿，由项目用户确认；其余任务必须在对应页面进入 Sprint 前一个 Sprint 达到 `Reviewed + Mocked`。
- 每项 operation 必须提供：权限/capability、请求/响应示例、字段 required/nullable、枚举、分页/排序、缓存与 `asOf`、错误码、幂等、对象版本、审计、限流、实时恢复和敏感字段说明。
- 对总开发计划已经存在的服务接口，BFF 只能做授权、裁剪、聚合和页面模型转换，不复制领域规则；风险结论、审批状态、订单事实和账本状态仍由原服务权威产生。
- 新增页面 API 不得扩展产品范围：不增加 workspace 切换、生产 Assisted Live、Guarded Live、任意 Runbook 命令、手工改账、客户端 command 构造或 venue 直连。
- BFF 契约未实现时允许同 schema mock；契约为 Draft、页面使用手写 DTO、provider 功能 contract 未通过或真实 BFF 行为与 mock 不一致时，对应 `UI-Pxx` 不能进入 `Integrated`。staging 行为不一致仍阻塞正式 `Done`/发布。

### 5.7 逐页接口覆盖 Gate

每个页面开始开发前建立一行 `Page API Coverage` 记录，最少包含：页面 ID、有效设计稿、路由、query operationId、command operationId、realtime channel/operationId、权限/capability、错误码集合、数据新鲜度字段、OpenAPI 版本、mock 版本、BFF owner 和最后验证时间。满足以下条件才算接口覆盖完成：

1. 页面展示的每个服务端字段都能追溯到 OpenAPI/领域 schema；不存在仅见于设计稿而无契约来源的业务字段。
2. 页面每个按钮均映射为明确的本地 UI 动作或 BFF command；危险按钮必须有服务端可操作性与版本校验。
3. 列表、详情、异步任务和实时事件分别有分页、终态、断线恢复和错误契约；不能用轮询/本地状态暗中替代未定义时序。
4. 默认、加载、空、错误、无权、陈旧、离线和危险确认状态均有 fixture，功能联调以真实 BFF 验证；RELEASE 在 staging 再验证目标环境行为。
5. 契约变更报告能从 operationId 反查所有受影响的 `UI-Pxx` 任务和视觉/E2E 基线。

## 6. 联调与一致性校验机制

### 6.1 联调流水线

1. **契约设计：** BFF 在实现前提交 OpenAPI/Proto 变更、示例和兼容说明；前端和 QA 在 PR 内评审字段、状态、权限、错误与时序。
2. **生成与 mock：** CI 生成 TS client、Zod/fixture 类型；MSW 从同一契约提供成功、拒绝、冲突、限流、断流、陈旧与权限场景。
3. **Provider contract：** A1–A6 开发阶段验证实际代码、同源 schema/示例、权限/错误/幂等/恢复及 provider harness；I1–I10 使用本机真实 consumer/provider 模块组合验证功能链。外部端口可用自有合成输入/adapter，须记录替代边界，不能以纯 MSW 页面演示证明服务实现。所有外部目标连接、staging、testnet、性能及签署在 RELEASE 完成。
4. **功能联调：** 按“单接口 smoke → 页面 query → command → realtime → 审计链 → 故障恢复”的顺序，每个接口记录 owner、环境、版本、证据和遗留项。
5. **Gate 回归：** 按变更和依赖运行对应功能/契约回归、受影响安全场景及基本浏览器 E2E；功能链闭环时运行完整业务旅程。RELEASE 运行全量目标环境/浏览器/性能回归。该阶段必需功能契约失败仍阻塞其准入，不以重跑筛除失败。

### 6.2 一致性自动校验

- `buf breaking`、Proto/JSON Schema/OpenAPI diff、TS client regenerate clean check 必须通过。
- 响应 fixture 使用 schema validator；required/enum/format/additionalProperties 策略一致。
- 前端禁止直接 import 内部数据库 DTO 或第三方 Engine/venue 类型；ESLint boundary rule 强制 `page → api-client/domain-ui`。
- 所有 command 测试断言 Idempotency-Key、request ID、correlation ID、expectedVersion 和审计事件。
- Realtime 测试覆盖重复、乱序、断连、漏通知、权限撤销和 schema version 不兼容。
- 敏感字段字典对网络响应、前端日志、监控事件、URL、下载和浏览器存储做自动扫描。

### 6.3 跨域与浏览器安全配置

| 项目 | 要求 |
|---|---|
| 同源优先 | 生产通过同站 BFF 路由；若必须跨域，仅允许明确的 Web/预览 origin allowlist，禁止 `*` + credentials |
| CORS | 限定 methods/headers；允许 `Idempotency-Key`、request/correlation/trace headers；预检缓存有版本化变更测试 |
| Cookie/CSRF | Secure、HttpOnly、SameSite；所有有副作用请求校验 CSRF token/origin |
| CSP | 默认拒绝；script/style/connect/img/font/frame 分别 allowlist；Sentry/WS/SSE 域名单独审计 |
| 下载/上传 | 短时签名 URL、内容类型/大小限制、恶意内容扫描、水印与导出审计；不让 Engine 直接读取本地文件 |
| 缓存 | 会话/受限响应 `no-store`；静态制品内容寻址；Service Worker 不缓存命令响应或敏感审计数据 |

### 6.4 接口变更同步机制

- 契约仓库/目录是单一事实来源；每个变更必须含 owner、版本、兼容性等级、影响页面、迁移期和回滚方案。
- 非 breaking 新增字段：前端必须容忍并记录覆盖；breaking 变更：新增 `/vN` 或兼容窗口，不允许直接修改既有语义。
- 每周一次 30 分钟契约评审；P0 阶段每日异步更新阻塞项。接口状态统一为 `Draft → Reviewed → Mocked → Implemented → Integrated → Verified`。
- 紧急变更必须由 BFF、前端、QA 和风险 owner 同意，带 feature flag/canary；高风险字段不允许口头或聊天消息直接变更。
- CI 自动生成契约变更报告并 @ 影响页面 owner；生成 client 有 diff 时不得跳过前端评审。

## 7. 测试与验收标准

### 7.1 测试分层与执行阶段

保留所有测试和验收目标，按变更影响与阶段执行。有意义的功能回归不能因“性能后置”被删除；修复后通过必要检查即可继续实现下一功能，只有新变更、失败或未解决疑点才扩大或重复验证。

| 层级 | 覆盖要求 | 开发/功能联调要求 | 发布前要求 |
|---|---|---|---|
| 单元 | 领域组件/状态/格式化/权限解释/错误映射/stream reducer；TypeScript 新增领域代码行覆盖率 ≥80%，关键风险状态分支 100% | 受影响代码和 P0 状态分支必须验证，不得用无断言/跳过测试充数；覆盖退化需修复 | 重跑候选相关回归，保留实际覆盖证据 |
| 组件 | 默认、加载、空、错误、无权、陈旧、离线、危险确认；Storybook + RTL + axe | 所交付组件状态齐全，严重/高等级 a11y 问题为 0 | 覆盖全部 P01–P15/P17–P23 并签署 |
| 契约 | OpenAPI、错误码、枚举、精度、分页、幂等、冲突、实时事件 | 开发校验 schema/生成/实现；真实 consumer/provider 不一致阻断相关功能联调 | 候选版本与 staging 契约全绿 |
| 集成 | 缓存/失效、OIDC、MFA、SSE/WS、平台 adapter、真实服务 | 以本机真实 UI/BFF/服务模块组合验证业务链；外部端口替代范围须记录，纯 mock 演示不替代模块联调，correlation ID 不得丢失 | staging/部署身份、权限、实时与故障行为复验；差异未解决则阻发布 |
| E2E | 每角色关键 Web 旅程；研究、策略、风险审批、订单、审计、对账、运维 | 逐功能执行基本浏览器回归，链路闭环时 P0 旅程通过率 100%，不得重跑筛除 flaky | 全业务链和目标浏览器完整 E2E 矩阵通过 |
| 视觉 | 1280/1440、768 折叠、390 只读、深浅主题、危险状态 | 建立 1440 基线，验证安全含义/可读性/关键布局，记录差异 | 关键页面无未批准差异；其余像素差异阈值 ≤0.5%，完成全矩阵和签署 |
| 兼容 | Chromium/Firefox/Safari 当前稳定版；200% 缩放 | 主要目标浏览器关键功能/键盘及缩放可用，定期扩大采样并记录问题 | 完整矩阵的 P0 功能/布局/键盘任一失败均阻发布 |
| 安全 | 越权、IDOR、CSRF/CSP/CORS、XSS、敏感字段、缓存、离线、依赖与 secret scan | 对应权限/数据/交易边界绕过为 0，已知相关高危问题先修复再联调；敏感字段扫描和负向测试保留 | 全范围高危=0、未豁免中危=0、交易边界绕过=0，供应链签署 |
| 性能与运行 | 第 7.4 节全部阈值、容量、恢复、长稳、部署 | 采样诊断与趋势；无界积压、资源耗尽、明显不可用或架构不可行阻塞相关功能 | 在授权目标环境/负载/时长验证全部阈值及发布运维证据 |

### 7.2 必测功能 E2E 场景

以下语义在对应功能开发时实现并回归，跨模块链路在 INTEGRATION 验证；RELEASE 再取得发布候选的完整目标环境证据。

1. 研究员选择可用 DataSnapshot，创建研究，接收流式结果，断线续传，取消并进入 Artifact/Audit；全过程无订单入口。
2. 量化开发完成草稿、静态检查、固定快照回测、Release 和审批申请；验证失败/未审批/Assisted Live 均不可部署。
3. 交易员从有效 Proposal 或 Trade Ticket 发起风险评估；分别覆盖 allow、deny、approval-required、过期、重复、数据陈旧、kill switch。
4. 审批人完成 MFA 与审批；自批、第二人缺失、版本冲突、额度变化、命令过期全部拒绝。
5. 已批准 command 重复提交 1,000 次仅产生一个命令/订单事实；这是幂等正确性要求，保留可重放功能测试，页面不在 ack 前显示成交。
6. 订单部分成交、拒绝、撤单延迟、断流回补；每个 Fill 可追溯 Proposal、RiskDecision、Approval、Command、Release 和 Snapshot。
7. 对账注入差异后，Orders/Performance/Alerts/Audit 一致显示 provisional/Investigating，且 UI 无改账入口。
8. 断网后 Web 全部写操作禁用；恢复连接后不自动提交旧意图。

### 7.3 页面还原度与功能完整性

- P01–P15、P17–P23 的页面、路由、角色、主操作、文案、字段和状态逐功能对照设计，功能闭环目标仍为第一期 Web 需求覆盖率 100%；分母按开发、联调、发布验收分别统计。
- 开发期建立 App Shell、ModeBanner、DataGrid、EvidenceTimeline、RiskDecision、OrderStateMachine、DangerConfirmDialog 的视觉基线与关键状态测试；RELEASE 由 Codex 汇总设计 owner 负责的完整视觉矩阵证据，项目用户确认，关键页面设计验收评分 ≥95/100。
- 金融数值的币种、精度、时区、`as_of` 与口径，以及证据对象的 hash/版本/关联 ID，属于开发正确性，必须随功能交付。
- 危险动作只有一个明确主按钮，默认不获焦；状态变化来自服务端事实。不得把安全语义缺陷记作可延期视觉优化。

### 7.4 性能基线与发布验收指标

开发/联调记录下列指标的样本环境、数据量、负载、分位数和缺口，用于发现架构问题及建立优化待办；一般预算不足不阻止继续实现无关功能。功能闭环后，在 staging 生产等价构建、受控网络与固定数据量采集 P75/P95 并完成 RELEASE 验收。原阈值全部保留，前端预算不得掩盖核心计划的 BFF SLO。

| 指标 | 发布前验收门槛 | 开发/联调责任 |
|---|---|---|
| 官网 Lighthouse | Performance/Accessibility/SEO/Best Practices 均 ≥90；核心内容 LCP ≤2.5s | 建立基线；SEO、隐私和安全功能先实现 |
| Terminal 首次可用 | 典型办公网络冷启动 LCP ≤2.5s，INP ≤200ms，CLS ≤0.1；认证后 App Shell 可交互 ≤3.0s | 记录构建/设备/网络；明显不可用须排查 |
| 路由切换 | 已缓存 shell 下 P95 ≤500ms 出现可用骨架，P95 ≤1.5s 呈现首批有效数据（不含明确异步任务） | 实现 loading/error/timeout 语义并采样 |
| 交互响应 | 本地输入/展开/筛选反馈 ≤100ms；大表滚动保持 ≥55 FPS | 高风险点击立即进入 pending 防重复提交是功能要求，开发时验证；响应/FPS 预算集中优化 |
| BFF | 同区域授权读 P95 <100ms；风险/组合读模型 P95 <300ms；命令校验 P95 <200ms | 记录连接/SQL/网络耗时；权限、幂等、错误和边界超时先正确 |
| 实时 | 已授权事件到 UI P95 ≤5s；研究取消确认 ≤2s | 取消/超时/终态/资源释放及断线恢复后无事件丢失/重复副作用随功能验证；端到端时限在联调采样，并于 RELEASE 指定环境验收 |
| Bundle | 每路由预算在 G0 基线化；共享首屏 JS 初始建议 gzip ≤250KB，发布前超限必须 ADR 与拆包证据 | 记录新增依赖和体积，不因普通超限重复阻塞功能实现 |

处理耗时、源数据年龄、事件到 UI 延迟与异常起点到持久化 ACK 的时限必须分别记录；持续写入、pending=0 或局部处理快速不能替代新鲜度/readiness 结论。R01 已知新鲜度降级和 B01 的 OPEN/PARTIAL 继续保留并限制相应用途；不自动阻塞其他可在契约/受控数据范围内开展的功能。30 分钟运行不证明 24 小时或部署长稳，任何超出现有 1800 秒、两标的、原内部用途的运行都须新范围授权；不得自动延长或复用过期批准。

### 7.5 完成定义与统计

| 记录 | 达成条件 | 可以支持的结论 |
|---|---|---|
| `development_status=COMPLETED` / `REVIEW_READY` | 代码、契约、基本回归、对应权限/数据/高危交互、观测、文档和回滚方案就绪 | 工程实现完成；包含历史完成事实，不等于新 `stage_gate` 已评估 |
| `UI Complete` | 页面、状态和同 schema fixture 可运行，组件/契约基本验证通过 | UI 实现完成；真实 BFF/服务联调仍待执行 |
| `Integrated` | 本机真实 provider/consumer 模块组合、权限、实时、错误、审计链和恢复验证通过，外部端口替代范围明确 | 功能联调完成；记录真实环境与能力边界，不能改称 staging/发布通过 |
| `stage_gate=READY` | 节点声明阶段的必要检查通过、全部前置阶段 READY、输入清单摘要和实际证据齐备 | 仅解锁依赖图中的对应阶段功能；RELEASE 还须自身正式 ACCEPTED 与源码 SHA/发布证据 |
| `Done` / 正式 `ACCEPTED` | 功能完成且适用的 RELEASE 环境、性能、长稳、CI、签署等全部正式要求通过 | 对已验证版本、环境、用途的正式验收；范围外仍未验收 |

A1 的 `DEFERRED_TO_FINAL_REVIEW` 保留，并按上述规则推广阶段边界。性能/部署等延期项保留 owner、问题、风险、目标环境、执行条件及 RELEASE 入口；不能删除失败事实或从正式验收分母中移除。工程完成率、功能联调完成率、正式发布验收率分别报告。功能已完成但阶段未聚焦评估记 NOT_ASSESSED，不因本文改版自动升级。

## 8. 风险管控与排期保障

| 风险 | 触发信号 | 影响 | 预案 | Owner |
|---|---|---|---|---|
| BFF 接口延期 | 功能接口未按前置窗口就绪；staging 连续 2 天不可用 | 前者影响对应功能，后者影响目标环境验收 | schema-first + MSW 支持开发；真实功能联调用获准工程环境，staging 缺口列入 RELEASE；P0 command 不以 mock 代验收 | BFF TL + FE TL |
| 契约/字段频繁变更 | 一周内 breaking diff >1 次 | client/表单/测试返工 | 版本化 OpenAPI、兼容窗口、consumer contract、变更冻结日；breaking 必须 ADR | Architect |
| 设计变更 | 已开发页面结构/安全文案变化 | 视觉和交互返工 | token/组件优先；设计在 Sprint 前签署；安全含义变更需产品+风控复审 | Product + Design |
| 设计稿状态不全 | 缺错误/无权/陈旧/离线稿 | 边界状态临时发挥 | G0 必须补齐七态；未补齐页面不进 Sprint | Design owner |
| 实时链路不稳定 | 断线、重复、乱序、quota >70% | 状态错乱、重复提示 | cursor 回补、eventId 去重、轮询降级、只读降级；事实始终回查 BFF | BFF + FE |
| 权限/交易边界缺陷 | UI 可见越权数据或可绕过 Risk | 高危安全风险 | 默认拒绝、服务端权威、七类 E2E、IDOR/缓存扫描；立即阻断发布 | Security + Risk |
| 图表/大表性能 | 10k+ 行或高频 candle 卡顿 | 专业使用不可用 | 虚拟化、服务端聚合、增量更新、路由拆包；阶段内做性能基线 | FE Performance owner |
| 第三方/许可问题 | CVE、许可证或上游 breaking | 影响获准用途下的开发/运行或正式发布 | 锁版本、SBOM、adapter 隔离；实际使用始终需要有效批准，商业/再分发/部署用途的许可在 RELEASE 验收，不由工程功能通过自动扩大 | Supply-chain owner |
| 跨浏览器 CI 晚暴露 | Firefox/WebKit 失败 | 对应功能或 Beta 延期 | 从 FEP-1 起每 PR 跑基本 Chromium，定期采样其他目标浏览器；完整矩阵及远程同 SHA CI 在 RELEASE 收口，关键功能缺陷发现即修复 | QA |
| 人员/估算偏差 | Sprint burn-up 偏差 >20% | 里程碑滑动 | P0/P1 分层；锁定安全与契约任务，不删测试；官网/P1 报表或平台增强可后移 | PM + FE TL |

### 8.1 排期控制规则

本节 DoR 为最低要求；新增页面仍须满足第 4 节全量 API 的 DEVELOPMENT 阶段准入，不能仅凭 Reviewed/Mocked 开始，也不要求先取得发布验收。

- 每个阶段开始前满足 DoR：设计七态齐全、契约 Reviewed/Mocked、所需依赖的 stage_gate READY、fixture 可用、owner 与估算已确认；真实使用和联调须处于有效环境/用途授权内。
- Sprint 预留 20% 容量处理功能联调、可访问性、安全/数据缺陷与性能诊断；一般性能优化集中安排在功能闭环后的 RELEASE 窗口，发现无界积压/资源耗尽或明显不可用时及时修复。
- 阻塞超过 1 个工作日升级给 BFF/产品 owner；超过 2 个工作日由 PM 调整依赖顺序；不得通过硬编码返回值绕过。
- 每周准备功能集成候选，获准工程环境可用时做真实 BFF smoke，窗口末做对应功能 Gate；环境缺失登记影响范围并推进独立功能。发布部署演练、完整同 SHA CI、性能和长稳统一由 RELEASE 收口。
- P0 阻断缺陷（交易边界、越权、数据/模式混淆、证据丢失、重复命令）为 0；P1 缺陷必须有 owner、修复版本和风险接受记录。

## 9. 执行看板与责任分工

| 工程责任 / 审阅维度 | 必须在确认文稿中核对的事项 |
|---|---|
| Frontend TL | 技术栈、目录边界、生成 client、共享实现、性能与阶段 Gate |
| BFF TL | OpenAPI、错误 envelope、权限裁剪、幂等、实时回补、correlation/审计 |
| Product/Design | 页面台账、优先级、七态设计、文案、还原度 |
| QA | fixture、契约/E2E/视觉/兼容矩阵、缺陷出口标准 |
| Security | OIDC/MFA、CSP/CORS/CSRF、敏感字段、浏览器权限、供应链 |
| Risk/Compliance | Proposal/Risk/Approval/Command 时序、模式/限额/kill switch、审计与导出 |
| SRE | staging、观测、性能采样、故障注入、Runbook 与发布回滚 |

上表规定工程职责和文稿审阅维度，所有原多角色人工签署均由 Codex 汇总拟稿、项目用户一人确认，不要求逐角色收集签字。

每个看板任务首先包含 `task_id`、`task_type`、`iteration`、`depends_on`、`development_status`、`workflow`、`stage_gate`；一期前端任务不携带指定模型复审字段，工程审计通过报告及证据链接追踪。页面交付看板还必须包含：`页面 ID`、`前端任务 ID`、`契约 ID`、`后端计划 ID`、`风险级别`、`设计链接`、`测试用例`、`owner`、`依赖`、`目标 Sprint`、`契约状态`、`联调状态`、`Gate 证据`。

## 10. RELEASE 发布前验收与检查表

- [ ] 官网首期页面与 Web Terminal P01–P15、P17–P23 的范围、角色、路由和七态全部交付。
- [ ] OpenAPI/Proto/JSON Schema/TS client 无未解释 diff，provider/consumer contract 全绿。
- [ ] Research、Strategy、Proposal → Risk → Approval → Command → Order → Reconciliation → Audit 全链路均有真实 BFF E2E 证据。
- [ ] Proposal 无执行入口；客户端无 command 构造、venue 直连、密钥、离线写或乐观成交。
- [ ] 401/403/404/409/422/429/5xx、断线、陈旧、权限撤销和未知枚举均 fail closed。
- [ ] WCAG 2.2 AA、视觉、性能、兼容、安全和供应链 Gate 达标。
- [ ] 每笔抽样订单可在 5 分钟内还原完整证据链；每个错误可凭 correlation ID 定位。
- [ ] Paper/Shadow 清晰区分；M5 flag 关闭时 Assisted Live UI/API 100% 不可达；Guarded Live 不存在。
- [ ] Web 发布、灰度、回滚、告警与 Runbook 均已演练并归档。


<a id="acceptance-release-gate-beta"></a>
### RELEASE-GATE:BETA：Paper/Shadow 正式发布验收检查点

在 I9 与核心 R1/S2/X3 功能闭环后，完成 Paper/Shadow Beta 的全部业务链、性能指标、staging 与部署环境、安全/视觉/浏览器完整矩阵、获准长稳及 10 个交易日 Shadow、远程同 SHA CI、发布/回滚/告警证据和适用用途许可/用户验收确认；F07/F09 的 Beta 实际使用范围在此验收，L04 责任归档不构成等待全部 L4 的前置。R02 C25：代表性发布环境/数据规模/并发下，ID/hash/标的列表无缓存查询 P95<300ms；R02 C26：已部署 BFF/Runtime、真实登录 JWT/成员权限、跨租户拒绝与快照投影篡改拒绝的完整 HTTP 消费链。owner=CORE:R02，归 RELEASE-GATE:BETA，绑定候选完整源码 SHA 和远程同 SHA CI；发布环境/规模/并发/新范围授权未配置时不得记 PASS。全部正式要求通过且 review_status=ACCEPTED、完整源码 SHA/证据齐备后方可阶段 READY；当前 1800 秒、BTCUSDT/ETHUSDT、原内部用途批准不自动扩展为长稳、部署、商业或交易授权。 R03 Supabase发布验收：平台容量/默认可写性、真实PostgreSQL迁移/RLS/事务一致性、Auth/BFF/Runtime/私有Storage读写及权限拒绝、100任务强杀恢复/无重复Artifact与费用、取消≤2秒、R02获准来源持久消费链、代表性P95/长稳/清理和同SHA CI；包括R03本地准入移交的全部Supabase前置命令。owner=CORE:R03，首次上线前由RELEASE-GATE:BETA逐项实际执行并绑定候选源码；无目标或未执行为NOT RUN，不得用LOCAL_READY代替。 F0/TP03/TP04/R04 本地开发移交：全部Supabase目标命令、平台可写性、PostgreSQL迁移/RLS/事务、Auth/BFF/Runtime/Storage持久闭环和恢复、代表性负载/性能/长稳/目标部署及同SHA CI，由RELEASE-GATE:BETA在首次上线前对候选完整源码实际验收；本地READY不构成数据库、生产或正式ACCEPTED。 后续22任务的外部环境与性能移交按核心计划2.11和机器清单逐项验收，缺目标保持NOT_RUN。 R04 发布验收：Supabase持久Signal/Proposal与R03私有Artifact读回、RLS/事务/独立进程恢复、实际BFF及页面研究消费闭环、外部上游集成、代表性性能/容量/长稳与同SHA CI；本地合成Engine/内存服务READY仅供后续开发，目标和性能NOT_RUN，由RELEASE-GATE:BETA首次上线前实际验收。 TP01-C_LOCAL 发布移交：全部Supabase前置与平台可写性、PostgreSQL迁移/RLS/事务/Auth/Storage及持久Artifact/取消恢复、实际BFF/Runtime部署授权、GitHub远程分支保护及fork治理、OS egress隔离、代表性性能/容量/长稳与候选同SHA CI；由RELEASE-GATE:BETA首次发布前实际验收。目标NOT_RUN，本地研究fixture不授予上游READY、R1-SERVICE、生产或正式ACCEPTED。 TP01-D_LOCAL 发布移交：全部Supabase前置与平台可写性、PostgreSQL迁移/RLS/事务/Auth/Storage及持久Artifact/audit/取消恢复、实际BFF/Runtime部署授权、GitHub远程分支保护及fork治理、R02真实来源与用途许可、OS egress隔离、代表性性能/容量/长稳与候选同SHA CI；由RELEASE-GATE:BETA首次发布前实际验收。目标NOT_RUN，本地合成研究fixture与20组双RPC回放不授予上游READY、R1-SERVICE、生产或正式ACCEPTED。 前端BFF-FE-003之后全部任务的外部环境及性能验收，按前端计划第2.3节与scripts/frontend-gate-handoff-policy.json逐项移交；Beta范围归RELEASE-GATE:BETA，I10/testnet范围归RELEASE-GATE:LIVE-READINESS。DEVELOPMENT和INTEGRATION不要求目标环境或性能达标；发布须补齐原目标与候选同SHA实际证据，未执行NOT_RUN。 A2_LOCAL/R1_LOCAL/BFF003_LOCAL/BFF005_LOCAL 发布移交：Supabase迁移/RLS/事务/Auth/Storage与身份设置/audit导出、Research/Snapshot/Artifact持久消费和worker取消恢复、market/watchlist持久事务及流撤权、真实盘口/成交来源用途许可、外部Engine/服务部署及OS隔离、远程漏洞库SCA与fork治理、代表性性能/容量/长稳、完整浏览器矩阵及候选同SHA CI；归RELEASE-GATE:BETA首次上线前实际验收。目标与性能NOT_RUN，本地回执不构成上游独立READY、正式ACCEPTED或生产/发布授权。 TP02_LOCAL 发布移交：Supabase可写性及PostgreSQL迁移/RLS/事务/Auth/Storage、持久Artifact/audit/取消恢复、真实DataSnapshot字节及获准来源用途、真实provider/LLM/tool与部署JWT/权限、OS egress、GitHub远程治理与SCA漏洞库查询、代表性P95接收<1s/容量/长稳/平台矩阵及候选同SHA CI和ProjectUser正式确认；由测试及RELEASE-GATE:BETA首次发布前实际验收。目标NOT_RUN，本地两组双RPC fixture与隔离安装wheel不授予上游READY、R1-SERVICE、生产或正式ACCEPTED。

```json
{
  "checkpoint_id": "RELEASE-GATE:BETA",
  "acceptance_window": "RELEASE-BETA",
  "depends_on": [
    "CORE-GATE:R1",
    "CORE-GATE:S2",
    "CORE-GATE:X3",
    "FE:FEP-7",
    "PROVIDER:ALL"
  ],
  "required_scope": "在 I9 与核心 R1/S2/X3 功能闭环后，完成 Paper/Shadow Beta 的全部业务链、性能指标、staging 与部署环境、安全/视觉/浏览器完整矩阵、获准长稳及 10 个交易日 Shadow、远程同 SHA CI、发布/回滚/告警证据和适用用途许可/用户验收确认；F07/F09 的 Beta 实际使用范围在此验收，L04 责任归档不构成等待全部 L4 的前置。R02 C25：代表性发布环境/数据规模/并发下，ID/hash/标的列表无缓存查询 P95<300ms；R02 C26：已部署 BFF/Runtime、真实登录 JWT/成员权限、跨租户拒绝与快照投影篡改拒绝的完整 HTTP 消费链。owner=CORE:R02，归 RELEASE-GATE:BETA，绑定候选完整源码 SHA 和远程同 SHA CI；发布环境/规模/并发/新范围授权未配置时不得记 PASS。全部正式要求通过且 review_status=ACCEPTED、完整源码 SHA/证据齐备后方可阶段 READY；当前 1800 秒、BTCUSDT/ETHUSDT、原内部用途批准不自动扩展为长稳、部署、商业或交易授权。 R03 Supabase发布验收：平台容量/默认可写性、真实PostgreSQL迁移/RLS/事务一致性、Auth/BFF/Runtime/私有Storage读写及权限拒绝、100任务强杀恢复/无重复Artifact与费用、取消≤2秒、R02获准来源持久消费链、代表性P95/长稳/清理和同SHA CI；包括R03本地准入移交的全部Supabase前置命令。owner=CORE:R03，首次上线前由RELEASE-GATE:BETA逐项实际执行并绑定候选源码；无目标或未执行为NOT RUN，不得用LOCAL_READY代替。 F0/TP03/TP04/R04 本地开发移交：全部Supabase目标命令、平台可写性、PostgreSQL迁移/RLS/事务、Auth/BFF/Runtime/Storage持久闭环和恢复、代表性负载/性能/长稳/目标部署及同SHA CI，由RELEASE-GATE:BETA在首次上线前对候选完整源码实际验收；本地READY不构成数据库、生产或正式ACCEPTED。 后续22任务的外部环境与性能移交按核心计划2.11和机器清单逐项验收，缺目标保持NOT_RUN。 R04 发布验收：Supabase持久Signal/Proposal与R03私有Artifact读回、RLS/事务/独立进程恢复、实际BFF及页面研究消费闭环、外部上游集成、代表性性能/容量/长稳与同SHA CI；本地合成Engine/内存服务READY仅供后续开发，目标和性能NOT_RUN，由RELEASE-GATE:BETA首次上线前实际验收。 TP01-C_LOCAL 发布移交：全部Supabase前置与平台可写性、PostgreSQL迁移/RLS/事务/Auth/Storage及持久Artifact/取消恢复、实际BFF/Runtime部署授权、GitHub远程分支保护及fork治理、OS egress隔离、代表性性能/容量/长稳与候选同SHA CI；由RELEASE-GATE:BETA首次发布前实际验收。目标NOT_RUN，本地研究fixture不授予上游READY、R1-SERVICE、生产或正式ACCEPTED。 TP01-D_LOCAL 发布移交：全部Supabase前置与平台可写性、PostgreSQL迁移/RLS/事务/Auth/Storage及持久Artifact/audit/取消恢复、实际BFF/Runtime部署授权、GitHub远程分支保护及fork治理、R02真实来源与用途许可、OS egress隔离、代表性性能/容量/长稳与候选同SHA CI；由RELEASE-GATE:BETA首次发布前实际验收。目标NOT_RUN，本地合成研究fixture与20组双RPC回放不授予上游READY、R1-SERVICE、生产或正式ACCEPTED。 前端BFF-FE-003之后全部任务的外部环境及性能验收，按前端计划第2.3节与scripts/frontend-gate-handoff-policy.json逐项移交；Beta范围归RELEASE-GATE:BETA，I10/testnet范围归RELEASE-GATE:LIVE-READINESS。DEVELOPMENT和INTEGRATION不要求目标环境或性能达标；发布须补齐原目标与候选同SHA实际证据，未执行NOT_RUN。 A2_LOCAL/R1_LOCAL/BFF003_LOCAL/BFF005_LOCAL 发布移交：Supabase迁移/RLS/事务/Auth/Storage与身份设置/audit导出、Research/Snapshot/Artifact持久消费和worker取消恢复、market/watchlist持久事务及流撤权、真实盘口/成交来源用途许可、外部Engine/服务部署及OS隔离、远程漏洞库SCA与fork治理、代表性性能/容量/长稳、完整浏览器矩阵及候选同SHA CI；归RELEASE-GATE:BETA首次上线前实际验收。目标与性能NOT_RUN，本地回执不构成上游独立READY、正式ACCEPTED或生产/发布授权。 TP02_LOCAL 发布移交：Supabase可写性及PostgreSQL迁移/RLS/事务/Auth/Storage、持久Artifact/audit/取消恢复、真实DataSnapshot字节及获准来源用途、真实provider/LLM/tool与部署JWT/权限、OS egress、GitHub远程治理与SCA漏洞库查询、代表性P95接收<1s/容量/长稳/平台矩阵及候选同SHA CI和ProjectUser正式确认；由测试及RELEASE-GATE:BETA首次发布前实际验收。目标NOT_RUN，本地两组双RPC fixture与隔离安装wheel不授予上游READY、R1-SERVICE、生产或正式ACCEPTED。",
  "review_status": "NOT_STARTED",
  "source_commit": null,
  "evidence": [],
  "stage_gate": {
    "stage": "RELEASE",
    "status": "NOT_ASSESSED",
    "input_digest": null,
    "evidence": []
  }
}
```

本检查点在功能候选后独立执行，不为 I1–I10 新增反向依赖。每项延期工作须落实 owner、缺口、环境/负载/时长、运行授权及验收命令，满足条件后一次集中优化和验证；不因暂缺部署环境反复重跑短窗口。采用空的新证据目录与具名 actor，提前退出保留失败、结束停止本次进程并停用 actor，保留既有 Supabase 不可变事实。

testnet/Live 准备的部署与正式运行范围另见[核心 RELEASE-GATE:LIVE-READINESS](./SumAlpha-QuantOS-Development-Plan.md#acceptance-release-gate-live-readiness)。该检查点不授权生产 Assisted Live 或 Guarded Live。
