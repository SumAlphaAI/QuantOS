# Bounded, local upstream-advisory regression. No network, credentials or database.
import gc,json,sys,importlib.metadata
import msgpack
from cachecontrol.serialize import Serializer
from requests import Request
from urllib3.response import HTTPResponse

class Marker:
    pass
marker=Marker()
def hook(value):
    return marker
payload=msgpack.packb({42:{'nested':'owned'}},use_bin_type=True)
results=[]
for mode in ['unpackb','stream-unpack','stream-iterate']:
    gc.collect();before=sys.getrefcount(marker);rejected=0
    for _ in range(64):
        u=None
        try:
            if mode=='unpackb':msgpack.unpackb(payload,object_hook=hook)
            else:
                u=msgpack.Unpacker(object_hook=hook);u.feed(payload)
                if mode=='stream-unpack':u.unpack()
                else:list(u)
        except ValueError:
            rejected+=1
        finally:
            del u
    gc.collect()
    results.append({'path':mode,'attempts':64,'defaultStrictMapKeyRejections':rejected,'retainedMarkerReferences':sys.getrefcount(marker)-before})
value={'text':'量化','bytes':b'owned','values':[None,True,123,1.25]}
assert msgpack.unpackb(msgpack.packb(value,use_bin_type=True),raw=False)==value
request=Request('GET','https://owned.invalid/cache-probe').prepare()
response=HTTPResponse(body=b'owned cached body',status=200,headers={'cache-control':'max-age=60'},preload_content=False)
serializer=Serializer();encoded=serializer.dumps(request,response,body=b'owned cached body');restored=serializer.loads(request,encoded)
assert restored.status==200 and restored.read()==b'owned cached body'
passed=msgpack.unpackb.__module__=='msgpack._cmsgpack' and all(r['defaultStrictMapKeyRejections']==64 and r['retainedMarkerReferences']==0 for r in results)
print(json.dumps({'status':'PASS' if passed else 'FAIL','package':'msgpack','version':importlib.metadata.version('msgpack'),'implementation':msgpack.unpackb.__module__,'payloadBytes':len(payload),'results':results,'roundTrip':'PASS','cacheControlSerializerRoundTrip':'PASS','scope':'bounded reference-count probe, not all-platform or complete memory-safety acceptance'},indent=2))
sys.exit(0 if passed else 1)
