# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: website.spec.ts >> WEB-101 website >> 文档详情可通过鼠标展开并收起
- Location: tests/e2e/website.spec.ts:82:7

# Error details

```
Error: expect(locator).not.toHaveAttribute() failed

Locator:  locator('#architecture details')
Expected: not have attribute
Received: have attribute
Timeout:  5000ms

Call log:
  - Expect "not toHaveAttribute" with timeout 5000ms
  - waiting for locator('#architecture details')
    14 × locator resolved to <details open="" class="docs-details">…</details>
       - unexpected value "attribute present"

```

```yaml
- group:
  - text: 阅读当前版本
  - list
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | 
  4   | /**
  5   |  * WEB-101 官网验收：页面渲染、无障碍、移动端无横向溢出、表单防滥用与合规文案。
  6   |  * 服务目标为 apps/website/out 静态产物（见 playwright.website.config.ts）。
  7   |  */
  8   | 
  9   | const SITE_ORIGIN = (process.env.NEXT_PUBLIC_SITE_ORIGIN ?? "https://sumalpha.ai").replace(/\/$/, "");
  10  | const PAGES = ["", "product", "architecture-security", "use-cases", "docs", "access-request", "login"];
  11  | 
  12  | async function fillAccessRequest(page: import("@playwright/test").Page) {
  13  |   const form = page.locator('[data-smoke="website-access-form"]');
  14  |   await form.locator('input[name="teamName"]').fill("SumAlpha Research");
  15  |   await form.locator('input[name="contactEmail"]').fill("research@example.com");
  16  |   await form.locator('select[name="market"]').selectOption("futures");
  17  |   await form.locator('select[name="expectedMode"]').selectOption("shadow");
  18  |   await form.locator('textarea[name="purpose"]').fill("用于验证可重放研究、策略治理与 Shadow 模式协作流程。");
  19  |   await form.locator('input[type="checkbox"]').check();
  20  |   return form;
  21  | }
  22  | 
  23  | test.describe("WEB-101 website", () => {
  24  |   test("首页呈现品牌主张、信任承诺与证据链", async ({ page }) => {
  25  |     await page.goto("/");
  26  |     await expect(page.locator('[data-smoke="website-home"]')).toBeVisible();
  27  |     await expect(page.getByRole("heading", { level: 1 })).toContainText("AI-native operating system");
  28  |     await expect(page.getByText("Agent 不直接下单")).toBeVisible();
  29  |     await expect(page.getByText("默认 Paper / Shadow")).toBeVisible();
  30  |     await expect(page.getByRole("img", { name: /受控链路示意图/ })).toBeVisible();
  31  |     await expect(page.getByRole("link", { name: "申请访问" }).first()).toBeVisible();
  32  |   });
  33  | 
  34  |   test("全部首期页面可访问且导航互链", async ({ page }) => {
  35  |     for (const path of PAGES) {
  36  |       const response = await page.goto(`/${path}`);
  37  |       expect(response?.status(), `GET /${path}`).toBe(200);
  38  |       await expect(page.locator("main#main-content")).toBeVisible();
  39  |     }
  40  |     await page.goto("/product");
  41  |     await page.getByRole("link", { name: "架构与安全" }).first().click();
  42  |     await expect(page).toHaveURL(/architecture-security/);
  43  |     await expect(page.getByRole("heading", { level: 1 })).toContainText("边界先行");
  44  |   });
  45  | 
  46  |   for (const path of PAGES) {
  47  |     test(`/${path} 无 serious/critical 无障碍违规`, async ({ page }) => {
  48  |       await page.goto(`/${path}`);
  49  |       const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze();
  50  |       const blocking = results.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
  51  |       expect(blocking, JSON.stringify(blocking.map((v) => v.id))).toEqual([]);
  52  |     });
  53  |   }
  54  | 
  55  |   test("390px 移动端无页面级横向溢出", async ({ page }) => {
  56  |     await page.setViewportSize({ width: 390, height: 844 });
  57  |     for (const path of PAGES) {
  58  |       await page.goto(`/${path}`);
  59  |       const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  60  |       expect(overflow, `/${path} horizontal overflow`).toBeLessThanOrEqual(0);
  61  |     }
  62  |   });
  63  | 
  64  |   test("文档中心无结果时可清除条件并联系支持", async ({ page }) => {
  65  |     await page.goto("/docs");
  66  |     await page.getByRole("searchbox", { name: "搜索文档" }).fill("不存在的文档关键词");
  67  |     await expect(page.getByRole("heading", { name: "没有匹配的文档" })).toBeVisible();
  68  |     await expect(page.getByRole("status").getByRole("link", { name: "联系支持" })).toHaveAttribute("href", "mailto:support@sumalpha.ai");
  69  |     await page.getByRole("button", { name: "清除搜索条件" }).click();
  70  |     await expect(page.locator(".docs-grid > li")).toHaveCount(6);
  71  |     const architectureDetails = page.locator("#architecture details");
  72  |     // Filtering replaces the focused clear button and can move WebKit's viewport.
  73  |     // Activate the restored native disclosure by keyboard; pointer behavior has its own case below.
  74  |     const summary = architectureDetails.locator("summary");
  75  |     await summary.focus();
  76  |     await expect(summary).toBeFocused();
  77  |     await summary.press("Enter");
  78  |     await expect(architectureDetails).toHaveAttribute("open", "");
  79  |     await expect(architectureDetails.getByText("浏览器只访问 Gateway/BFF", { exact: false })).toBeVisible();
  80  |   });
  81  | 
  82  |   test("文档详情可通过鼠标展开并收起", async ({ page }) => {
  83  |     await page.goto("/docs");
  84  |     const details = page.locator("#architecture details");
  85  |     const summary = details.locator("summary");
  86  |     const content = details.getByText("浏览器只访问 Gateway/BFF", { exact: false });
  87  |     await expect(details).not.toHaveAttribute("open");
  88  |     await expect(content).toBeHidden();
  89  |     await summary.click();
  90  |     await expect(details).toHaveAttribute("open", "");
  91  |     await expect(content).toBeVisible();
  92  |     await summary.click();
> 93  |     await expect(details).not.toHaveAttribute("open");
      |                               ^ Error: expect(locator).not.toHaveAttribute() failed
  94  |     await expect(content).toBeHidden();
  95  |   });
  96  | 
  97  |   test("访问申请表单：校验、honeypot 与受理语义", async ({ page }) => {
  98  |     await page.goto("/access-request");
  99  |     const form = page.locator('[data-smoke="website-access-form"]');
  100 |     await expect(form).toBeVisible();
  101 |     // 未同意隐私条款时浏览器原生校验阻断提交
  102 |     await form.getByRole("button", { name: "提交申请" }).click();
  103 |     await expect(form).toBeVisible();
  104 |     // honeypot 填充后静默拒绝（不发起网络请求）
  105 |     let requested = false;
  106 |     page.on("request", (req) => {
  107 |       if (req.url().includes("/v1/access-requests")) requested = true;
  108 |     });
  109 |     await form.locator('input[name="website"]').fill("spam-bot");
  110 |     await form.locator('input[name="teamName"]').fill("Spam Team");
  111 |     await form.locator('input[name="contactEmail"]').fill("spam@example.com");
  112 |     await form.locator('textarea[name="purpose"]').fill("这是一个用于验证蜜罐行为的自动化提交内容。");
  113 |     await form.locator('input[type="checkbox"]').check();
  114 |     await form.getByRole("button", { name: "提交申请" }).click();
  115 |     await page.waitForTimeout(300);
  116 |     expect(requested).toBe(false);
  117 |     await expect(page.getByText("申请已受理")).not.toBeVisible();
  118 |   });
  119 | 
  120 |   test("访问申请 202 仅显示受理态并发送冻结契约字段", async ({ page }) => {
  121 |     let payload: Record<string, unknown> | undefined;
  122 |     await page.route("**/v1/access-requests", async (route) => {
  123 |       payload = route.request().postDataJSON() as Record<string, unknown>;
  124 |       await route.fulfill({
  125 |         status: 202,
  126 |         contentType: "application/json",
  127 |         body: JSON.stringify({
  128 |           jobId: "11111111-2222-4333-8444-555555555555",
  129 |           status: "accepted",
  130 |           auditRef: "11111111-2222-4333-8444-555555555555",
  131 |           correlationId: "66666666-7777-4888-8999-000000000000",
  132 |         }),
  133 |       });
  134 |     });
  135 |     await page.goto("/access-request");
  136 |     const form = await fillAccessRequest(page);
  137 |     await form.getByRole("button", { name: "提交申请" }).click();
  138 |     await expect(page.getByRole("heading", { name: "申请已受理" })).toBeVisible();
  139 |     await expect(page.getByText("不代表访问权限已经开通")).toBeVisible();
  140 |     expect(payload).toMatchObject({
  141 |       teamName: "SumAlpha Research",
  142 |       markets: ["futures"],
  143 |       expectedMode: "shadow",
  144 |       privacyNoticeVersion: "2026-08-15",
  145 |     });
  146 |   });
  147 | 
  148 |   test("访问申请 429 显示等待与参考号且保留输入", async ({ page }) => {
  149 |     await page.route("**/v1/access-requests", (route) => route.fulfill({
  150 |       status: 429,
  151 |       contentType: "application/json",
  152 |       body: JSON.stringify({
  153 |         code: "RATE_LIMITED",
  154 |         message: "rate limited",
  155 |         retryAfter: 60,
  156 |         correlationId: "66666666-7777-4888-8999-000000000000",
  157 |       }),
  158 |     }));
  159 |     await page.goto("/access-request");
  160 |     const form = await fillAccessRequest(page);
  161 |     await form.getByRole("button", { name: "提交申请" }).click();
  162 |     await expect(form.locator(".form-error")).toContainText("建议等待 60 秒");
  163 |     await expect(form.locator(".form-error")).toContainText("66666666-7777-4888-8999-000000000000");
  164 |     await expect(form.locator('input[name="teamName"]')).toHaveValue("SumAlpha Research");
  165 |   });
  166 | 
  167 |   test("离线时禁止提交并保留已填内容", async ({ page, context }) => {
  168 |     await page.goto("/access-request");
  169 |     const form = await fillAccessRequest(page);
  170 |     await context.setOffline(true);
  171 |     await page.evaluate(() => window.dispatchEvent(new Event("offline")));
  172 |     await expect(form.getByRole("button", { name: "离线，无法提交" })).toBeDisabled();
  173 |     await expect(form.locator(".form-error")).toContainText("网络已断开");
  174 |     await expect(form.locator('textarea[name="purpose"]')).toHaveValue(/用于验证可重放研究/);
  175 |     await context.setOffline(false);
  176 |   });
  177 | 
  178 |   test("SEO 输出覆盖 canonical、robots 与七页 sitemap", async ({ page, request }) => {
  179 |     await page.goto("/");
  180 |     await expect(page).toHaveTitle("SumAlpha QuantOS — AI 原生量化研究与交易操作系统");
  181 |     expect(new URL((await page.locator('link[rel="canonical"]').getAttribute("href"))!).origin).toBe(SITE_ORIGIN);
  182 |     const robots = await request.get("/robots.txt");
  183 |     expect(await robots.text()).toContain(`Sitemap: ${SITE_ORIGIN}/sitemap.xml`);
  184 |     const sitemap = await request.get("/sitemap.xml");
  185 |     const xml = await sitemap.text();
  186 |     for (const url of [
  187 |       SITE_ORIGIN,
  188 |       `${SITE_ORIGIN}/product`,
  189 |       `${SITE_ORIGIN}/architecture-security`,
  190 |       `${SITE_ORIGIN}/use-cases`,
  191 |       `${SITE_ORIGIN}/docs`,
  192 |       `${SITE_ORIGIN}/access-request`,
  193 |       `${SITE_ORIGIN}/login`,
```