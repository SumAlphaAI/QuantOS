// Replay original bounded HTTP evidence only; never grants current phase admission.
import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {coverage} from '../../scripts/provider-all-functional-gate.mjs';
const root='docs/audit/evidence/ci-4667f503-20261027/';
const read=p=>existsSync(p)?readFileSync(p):gunzipSync(readFileSync(p+'.gz'));
const digest=b=>createHash('sha256').update(b).digest('hex');
const binding=JSON.parse(read(root+'source-binding.json'));
for(const f of [...binding.files,...binding.unchangedInputs])assert.equal(digest(readFileSync(f.path)),f.sha256,'source drift: '+f.path);
for(const a of binding.actualCorpus){assert.equal(digest(readFileSync(a.gzipPath)),a.gzipSha256);assert.equal(digest(read(a.logicalPath)),a.sha256);}
const prefix='docs/audit/evidence/provider-all-local-20261020/function-attempt-05/';
const http=JSON.parse(read(prefix+'aggregate-http.json')),assisted=JSON.parse(read(prefix+'assisted-http.json'));
assert.equal(assisted.binarySha256,binding.binary.sha256);
const result=coverage(http,{readBytes:read});assert.equal(result.length,142);assert.equal(http.records.length,3074);assert.equal(http.executions.length,11);
process.stdout.write('PASS_ORIGINAL_SCOPE_REPLAY: 11 domains / 142 operations / 3074 records; current phase admission NOT_ASSESSED\n');
