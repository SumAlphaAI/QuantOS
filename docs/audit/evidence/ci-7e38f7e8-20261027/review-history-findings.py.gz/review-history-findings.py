"""Read-only triage of this frozen scanner report; emits a proposal, never edits policy."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess
base=Path('artifacts/ci-7e38f7e8-20261027')
findings=json.loads((base/'history-findings.redacted.json').read_text())
assert len(findings)==1090
cache={};producer_proofs={};review=[]
hash_bytes=lambda b:hashlib.sha256(b).hexdigest()
def read(commit,path):
 key=(commit,path)
 if key not in cache:cache[key]=subprocess.check_output(['git','show',commit+':'+path])
 return cache[key]
def producer(commit,path):
 key=(commit,path)
 if key not in producer_proofs:
  raw=read(commit,path);s=raw.decode()
  assert re.search(r'createHash\([\'"]sha256[\'"]\)\.update\(b\)\.digest\([\'"]hex[\'"]\)',s),path
  assert re.search(r'keyHash\s*(?:=|:)[^\n]*hash\(String\(req\.headers\[[\'"]idempotency-key[\'"]\]\)\)',s),path
  producer_proofs[key]={'commit':commit,'path':path,'blobSha256':hash_bytes(raw),'verifiedFlow':'request idempotency-key header -> SHA256 -> hexadecimal keyHash; no raw authorization key'}
 return producer_proofs[key]
def producers_for(name):
 if name=='ui301.json':return ['tests/e2e/fixtures/ui301-reference.ts','tests/e2e/fixtures/frontend-g3-reference.ts']
 if name.startswith('ui507'):return ['tests/e2e/ui507.spec.ts']
 paths={'u01-network.json':'u01-reference','frontend-g6.json':'frontend-g6-reference','g6-recovery.json':'frontend-g6-reference','fep5.json':'fep5-reference','g8-journey.json':'frontend-g8-reference','core-x06.json':'x06-reference','ui506.json':'ui506-reference','core-x3.json':'x3-reference','x3-shadow-chain.json':'x3-reference','p08.json':'ui-p08-reference','s04-submission-recovery.json':'frontend-g3-reference'}
 return ['tests/e2e/fixtures/'+paths[name]+'.ts']
def objects(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from objects(v)
 elif isinstance(x,list):
  for v in x:yield from objects(v)
for f in findings:
 commit,path=f['Commit'],f['File'];assert re.fullmatch('[a-f0-9]{40}',commit);assert f['RuleID']=='generic-api-key';assert f['StartLine']==f['EndLine']
 raw=read(commit,path);line=raw.decode().splitlines()[f['StartLine']-1]
 item={'fingerprint':f['Fingerprint'],'commit':commit,'path':path,'rule':f['RuleID'],'line':f['StartLine'],'historicalBlobSha256':hash_bytes(raw),'lineSha256':hash_bytes(line.encode())}
 if path.endswith('.json'):
  assert path.startswith('docs/audit/evidence/')
  m=re.fullmatch(r'\s*"([^"\\]+)":\s*"([^"\\]*)",?\s*',line);assert m,path
  key,value=m.groups();data=json.loads(raw)
  if key=='keyHash':
   assert re.fullmatch('[a-f0-9]{64}',value)
   matching=[r for r in objects(data) if r.get('keyHash')==value];assert matching
   assert all({'method','path','status','source'}.issubset(r) and r['method'] in ['POST','PUT','DELETE','PATCH'] and (r['source'].startswith('REFERENCE_') or r['source'].startswith('SYNTHETIC_')) for r in matching)
   proofs=[producer(commit,p) for p in producers_for(Path(path).name)]
   item.update(classification='SYNTHETIC_IDEMPOTENCY_SHA256',field=key,producerInputs=[{'path':p['path'],'blobSha256':p['blobSha256']} for p in proofs],reason='Hash of a controlled test request idempotency key; not API authorization. Original keys are not stored, so no preimage recomputation is claimed.')
  else:
   assert key=='idempotency_key' and Path(path).name=='r1-chain.json'
   assert re.fullmatch(r'r1-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}',value)
   source=read(commit,'services/bff-gateway/src/r1.rs');assert b'idempotency_key: format!("r1-{}", source.workflow_run_id)' in source
   item.update(classification='SYNTHETIC_WORKFLOW_IDEMPOTENCY_ID',field=key,producerPath='services/bff-gateway/src/r1.rs',producerBlobSha256=hash_bytes(source),reason='Test-only R1 workflow_run_id namespaced with r1-, used for deduplication, not authentication.')
 else:
  assert path=='scripts/core-l01-review.test.mjs' and 'assert.throws(()=>safeArtifact(value))' in line and 'apiSecret=owned-canary' in line
  item.update(classification='NEGATIVE_VALIDATION_CANARY',reason='Public owned-canary literal in assert.throws rejection inputs, not a configured credential.')
 review.append(item)
counts=Counter(x['classification'] for x in review);assert counts=={'SYNTHETIC_IDEMPOTENCY_SHA256':1065,'SYNTHETIC_WORKFLOW_IDEMPOTENCY_ID':24,'NEGATIVE_VALIDATION_CANARY':1}
assert len({x['fingerprint'] for x in review})==1090
report={'sourceSha':'7e38f7e8a881b88e1be52bff31465628d9c4f759','scanner':'Gitleaks 8.28.0','reviewedFindings':1090,'classificationCounts':dict(counts),'scope':'Exact immutable commit/file/rule/line findings only; no rule, value, directory or field-name waiver','producerProofs':list(producer_proofs.values()),'findings':review}
(base/'history-finding-review.json').write_text(json.dumps(report,indent=2)+'\n')
(base/'reviewed-fingerprints.txt').write_text('\n'.join(sorted(x['fingerprint'] for x in review))+'\n')
print('Reviewed',len(review),'findings:',dict(counts),'with',len(producer_proofs),'historical producer snapshots.')
