import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';
import {webEnvironment} from '../../scripts/p0-functional-scope.mjs';
const directory=resolve('artifacts/ci-11b91b21-20261026');
const source='11b91b21f31953c156c7f21bf3fd5e3fa146b627';
for(const name of ['.env','.env.local','.env.production','.env.production.local'])assert(!existsSync('apps/terminal/'+name),'private app dotenv denied');
const env={...webEnvironment(),NEXT_PUBLIC_QUANTOS_ENV:'local-integrated',NEXT_PUBLIC_QUANTOS_MOCK_ENABLED:'false',NEXT_PUBLIC_QUANTOS_BFF_ORIGIN:'https://127.0.0.1:4010',NEXT_PUBLIC_QUANTOS_OIDC_ISSUER:'https://127.0.0.1:4010',GITHUB_SHA:source,CARGO_BUILD_JOBS:'1',CARGO_NET_OFFLINE:'true',CARGO_TERM_COLOR:'never',CI:'1',QUANTOS_SKIP_ENV:'1'};
const commands=[['p07-terminal-build',['pnpm','--filter','@sumalpha/terminal','build']],['p07-bff-build',['cargo','build','--locked','--offline','-p','bff-gateway','--bin','bff-gateway']],['p07-browser',['pnpm','exec','playwright','test','--config','playwright.ui-p07.config.ts','--project','chromium','--grep','P07 ','--update-snapshots=none','--reporter=list,json','--output',directory+'/p07-browser']]];
const results=[];
for(const [id,[command,...args]]of commands){
 const startedAt=new Date().toISOString();
 const r=spawnSync(command,args,{encoding:'utf8',maxBuffer:16*1024*1024,timeout:600000,env:{...env,PLAYWRIGHT_JSON_OUTPUT_NAME:directory+'/p07-browser.json'}});
 writeFileSync(directory+'/'+id+'.log',(r.stdout??'')+(r.stderr??''));
 results.push({id,command:[command,...args],startedAt,finishedAt:new Date().toISOString(),exitCode:r.status,signal:r.signal,errorCode:r.error?.code??null});
 writeFileSync(directory+'/p07-executions.json',JSON.stringify({sourceSha:source,scope:'fresh local integrated mock profile; reference BFF and loopback TLS; no database',results},null,2)+'\n');
 assert.equal(r.status,0,id);assert.equal(r.signal,null,id);assert.equal(r.error,undefined,id);
 console.log(id,'PASS');
 if(id==='p07-terminal-build'){
  const build=JSON.parse(readFileSync('apps/terminal/out/pre03-build.json'));assert.equal(build.buildId,'terminal-'+source);
  writeFileSync(directory+'/p07-build.json',JSON.stringify(build,null,2)+'\n');
 }
}
const report=JSON.parse(readFileSync(directory+'/p07-browser.json'));
assert.equal(report.stats.expected,3);assert.equal(report.stats.unexpected,0);assert.equal(report.stats.skipped,0);assert.equal(report.stats.flaky,0);
console.log('P07 all three scenarios passed, no skips or flaky outcomes.');
