from pathlib import Path
import json,hashlib,struct,subprocess
root=Path('artifacts/ci-39ce9714-20261025');sha='39ce971488c36cd48564b802fee4e1919c169313'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dimensions(p):return struct.unpack('>II',p.read_bytes()[16:24])
receipt=json.loads((root/'linux-candidates/receipt.json').read_text())
assert receipt['commit']==sha and receipt['runner']=='ubuntu-24.04' and receipt['run'].endswith('/40176236047')
assert len(receipt['files'])==12
subprocess.run(['git','diff','--exit-code',sha,'--','apps/terminal','packages','playwright.config.ts','pnpm-lock.yaml','package.json'],check=True,stdout=subprocess.DEVNULL)
rows=[]
for entry in receipt['files']:
 source=root/'linux-candidates'/entry['path'];assert digest(source)==entry['sha256'];assert dimensions(source)==(entry['width'],entry['height'])
 # UI102 is explicitly dark after this repair. Its reference is the identical
 # /login, 1440x900, dark P01 capture from the original Linux failure report.
 if 'ui102-login' in entry['path']:continue
 rows.append({'target':entry['path'],'source':str(source),'artifactId':12592515891,'run':40176236047,'basis':'reviewed exact-source Linux candidate'})
for browser,artifact in [('chromium',12591228523),('firefox',12591442231),('webkit',12591387564)]:
 directory=root/('linux-'+browser);report=json.loads((directory/'terminal.json').read_text());assert report['stats']['expected']==44 and report['stats']['unexpected']==5 and report['stats']['flaky']==0
 for theme in ['dark','light']:
  for page in ['login','mfa','access-request','unauthorized','offline']:
   name=f'p01-{page}-{theme}';matches=[f for f in directory.rglob(name+'-actual.png') if 'retry' not in str(f)];assert len(matches)==1
   source=matches[0];assert dimensions(source)==(1440,900),(source,dimensions(source))
   rows.append({'target':f'tests/e2e/ui-p01.spec.ts-snapshots/{name}-{browser}-linux.png','source':str(source),'artifactId':artifact,'run':40174245400,'basis':'reviewed original missing-baseline actual, same route/theme/viewport'})
   if page=='login' and theme=='dark':
    rows.append({'target':f'tests/e2e/ui102-auth.spec.ts-snapshots/ui102-login-1440-dark-{browser}-linux.png','source':str(source),'artifactId':artifact,'run':40174245400,'basis':'same /login dark capture, 1440x900 fullPage equals viewport; UI102 now explicitly requests dark media'})
assert len(rows)==42 and len({r['target'] for r in rows})==42
manifestPath=Path('tests/e2e/visual-baselines.json');manifest=json.loads(manifestPath.read_text());byPath={r['path']:r for r in manifest['entries']}
for r in rows:
 source=Path(r['source']);target=Path(r['target']);r['sha256']=digest(source);r['width'],r['height']=dimensions(source);r['previousSha256']=digest(target) if target.exists() else None
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
 byPath[str(target)]={'path':str(target),'sha256':r['sha256'],'width':r['width'],'height':r['height'],'scope':f'Reviewed Linux mocked UI reference from {sha}; workflow {r["run"]}; fresh repaired-SHA comparison NOT_RUN'}
# The single local Chromium auth reference changed with the explicit dark media.
for entry in list(byPath.values()):
 target=Path(entry['path'])
 if target.exists() and digest(target)!=entry['sha256']:
  assert entry['path']=='tests/e2e/ui102-auth.spec.ts-snapshots/ui102-login-1440-dark-chromium-darwin.png'
  entry['sha256']=digest(target);entry['width'],entry['height']=dimensions(target);entry['scope']='Local Chromium Darwin mocked login, explicit dark media; browser comparison recorded separately; other Darwin browsers NOT_RUN'
manifest['entries']=sorted(byPath.values(),key=lambda r:r['path'])
manifest['linuxCapture']={'commit':sha,'run':receipt['run'],'runner':receipt['runner'],'playwright':receipt['playwright'],'additionalSourceRun':'https://github.com/SumAlphaAI/QuantOS/actions/runs/40174245400','review':'source PNGs reviewed by Codex; original capture/missing-reference failures retained; repaired-SHA comparison NOT_RUN'}
manifestPath.write_text(json.dumps(manifest,indent=2)+'\n')
(root/'linux-import.json').write_text(json.dumps({'sourceCommit':sha,'renderingSourceUnchanged':True,'newMissingBaselines':sum(r['previousSha256'] is None for r in rows),'referencesReviewed':42,'pixelTransformation':False,'thresholdChanged':False,'rows':rows},indent=2)+'\n')
print('Imported 42 reviewed Linux references, including 30 missing P01 images; no pixel transformation')
