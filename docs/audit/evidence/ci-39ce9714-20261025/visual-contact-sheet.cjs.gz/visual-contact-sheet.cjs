const fs=require('node:fs'),path=require('node:path'),{PNG}=require('../../node_modules/pngjs');
const root=path.resolve('artifacts/ci-39ce9714-20261025');
const files=process.argv.slice(3);const tileW=480,tileH=340,cols=3,rows=Math.ceil(files.length/cols);const out=new PNG({width:cols*tileW,height:rows*tileH,fill:true});out.data.fill(220);
files.forEach((file,index)=>{const p=PNG.sync.read(fs.readFileSync(file)),w=tileW,h=Math.min(tileH-20,Math.round(p.height*w/p.width));for(let y=0;y<h;y++)for(let x=0;x<w;x++){const src=(Math.min(p.height-1,Math.floor(y*p.height/h))*p.width+Math.floor(x*p.width/w))*4,dst=((Math.floor(index/cols)*tileH+y)*out.width+(index%cols)*tileW+x)*4;p.data.copy(out.data,dst,src,src+4);}});
fs.writeFileSync(process.argv[2],PNG.sync.write(out));fs.writeFileSync(process.argv[2]+'.json',JSON.stringify(files,null,2)+'\n');
