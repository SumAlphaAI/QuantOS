import urllib.request,urllib.error,subprocess,io,zipfile,struct,zlib,json,hashlib,concurrent.futures,time
from pathlib import Path
root=Path('artifacts/ci-39ce9714-20261025')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None

def fetch(artifact,label):
 token=subprocess.check_output(['gh','auth','token'],text=True).strip()
 req=urllib.request.Request(f'https://api.github.com/repos/SumAlphaAI/QuantOS/actions/artifacts/{artifact}/zip',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'})
 try:urllib.request.build_opener(NoRedirect).open(req,timeout=30);raise RuntimeError('expected artifact redirect')
 except urllib.error.HTTPError as e:
  if e.code!=302:raise RuntimeError('artifact redirect HTTP '+str(e.code)) from None
  url=e.headers['Location']
 def get(start,end):
  for attempt in range(3):
   try:
    req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}'})
    with urllib.request.urlopen(req,timeout=30) as response:
     if response.status!=206:raise RuntimeError('range request must return 206')
     data=response.read();contentrange=response.headers['Content-Range']
    if len(data)!=end-start+1:raise RuntimeError('truncated range')
    return data,contentrange
   except Exception:
    if attempt==2:raise RuntimeError(f'artifact {artifact} range {start}-{end} failed after 3 attempts') from None
    time.sleep(0.3*(attempt+1))
 _,cr=get(0,0);size=int(cr.split('/')[-1])
 class Reader:
  pos=0
  def seek(self,offset,whence=0):
   self.pos=offset if whence==0 else self.pos+offset if whence==1 else size+offset
   return self.pos
  def tell(self):return self.pos
  def read(self,length=-1):
   length=size-self.pos if length<0 else min(length,size-self.pos)
   if length<=0:return b''
   data,_=get(self.pos,self.pos+length-1);self.pos+=length;return data
  def seekable(self):return True
 with zipfile.ZipFile(Reader()) as archive:infos=archive.infolist()
 dest=root/label;dest.mkdir(parents=True,exist_ok=True)
 selected=[i for i in infos if i.filename.endswith('.json') or i.filename.endswith('-actual.png') or i.filename.endswith('-expected.png') or (label=='linux-candidates' and i.filename.endswith('.png'))]
 def entry(info):
  start=info.header_offset;end=min(size-1,start+30+len(info.filename.encode())+len(info.extra)+info.compress_size+128)
  data,_=get(start,end)
  header=struct.unpack('<4s5H3L2H',data[:30]);assert header[0]==b'PK\x03\x04'
  offset=30+header[-2]+header[-1]
  if len(data)<offset+info.compress_size:data,_=get(start,start+offset+info.compress_size-1)
  payload=data[offset:offset+info.compress_size]
  raw=zlib.decompress(payload,-15) if info.compress_type==zipfile.ZIP_DEFLATED else payload
  assert len(raw)==info.file_size and (zlib.crc32(raw)&0xffffffff)==info.CRC
  target=dest/info.filename
  assert dest.resolve() in target.resolve().parents
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  return {'path':info.filename,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'crc32':hex(info.CRC)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:files=list(pool.map(entry,selected))
 receipt={'artifactId':artifact,'archiveBytes':size,'archiveEntries':len(infos),'selectedEntries':len(files),'scope':'selected complete ZIP entries only; HTTP 206 range, deflate/CRC32 and SHA256 verified; not a full archive download','files':files}
 (root/(label+'-download.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(label,'PASS',len(files),'entries',sum(x['bytes'] for x in files),'bytes',flush=True)

if __name__=='__main__':
 import sys
 if len(sys.argv)>1:fetch(int(sys.argv[1]),sys.argv[2])
 else:
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda x:fetch(*x),[(12591228523,'linux-chromium'),(12591442231,'linux-firefox'),(12591387564,'linux-webkit')]))
