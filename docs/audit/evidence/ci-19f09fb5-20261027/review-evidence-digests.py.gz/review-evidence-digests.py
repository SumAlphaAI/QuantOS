# Read-only review of exact source digest fields in the original CLI receipt.
from pathlib import Path
import hashlib,json,re
root=Path('artifacts/ci-19f09fb5-20261027')
receipt=json.loads((root/'semantics.json').read_text())
findings=json.loads((root/'raw-evidence-findings.json').read_text())
assert receipt['schema']=='quantos-bff-a2-executed-semantics/v1' and receipt['status']=='PASS'
assert receipt['sourceCommit']=='19f09fb521ee09a21a3ea03674200c6a84c06e99'
expected={'authBoundary':'crates/quantos-auth/src/lib.rs','authClient':'apps/terminal/src/auth/bff.ts'}
lines=(root/'semantics.json').read_text().splitlines()
def review(f,r=receipt,rows=lines):
 assert f['File']==str(root/'semantics.json') and f['RuleID']=='generic-api-key'
 assert f['StartLine']==f['EndLine']
 line=rows[f['StartLine']-1]
 m=re.fullmatch(r'\s*"(authBoundary|authClient)": "([a-f0-9]{64})",?\s*',line);assert m
 field,value=m.groups();path=expected[field]
 actual=hashlib.sha256(Path(path).read_bytes()).hexdigest()
 assert value==r['sourceHashes'][field]==actual
 return {'path':path,'algorithm':'SHA-256','digest':actual,'receiptLine':f['StartLine'],'lineSha256':hashlib.sha256(line.encode()).hexdigest(),'classification':'VERIFIED_CURRENT_SOURCE_DIGEST_NOT_CREDENTIAL'}
assert len(findings)==2
reviews=[review(f) for f in findings];assert {x['path'] for x in reviews}==set(expected.values())
refused=0
for f in findings:
 line=lines[f['StartLine']-1];field=re.search(r'"(authBoundary|authClient)"',line)[1]
 forged=json.loads(json.dumps(receipt));forged['sourceHashes'][field]='0'*64
 try:review(f,forged)
 except AssertionError:refused+=1
 else:raise AssertionError('forged digest accepted')
 rows=lines.copy();rows[f['StartLine']-1]=re.sub('[a-f0-9]{64}','0'*64,line)
 try:review(f,rows=rows)
 except AssertionError:refused+=1
 else:raise AssertionError('forged original line accepted')
assert refused==4
(root/'raw-evidence-digest-review.json').write_text(json.dumps({'rawScannerStatus':'FAIL','rawFindings':2,'reviewedNonCredentialSourceDigests':2,'unreviewed':0,'negativeControlsRefused':refused,'scannerConfigChanged':False,'originalReceiptPreserved':True,'review':reviews},indent=2)+'\n')
print('2 exact source digests verified; 4 forged receipt/line controls refused; original raw scan FAIL retained')
