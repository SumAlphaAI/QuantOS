# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: website.spec.ts >> WEB-101 website >> 文档中心无结果时可清除条件并联系支持
- Location: tests/e2e/website.spec.ts:64:7

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('#architecture details')
Expected: ""
Received: serializes to the same string
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for locator('#architecture details')
    14 × locator resolved to <details class="docs-details">…</details>
       - unexpected value "null"

```

```yaml
- group: 阅读当前版本
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | 
  4   | /**
  5   |  * WEB-101 官网验收：页面渲染、无障碍、移动端无横向溢出、表单防滥用与合规文案。
  6   |  * 服务目标为 apps/website/out 静态产物（见 playwright.website.config.ts）。
  7   |  */
  8   | 
  9   | const SITE_ORIGIN = (process.env.NEXT_PUBLIC_SITE_ORIGIN ?? "https://sumalpha.ai").replace(/\/$/, "");
  10  | const PAGES = ["", "product", "architecture-security", "use-cases", "docs", "access-request", "login"];
  11  | 
  12  | async function fillAccessRequest(page: import("@playwright/test").Page) {
  13  |   const form = page.locator('[data-smoke="website-access-form"]');
  14  |   await form.locator('input[name="teamName"]').fill("SumAlpha Research");
  15  |   await form.locator('input[name="contactEmail"]').fill("research@example.com");
  16  |   await form.locator('select[name="market"]').selectOption("futures");
  17  |   await form.locator('select[name="expectedMode"]').selectOption("shadow");
  18  |   await form.locator('textarea[name="purpose"]').fill("用于验证可重放研究、策略治理与 Shadow 模式协作流程。");
  19  |   await form.locator('input[type="checkbox"]').check();
  20  |   return form;
  21  | }
  22  | 
  23  | test.describe("WEB-101 website", () => {
  24  |   test("首页呈现品牌主张、信任承诺与证据链", async ({ page }) => {
  25  |     await page.goto("/");
  26  |     await expect(page.locator('[data-smoke="website-home"]')).toBeVisible();
  27  |     await expect(page.getByRole("heading", { level: 1 })).toContainText("AI-native operating system");
  28  |     await expect(page.getByText("Agent 不直接下单")).toBeVisible();
  29  |     await expect(page.getByText("默认 Paper / Shadow")).toBeVisible();
  30  |     await expect(page.getByRole("img", { name: /受控链路示意图/ })).toBeVisible();
  31  |     await expect(page.getByRole("link", { name: "申请访问" }).first()).toBeVisible();
  32  |   });
  33  | 
  34  |   test("全部首期页面可访问且导航互链", async ({ page }) => {
  35  |     for (const path of PAGES) {
  36  |       const response = await page.goto(`/${path}`);
  37  |       expect(response?.status(), `GET /${path}`).toBe(200);
  38  |       await expect(page.locator("main#main-content")).toBeVisible();
  39  |     }
  40  |     await page.goto("/product");
  41  |     await page.getByRole("link", { name: "架构与安全" }).first().click();
  42  |     await expect(page).toHaveURL(/architecture-security/);
  43  |     await expect(page.getByRole("heading", { level: 1 })).toContainText("边界先行");
  44  |   });
  45  | 
  46  |   for (const path of PAGES) {
  47  |     test(`/${path} 无 serious/critical 无障碍违规`, async ({ page }) => {
  48  |       await page.goto(`/${path}`);
  49  |       const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze();
  50  |       const blocking = results.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
  51  |       expect(blocking, JSON.stringify(blocking.map((v) => v.id))).toEqual([]);
  52  |     });
  53  |   }
  54  | 
  55  |   test("390px 移动端无页面级横向溢出", async ({ page }) => {
  56  |     await page.setViewportSize({ width: 390, height: 844 });
  57  |     for (const path of PAGES) {
  58  |       await page.goto(`/${path}`);
  59  |       const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  60  |       expect(overflow, `/${path} horizontal overflow`).toBeLessThanOrEqual(0);
  61  |     }
  62  |   });
  63  | 
  64  |   test("文档中心无结果时可清除条件并联系支持", async ({ page }) => {
  65  |     await page.goto("/docs");
  66  |     await page.getByRole("searchbox", { name: "搜索文档" }).fill("不存在的文档关键词");
  67  |     await expect(page.getByRole("heading", { name: "没有匹配的文档" })).toBeVisible();
  68  |     await expect(page.getByRole("status").getByRole("link", { name: "联系支持" })).toHaveAttribute("href", "mailto:support@sumalpha.ai");
  69  |     await page.getByRole("button", { name: "清除搜索条件" }).click();
  70  |     await expect(page.locator(".docs-grid > li")).toHaveCount(6);
  71  |     const architectureDetails = page.locator("#architecture details");
  72  |     await architectureDetails.getByText("阅读当前版本", { exact: true }).click();
> 73  |     await expect(architectureDetails).toHaveAttribute("open", "");
      |                                       ^ Error: expect(locator).toHaveAttribute(expected) failed
  74  |     await expect(architectureDetails.getByText("浏览器只访问 Gateway/BFF", { exact: false })).toBeVisible();
  75  |   });
  76  | 
  77  |   test("访问申请表单：校验、honeypot 与受理语义", async ({ page }) => {
  78  |     await page.goto("/access-request");
  79  |     const form = page.locator('[data-smoke="website-access-form"]');
  80  |     await expect(form).toBeVisible();
  81  |     // 未同意隐私条款时浏览器原生校验阻断提交
  82  |     await form.getByRole("button", { name: "提交申请" }).click();
  83  |     await expect(form).toBeVisible();
  84  |     // honeypot 填充后静默拒绝（不发起网络请求）
  85  |     let requested = false;
  86  |     page.on("request", (req) => {
  87  |       if (req.url().includes("/v1/access-requests")) requested = true;
  88  |     });
  89  |     await form.locator('input[name="website"]').fill("spam-bot");
  90  |     await form.locator('input[name="teamName"]').fill("Spam Team");
  91  |     await form.locator('input[name="contactEmail"]').fill("spam@example.com");
  92  |     await form.locator('textarea[name="purpose"]').fill("这是一个用于验证蜜罐行为的自动化提交内容。");
  93  |     await form.locator('input[type="checkbox"]').check();
  94  |     await form.getByRole("button", { name: "提交申请" }).click();
  95  |     await page.waitForTimeout(300);
  96  |     expect(requested).toBe(false);
  97  |     await expect(page.getByText("申请已受理")).not.toBeVisible();
  98  |   });
  99  | 
  100 |   test("访问申请 202 仅显示受理态并发送冻结契约字段", async ({ page }) => {
  101 |     let payload: Record<string, unknown> | undefined;
  102 |     await page.route("**/v1/access-requests", async (route) => {
  103 |       payload = route.request().postDataJSON() as Record<string, unknown>;
  104 |       await route.fulfill({
  105 |         status: 202,
  106 |         contentType: "application/json",
  107 |         body: JSON.stringify({
  108 |           jobId: "11111111-2222-4333-8444-555555555555",
  109 |           status: "accepted",
  110 |           auditRef: "11111111-2222-4333-8444-555555555555",
  111 |           correlationId: "66666666-7777-4888-8999-000000000000",
  112 |         }),
  113 |       });
  114 |     });
  115 |     await page.goto("/access-request");
  116 |     const form = await fillAccessRequest(page);
  117 |     await form.getByRole("button", { name: "提交申请" }).click();
  118 |     await expect(page.getByRole("heading", { name: "申请已受理" })).toBeVisible();
  119 |     await expect(page.getByText("不代表访问权限已经开通")).toBeVisible();
  120 |     expect(payload).toMatchObject({
  121 |       teamName: "SumAlpha Research",
  122 |       markets: ["futures"],
  123 |       expectedMode: "shadow",
  124 |       privacyNoticeVersion: "2026-08-15",
  125 |     });
  126 |   });
  127 | 
  128 |   test("访问申请 429 显示等待与参考号且保留输入", async ({ page }) => {
  129 |     await page.route("**/v1/access-requests", (route) => route.fulfill({
  130 |       status: 429,
  131 |       contentType: "application/json",
  132 |       body: JSON.stringify({
  133 |         code: "RATE_LIMITED",
  134 |         message: "rate limited",
  135 |         retryAfter: 60,
  136 |         correlationId: "66666666-7777-4888-8999-000000000000",
  137 |       }),
  138 |     }));
  139 |     await page.goto("/access-request");
  140 |     const form = await fillAccessRequest(page);
  141 |     await form.getByRole("button", { name: "提交申请" }).click();
  142 |     await expect(form.locator(".form-error")).toContainText("建议等待 60 秒");
  143 |     await expect(form.locator(".form-error")).toContainText("66666666-7777-4888-8999-000000000000");
  144 |     await expect(form.locator('input[name="teamName"]')).toHaveValue("SumAlpha Research");
  145 |   });
  146 | 
  147 |   test("离线时禁止提交并保留已填内容", async ({ page, context }) => {
  148 |     await page.goto("/access-request");
  149 |     const form = await fillAccessRequest(page);
  150 |     await context.setOffline(true);
  151 |     await page.evaluate(() => window.dispatchEvent(new Event("offline")));
  152 |     await expect(form.getByRole("button", { name: "离线，无法提交" })).toBeDisabled();
  153 |     await expect(form.locator(".form-error")).toContainText("网络已断开");
  154 |     await expect(form.locator('textarea[name="purpose"]')).toHaveValue(/用于验证可重放研究/);
  155 |     await context.setOffline(false);
  156 |   });
  157 | 
  158 |   test("SEO 输出覆盖 canonical、robots 与七页 sitemap", async ({ page, request }) => {
  159 |     await page.goto("/");
  160 |     await expect(page).toHaveTitle("SumAlpha QuantOS — AI 原生量化研究与交易操作系统");
  161 |     expect(new URL((await page.locator('link[rel="canonical"]').getAttribute("href"))!).origin).toBe(SITE_ORIGIN);
  162 |     const robots = await request.get("/robots.txt");
  163 |     expect(await robots.text()).toContain(`Sitemap: ${SITE_ORIGIN}/sitemap.xml`);
  164 |     const sitemap = await request.get("/sitemap.xml");
  165 |     const xml = await sitemap.text();
  166 |     for (const url of [
  167 |       SITE_ORIGIN,
  168 |       `${SITE_ORIGIN}/product`,
  169 |       `${SITE_ORIGIN}/architecture-security`,
  170 |       `${SITE_ORIGIN}/use-cases`,
  171 |       `${SITE_ORIGIN}/docs`,
  172 |       `${SITE_ORIGIN}/access-request`,
  173 |       `${SITE_ORIGIN}/login`,
```