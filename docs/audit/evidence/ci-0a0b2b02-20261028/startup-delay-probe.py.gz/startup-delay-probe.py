"""Pause only the gateway child owned by an exact startup test; no service/DB IO."""
from pathlib import Path
import json, os, signal, subprocess, time
root=Path.cwd(); out=root/'artifacts/ci-0a0b2b02-20261028'
source='services/bff-gateway/tests/reference_startup.rs'
old=subprocess.check_output(['git','show','HEAD:'+source])
new=(root/source).read_bytes()
libs=sorted((root/'target/debug/deps').glob('libserde_json-*.rlib'))
assert libs
report=[]
for label,raw in [('before',old),('after',new)]:
 p=out/f'startup-{label}-probe.rs';p.write_bytes(raw)
 binary=out/f'startup-{label}-probe'
 env=dict(os.environ);env['CARGO_BIN_EXE_bff-gateway']=str(root/'target/debug/bff-gateway')
 compile=subprocess.run(['rustc','--edition=2024','--test',str(p),'-L','dependency='+str(root/'target/debug/deps'),'--extern','serde_json='+str(libs[0]),'-o',str(binary)],env=env,capture_output=True,text=True)
 (out/f'probe-compile-{label}.log').write_text(compile.stdout+compile.stderr)
 assert compile.returncode==0,compile.stderr
 begin=time.monotonic();proc=subprocess.Popen([str(binary),'--exact','operations_feed_starts_with_configured_download_origin','--nocapture'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 child=None
 try:
  while time.monotonic()-begin<3:
   if proc.poll() is not None:break
   rows=subprocess.check_output(['ps','-axo','pid=,ppid=,comm='],text=True).splitlines()
   for row in rows:
    parts=row.strip().split(None,2)
    if len(parts)==3 and int(parts[1])==proc.pid and parts[2].endswith('bff-gateway'):
     child=int(parts[0]);break
   if child is not None:break
   time.sleep(0.01)
  assert child is not None,'owned gateway child not found'
  os.kill(child,signal.SIGSTOP)
  time.sleep(11.5)
  try:os.kill(child,signal.SIGCONT)
  except ProcessLookupError:pass
  output=proc.communicate(timeout=65)[0]
  (out/f'probe-{label}.log').write_text(output)
  expected=label=='after';assert (proc.returncode==0)==expected,output
  if not expected:assert 'Timeout' in output,output
  # Drop kills and waits for the exact child on both success and failure.
  try:os.kill(child,0)
  except ProcessLookupError:reaped=True
  else:reaped=False
  assert reaped,'gateway child survived test'
  report.append({'variant':label,'controlledPauseSeconds':11.5,'elapsedSeconds':round(time.monotonic()-begin,3),'exitCode':proc.returncode,'expectedResultObserved':True,'childReaped':reaped,'scope':'controlled scheduler-delay reproduction, not Linux runner profiling'})
 finally:
  if proc.poll() is None:proc.kill();proc.wait()
  if child:
   try:os.kill(child,signal.SIGKILL)
   except ProcessLookupError:pass
(out/'startup-delay-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
